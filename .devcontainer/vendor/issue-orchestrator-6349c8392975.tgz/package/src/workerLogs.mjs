// Durable per-attempt worker logs.
//
// A tmux worker's output lives and dies with its pane, so a window that
// vanishes takes the only evidence of why with it. Every launch reserves a
// file here and streams its combined output into it, which lets the supervisor
// surface a bounded, redacted tail when it later notices the worker is gone.
//
// Everything is best effort: a log that cannot be written must never cost a
// worker, so every operation degrades to `null` rather than throwing.
import { mkdir as fsMkdir, readFile as fsReadFile, readdir as fsReaddir, unlink as fsUnlink } from "node:fs/promises";
import { isAbsolute, join, resolve } from "node:path";

// Under the *common* git dir, so a log outlives the issue worktree it
// describes, needs no `.gitignore` entry, and can never be tracked.
export const LOG_DIR_NAME = join("issue-orchestrator", "logs");

// Retention: at most this many attempt files per (role, issue) survive a
// launch, counting the attempt about to be written. The issue requires a bound
// preserving at least the latest three.
export const KEEP_ATTEMPTS = 3;

// Tail bounds, sized to sit comfortably inside a GitHub comment.
export const TAIL_LINES = 40;
export const TAIL_CHARS = 4000;

// Roles are an allowlist, not a passthrough: a later repair worker adds one
// string here and needs no other change, while no caller-supplied value can
// ever reach the path.
export const WORKER_ROLES = new Set(["issue", "review"]);

const REDACTIONS = [
  // Whole PEM blocks first, before any inner rule can fragment them. The body
  // is bounded well above any real key so an unmatched BEGIN cannot make the
  // lazy scan backtrack across the whole log.
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{0,20000}?-----END [A-Z ]*PRIVATE KEY-----/g, "[REDACTED]"],
  // A worker killed mid-print leaves a BEGIN with no END, which the balanced
  // rule cannot match. Everything after that marker is key material, so the
  // only safe reading is to redact to the end of the text.
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*/g, "[REDACTED]"],
  [/\bgithub_pat_[A-Za-z0-9_]{10,}/g, "[REDACTED]"],
  [/\bgh[pousr]_[A-Za-z0-9_]{10,}/g, "[REDACTED]"],
  [/(\bauthorization\s*:\s*)(bearer|token)\s+\S+/gi, "$1$2 [REDACTED]"],
  [/x-access-token:[^@\s]+@/gi, "x-access-token:[REDACTED]@"],
  // Inherited environment values. The name must be shell-style uppercase so
  // ordinary prose and YAML (`key: value`) stay readable. An unquoted value
  // runs to the end of the line rather than to the first space, because
  // `GH_TOKEN=my secret value` is one secret, not one word plus prose; the line
  // already contains a secret, so over-redacting its remainder is the safe
  // trade. Only horizontal whitespace surrounds the separator, which keeps
  // every alternative line-scoped and stops the rest-of-line match from
  // reaching past a newline into the next, innocent line.
  [
    /\b([A-Z][A-Z0-9_]*(?:TOKEN|SECRET|KEY|PASSWORD|PASSWD|CREDENTIALS?)[A-Z0-9_]*)([^\S\n]*[=:][^\S\n]*)("[^"\n]*"|'[^'\n]*'|[^\n]*)/g,
    "$1$2[REDACTED]",
  ],
];

// Applied when output is surfaced rather than when it is written: the criterion
// is about surfaced tails, and filtering the live stream would add a process to
// every worker command for the chance of mangling a diagnostic.
export function redactSecrets(text) {
  let out = String(text);
  for (const [pattern, replacement] of REDACTIONS) out = out.replace(pattern, replacement);
  return out;
}

function attemptPattern(role, number) {
  return new RegExp(`^${role}-${number}\\.(\\d+)\\.log$`);
}

function boundedTail(contents) {
  const lines = String(contents).replace(/\n+$/, "").split("\n");
  // Redact before the character bound, never after: cutting first can shear a
  // secret's prefix off (`ghs_XXXX` -> `XXXX`), leaving a remnant no pattern
  // recognises. A cut through a `[REDACTED]` marker is harmless by comparison.
  const tail = redactSecrets(lines.slice(-TAIL_LINES).join("\n"));
  return tail.length > TAIL_CHARS ? tail.slice(-TAIL_CHARS) : tail;
}

export function createWorkerLogs({
  exec,
  cwd = process.cwd(),
  fs = {},
  log = () => {},
} = {}) {
  const { mkdir = fsMkdir, readFile = fsReadFile, readdir = fsReaddir, unlink = fsUnlink } = fs;
  let dirPromise;

  // The same identity rule the tmux adapter applies before shell
  // interpolation, so a path is only ever assembled from validated parts.
  function identity(role, number) {
    if (!WORKER_ROLES.has(role)) return null;
    const n = Number(number);
    if (!Number.isInteger(n) || n <= 0) return null;
    return { role, number: n };
  }

  // `git rev-parse` answers relative to the process cwd, so a bare `.git` is
  // resolved against it. Cached: the answer cannot change while running.
  async function logDir() {
    if (!dirPromise) {
      dirPromise = (async () => {
        const { stdout } = await exec("git", ["rev-parse", "--git-common-dir"]);
        const common = stdout.trim();
        if (!common) throw new Error("git rev-parse --git-common-dir returned nothing");
        return join(isAbsolute(common) ? common : resolve(cwd, common), LOG_DIR_NAME);
      })();
      dirPromise.catch(() => { dirPromise = undefined; });
    }
    return dirPromise;
  }

  async function existingAttempts(dir, role, number) {
    const pattern = attemptPattern(role, number);
    const found = [];
    for (const name of await readdir(dir)) {
      const m = name.match(pattern);
      if (m) found.push({ name, attempt: Number(m[1]) });
    }
    return found.sort((a, b) => a.attempt - b.attempt);
  }

  // Reserve the next attempt file for a worker about to launch. Returns the
  // absolute path, or `null` when the log cannot be prepared — in which case
  // the caller launches the worker anyway.
  async function prepare(role, number) {
    const id = identity(role, number);
    if (!id) {
      log(`worker log skipped: invalid worker identity (role=${String(role)}, number=${String(number)})`);
      return null;
    }
    let dir;
    let attempts;
    try {
      dir = await logDir();
      await mkdir(dir, { recursive: true });
      attempts = await existingAttempts(dir, id.role, id.number);
    } catch (err) {
      log(`worker log unavailable for ${id.role}-${id.number} (continuing without it): ${err.message}`);
      return null;
    }

    // Pruning is opportunistic — an undeletable old attempt must not block the
    // new one, it only leaves retention temporarily over its bound.
    for (const stale of attempts.slice(0, Math.max(0, attempts.length - (KEEP_ATTEMPTS - 1)))) {
      try {
        await unlink(join(dir, stale.name));
      } catch (err) {
        log(`worker log retention could not remove ${stale.name}: ${err.message}`);
      }
    }

    const attempt = attempts.length ? attempts.at(-1).attempt + 1 : 1;
    return join(dir, `${id.role}-${id.number}.${attempt}.log`);
  }

  // The newest recorded attempt for a worker, with its tail already bounded and
  // redacted. `null` when there is nothing to show — including on any read
  // failure, because diagnostics must never break the poll that surfaces them.
  async function diagnostics(role, number) {
    const id = identity(role, number);
    if (!id) return null;
    try {
      const dir = await logDir();
      const attempts = await existingAttempts(dir, id.role, id.number);
      if (attempts.length === 0) return null;
      const path = join(dir, attempts.at(-1).name);
      return { path, tail: boundedTail(await readFile(path, "utf8")) };
    } catch {
      return null;
    }
  }

  return { prepare, diagnostics };
}
