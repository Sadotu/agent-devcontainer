# Container pause/unpause smoke check

This is a live integration procedure, not an automated test. It proves that
Usage Sentinel pauses and unpauses the **whole orchestrator container** at the
usage thresholds, and that the same supervisor and worker processes continue
afterwards — no session is saved, killed, or reconstructed. Do not claim PASS
unless all evidence below was captured; no run is claimed by this guide.

## External preconditions

- A disposable GitHub issue in a test repository, labels `agent-ready` and
  `agent-running`, GitHub App authentication, and permission to create a
  worktree, branch, and draft PR.
- The agent devcontainer's subscription-authenticated `ccode` alias and tmux. Do
  not replace `ccode` with API-key authentication.
- A real Usage Sentinel deployed from a revision that implements
  `/managed-containers` and Docker-based enforcement (`Sadotu/usage-sentinel`
  issue #44), reachable at `SENTINEL_URL`, with access to the Docker API of the
  host running this container. Record the Sentinel revision and its deployment
  method. Do not use a mock.
- A documented, safe way to move Sentinel's `claude-code` reading from below 95%
  to at or above 95% and back. Either use Sentinel's smoke override
  (`USAGE_SENTINEL_SMOKE_TOKEN` and `PUT /_smoke/usage/claude-code`, which does
  not consume real usage) or the operator's real-telemetry procedure. Record
  which one was used and its exact commands. This repository intentionally
  provides no command for changing Sentinel telemetry.
- A host shell with `docker` access, outside the orchestrator container, for
  every `docker inspect` observation below. The orchestrator container cannot
  observe its own pause.
- Use a repository/container with no pre-existing `orchestrator` tmux session;
  the supervisor's session name is fixed and cleanup below removes that session.

## Procedure

1. In the orchestrator container, create the disposable issue, initialize
   run-specific paths, and record revisions:

   ```bash
   set -euo pipefail
   evidence_dir="$(mktemp -d /tmp/issue-orchestrator-smoke.XXXXXX)"
   issue_url="$(gh issue create \
     --title 'Smoke: container pause and unpause' \
     --body 'Disposable smoke issue. Create the normal worktree and draft PR, make no product changes, then report what remains.')"
   issue="${issue_url##*/}"
   [[ "$issue" =~ ^[1-9][0-9]*$ ]]
   supervisor_log="$evidence_dir/supervisor.log"
   git rev-parse HEAD | tee "$evidence_dir/orchestrator-revision.txt"
   type ccode
   tmux -V
   ! tmux has-session -t orchestrator 2>/dev/null
   curl -fsS "$SENTINEL_URL/usage/claude-code" | tee "$evidence_dir/usage-before.json"
   ```

   The reading must be `status: "ok"` with numeric `windows.short.usedPercent`
   and `windows.long.usedPercent` **below 95**.

2. Record the container this run must register, straight from the kernel view
   the supervisor itself uses:

   ```bash
   grep -o '/containers/[0-9a-f]\{64\}/' /proc/self/mountinfo | head -1 \
     | grep -o '[0-9a-f]\{64\}' | tee "$evidence_dir/container-id.txt"
   ```

   The second `grep` must extract the ID rather than strip characters: the
   literal path segment `/containers/` itself contains `c`, `a`, and `e`, so a
   filter such as `tr -dc '0-9a-f'` prepends `cae` to the ID and Sentinel
   answers `400 invalid container ID`. Confirm the file holds exactly 64
   characters:

   ```bash
   test "$(wc -c <"$evidence_dir/container-id.txt")" -eq 65   # 64 hex + newline
   ```

3. Label the issue and start the supervisor in a dedicated foreground terminal,
   leaving the pipeline running so its timestamped logs are preserved:

   ```bash
   gh issue edit "$issue" --add-label agent-ready
   POLL_MS=1000 issue-orchestrator 2>&1 | tee "$supervisor_log"
   ```

   In the control terminal, confirm the startup lease line names the **exact**
   64-hex ID from step 2, and that the worker window exists:

   ```bash
   grep -F "Managed container lease registered for $(cat "$evidence_dir/container-id.txt")" "$supervisor_log"
   tmux list-panes -t orchestrator -a -F '#{window_name} #{pane_pid}' \
     | tee "$evidence_dir/panes-before-pause.tsv"
   ```

   Capture the issue number, draft PR URL, worktree path, and the `issue-<n>`
   window with its pane PID. Record Sentinel's registration evidence for that
   container ID using the pre-recorded Sentinel inspection procedure (log line,
   registry file, or API); an assumption based only on orchestrator logs is
   insufficient.

4. From the **host** shell, record the pre-pause Docker state and the live
   process tree of the worker:

   ```bash
   id="$(cat <evidence copied from step 2>)"
   docker inspect -f '{{.Id}} {{.State.Status}} {{.State.Pid}}' "$id" \
     | tee docker-before-pause.txt
   ps -o pid,stat,etime,cmd -p <worker pane PIDs from step 3> | tee ps-before-pause.txt
   ```

   `State.Status` must be `running`, and the worker PIDs must exist.

5. Drive either usage window to at least 95% using the recorded Sentinel
   procedure, then, from the host, observe the pause:

   ```bash
   docker inspect -f '{{.Id}} {{.State.Status}} {{.State.Pid}}' "$id" \
     | tee docker-paused.txt
   ps -o pid,stat,etime,cmd -p <same worker pane PIDs> | tee ps-paused.txt
   ```

   Required evidence: the same container ID, `State.Status=paused`, an unchanged
   `State.Pid`, and the **same** worker PIDs still present (state `D`/`S`, not
   gone). The supervisor log must show no new lines while paused, and no worker
   was killed, no issue label changed, and no tmux window disappeared.

6. Bring both windows back below 95% with a fresh valid reading, then observe the
   unpause from the host and the continuation inside the container:

   ```bash
   docker inspect -f '{{.Id}} {{.State.Status}} {{.State.Pid}}' "$id" \
     | tee docker-after-unpause.txt
   ps -o pid,stat,etime,cmd -p <same worker pane PIDs> | tee ps-after-unpause.txt
   ```

   ```bash
   tmux list-panes -t orchestrator -a -F '#{window_name} #{pane_pid}' \
     | tee "$evidence_dir/panes-after-unpause.tsv"
   diff "$evidence_dir/panes-before-pause.tsv" "$evidence_dir/panes-after-unpause.tsv"
   tail -n 20 "$supervisor_log"
   ```

   Required evidence: `State.Status=running`, identical container ID and
   `State.Pid`, identical worker PIDs with `etime` spanning the pause, an
   identical pane listing, and supervisor poll lines resuming. The worker must
   continue its issue — not restart it — and its lease must be refreshed again
   after unpause (verify with the Sentinel inspection procedure).

7. Prove no local pause or recovery state exists anywhere:

   ```bash
   grep -rniE "pause record|resume-ack|saved session|ISSUE_ORCHESTRATOR_PAUSE_DIR" \
     "$(git rev-parse --show-toplevel)/bin" "$(git rev-parse --show-toplevel)/src" || echo "no pause machinery"
   find "$(git rev-parse --git-common-dir)" -maxdepth 2 -name paused -o -maxdepth 2 -name '*.resume-ack' | tee "$evidence_dir/no-pause-state.txt"
   ```

   Both must show nothing but the `no pause machinery` line and an empty file.

8. Cleanup:

   ```bash
   docker inspect -f '{{.State.Status}}' "$id"   # host: must be running before cleanup
   ```

   ```bash
   gh pr close <smoke PR number> --delete-branch || true
   gh issue edit "$issue" --remove-label agent-running --remove-label agent-ready || true
   gh issue close "$issue"
   tmux kill-session -t orchestrator
   ```

   Clear any Sentinel smoke override (`DELETE /_smoke/usage/claude-code`), then
   confirm with the Sentinel inspection procedure that the lease for this
   container was removed on the supervisor's clean exit — and that Sentinel would
   have expired it anyway had the exit been abrupt.

## Recording the result

Archive `$evidence_dir` together with the host-side `docker-*.txt` and `ps-*.txt`
files. A PASS requires, in one run: the exact container ID registered at startup,
`running` → `paused` → `running` transitions driven only by the 95% thresholds,
identical supervisor and worker PIDs across the whole sequence, no killed worker,
no label churn, no pause or resume state on disk, and a lease removed on clean
exit. Anything else is a FAIL; report the captured evidence as-is.
