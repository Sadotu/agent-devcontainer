import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, sep } from "node:path";
import {
  KEEP_ATTEMPTS, LOG_DIR_NAME, TAIL_CHARS, TAIL_LINES,
  createWorkerLogs, redactSecrets,
} from "../src/workerLogs.mjs";

// A git stub that answers `rev-parse --git-common-dir` with a real temp dir, so
// path building and retention are exercised against an actual filesystem.
function gitStub(gitCommonDir, { calls = [] } = {}) {
  return async function exec(file, args) {
    calls.push([file, ...args]);
    if (file === "git" && args[1] === "--git-common-dir") return { stdout: `${gitCommonDir}\n` };
    throw new Error(`unexpected exec: ${file} ${args.join(" ")}`);
  };
}

async function tempGitDir() {
  return mkdtemp(join(tmpdir(), "worker-logs-"));
}

const logDirOf = (gitCommonDir) => join(gitCommonDir, LOG_DIR_NAME);

// ---------------------------------------------------------------------------
// redaction
// ---------------------------------------------------------------------------
test("redactSecrets removes every GitHub token shape", () => {
  const text = [
    "using ghp_AbCdEf0123456789AbCdEf0123456789abcd",
    "oauth gho_AbCdEf0123456789AbCdEf0123456789abcd",
    "user ghu_AbCdEf0123456789AbCdEf0123456789abcd",
    "server ghs_AbCdEf0123456789AbCdEf0123456789abcd",
    "refresh ghr_AbCdEf0123456789AbCdEf0123456789abcd",
    "fine-grained github_pat_11ABCDEFG0abcdefghijkl_XyZ0123456789",
  ].join("\n");
  const out = redactSecrets(text);
  assert.equal(out.includes("[REDACTED]"), true);
  for (const secret of ["ghp_", "gho_", "ghu_", "ghs_", "ghr_", "github_pat_"]) {
    assert.equal(out.includes(secret), false, `${secret} survived redaction`);
  }
  assert.equal(out.split("\n").length, 6, "redaction must not drop lines");
});

test("redactSecrets removes authorization headers and clone-URL credentials", () => {
  const out = redactSecrets([
    "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature",
    "authorization: token 1234567890abcdef",
    "git push https://x-access-token:v1.9f8e7d6c5b4a@github.com/Sadotu/issue-orchestrator",
  ].join("\n"));
  assert.equal(out.includes("eyJhbGciOiJIUzI1NiJ9"), false);
  assert.equal(out.includes("1234567890abcdef"), false);
  assert.equal(out.includes("v1.9f8e7d6c5b4a"), false);
  assert.equal(out.includes("github.com/Sadotu/issue-orchestrator"), true, "non-secret context is kept");
});

test("redactSecrets removes PEM private key blocks entirely", () => {
  const out = redactSecrets([
    "loading key",
    "-----BEGIN RSA PRIVATE KEY-----",
    "MIIEowIBAAKCAQEAx3Nq2K",
    "9f8e7d6c5b4a3f2e1d0c9b",
    "-----END RSA PRIVATE KEY-----",
    "done",
  ].join("\n"));
  assert.equal(out.includes("MIIEowIBAAKCAQEAx3Nq2K"), false);
  assert.equal(out.includes("PRIVATE KEY"), false);
  assert.equal(out.includes("loading key"), true);
  assert.equal(out.includes("done"), true);
});

test("redactSecrets removes an unterminated PEM private key block", () => {
  const out = redactSecrets([
    "loading key",
    "-----BEGIN RSA PRIVATE KEY-----",
    "MIIEowIBAAKCAQEAx3Nq2K",
    "9f8e7d6c5b4a3f2e1d0c9b",
  ].join("\n"));
  assert.equal(out.includes("MIIEowIBAAKCAQEAx3Nq2K"), false);
  assert.equal(out.includes("9f8e7d6c5b4a3f2e1d0c9b"), false);
  assert.equal(out.includes("PRIVATE KEY"), false);
  assert.equal(out.includes("loading key"), true);
});

test("redactSecrets removes secret-like environment assignments", () => {
  const out = redactSecrets([
    "GH_TOKEN=ghs_notarealtokenvalue0123456789",
    "SENTINEL_SECRET: hunter2hunter2",
    "APP_PRIVATE_KEY=\"-inline-key-material-\"",
    "DB_PASSWORD='p@ssw0rd'",
    "AWS_CREDENTIAL=abc123def456",
  ].join("\n"));
  for (const secret of ["ghs_notarealtoken", "hunter2hunter2", "-inline-key-material-", "p@ssw0rd", "abc123def456"]) {
    assert.equal(out.includes(secret), false, `${secret} survived redaction`);
  }
  assert.equal(out.includes("GH_TOKEN="), true, "the variable name is kept as a diagnostic");
});

test("redactSecrets removes an unquoted secret value containing spaces", () => {
  const out = redactSecrets([
    "GH_TOKEN=my secret value",
    "DB_PASSWORD='p@ssw0rd' trailing note",
    "Error: cannot open PR for issue 71",
  ].join("\n"));
  assert.equal(out.includes("secret value"), false, "the rest of the line is redacted");
  assert.equal(out.includes("GH_TOKEN="), true, "the variable name is kept as a diagnostic");
  assert.equal(out.includes("p@ssw0rd"), false, "a quoted value still redacts as before");
  assert.equal(out.includes("trailing note"), true, "a quoted value still stops at its closing quote");
  // The rest-of-line rule must be line-scoped: a following non-secret line is
  // not part of the assignment and must survive intact.
  assert.equal(out.includes("Error: cannot open PR for issue 71"), true);
});

test("redactSecrets leaves ordinary diagnostic output untouched", () => {
  const text = [
    "Error: cannot open PR for issue 71",
    "  at runOnce (bin/supervisor.mjs:404:7)",
    "key: value pairs in yaml stay readable",
    "monkey business as usual",
  ].join("\n");
  assert.equal(redactSecrets(text), text);
});

// ---------------------------------------------------------------------------
// prepare — path construction and validation
// ---------------------------------------------------------------------------
test("prepare builds a role- and issue-named log inside the git common dir", async () => {
  const gitDir = await tempGitDir();
  const logs = logsFor(gitDir);
  assert.equal(await logs.prepare("issue", 71), join(logDirOf(gitDir), "issue-71.1.log"));
  assert.equal(await logs.prepare("review", 71), join(logDirOf(gitDir), "review-71.1.log"));
});

test("prepare resolves a relative git common dir against the supervisor cwd", async () => {
  const gitDir = await tempGitDir();
  const exec = async (file, args) => {
    if (file === "git" && args[1] === "--git-common-dir") return { stdout: ".git\n" };
    throw new Error("unexpected exec");
  };
  const logs = createWorkerLogs({ exec, cwd: gitDir });
  assert.equal(
    await logs.prepare("issue", 71),
    join(gitDir, ".git", LOG_DIR_NAME, "issue-71.1.log"),
  );
});

test("prepare resolves the git common dir once and reuses it", async () => {
  const gitDir = await tempGitDir();
  const calls = [];
  const logs = createWorkerLogs({ exec: gitStub(gitDir, { calls }) });
  await logs.prepare("issue", 1);
  await logs.prepare("review", 2);
  await logs.prepare("issue", 3);
  assert.equal(calls.length, 1);
});

test("prepare refuses an unknown role and never touches the filesystem", async () => {
  const gitDir = await tempGitDir();
  const messages = [];
  const logs = createWorkerLogs({ exec: gitStub(gitDir), log: (m) => messages.push(m) });
  assert.equal(await logs.prepare("../../etc", 71), null);
  assert.equal(await logs.prepare("repair", 71), null);
  await assert.rejects(() => readdir(logDirOf(gitDir)));
  assert.equal(messages.length, 2);
});

test("prepare refuses a number that is not a positive integer", async () => {
  const gitDir = await tempGitDir();
  const logs = logsFor(gitDir);
  for (const bad of ['71" && rm -rf /', "../71", 0, -3, 7.5, "abc", null, undefined]) {
    assert.equal(await logs.prepare("issue", bad), null, `accepted ${String(bad)}`);
  }
  await assert.rejects(() => readdir(logDirOf(gitDir)));
});

test("prepare keeps the log directory inside the git common dir", async () => {
  const gitDir = await tempGitDir();
  const logs = logsFor(gitDir);
  const path = await logs.prepare("issue", 71);
  assert.equal(path.startsWith(gitDir + sep), true);
  assert.equal(path.includes(`${sep}${LOG_DIR_NAME}${sep}`), true);
});

// ---------------------------------------------------------------------------
// prepare — attempt numbering and retention
// ---------------------------------------------------------------------------
async function seedAttempts(gitDir, names) {
  const dir = logDirOf(gitDir);
  const logs = createWorkerLogs({ exec: gitStub(gitDir) });
  await logs.prepare("issue", 999); // creates the directory
  for (const name of names) await writeFile(join(dir, name), `${name} contents\n`);
  return dir;
}

test("prepare allocates the next attempt without overwriting earlier ones", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["issue-71.1.log", "issue-71.2.log"]);
  const logs = logsFor(gitDir);
  assert.equal(await logs.prepare("issue", 71), join(dir, "issue-71.3.log"));
  const remaining = (await readdir(dir)).filter((n) => n.startsWith("issue-71."));
  assert.deepEqual(remaining.sort(), ["issue-71.1.log", "issue-71.2.log"]);
});

test("prepare prunes to the retained attempt bound, keeping the newest", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, [
    "issue-71.1.log", "issue-71.2.log", "issue-71.3.log", "issue-71.4.log",
  ]);
  const logs = logsFor(gitDir);
  assert.equal(await logs.prepare("issue", 71), join(dir, "issue-71.5.log"));
  const remaining = (await readdir(dir)).filter((n) => n.startsWith("issue-71.")).sort();
  // The two survivors plus the attempt about to be written equal the bound.
  assert.deepEqual(remaining, ["issue-71.3.log", "issue-71.4.log"]);
  assert.equal(remaining.length + 1, KEEP_ATTEMPTS);
});

test("prepare prunes only the same role and issue", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, [
    "issue-71.1.log", "issue-71.2.log", "issue-71.3.log",
    "review-71.1.log", "issue-7.1.log", "issue-712.1.log", "notes.txt",
  ]);
  const logs = logsFor(gitDir);
  await logs.prepare("issue", 71);
  const remaining = (await readdir(dir)).sort();
  assert.equal(remaining.includes("review-71.1.log"), true);
  assert.equal(remaining.includes("issue-7.1.log"), true);
  assert.equal(remaining.includes("issue-712.1.log"), true);
  assert.equal(remaining.includes("notes.txt"), true);
  assert.equal(remaining.includes("issue-71.1.log"), false);
});

test("prepare ignores filenames that are not attempts of this worker", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["issue-71.log", "issue-71.x.log", "issue-71.2.log.bak"]);
  const logs = logsFor(gitDir);
  assert.equal(await logs.prepare("issue", 71), join(dir, "issue-71.1.log"));
});

// ---------------------------------------------------------------------------
// prepare — best-effort failure handling
// ---------------------------------------------------------------------------
test("prepare returns null and reports when the log directory cannot be created", async () => {
  const messages = [];
  const logs = createWorkerLogs({
    exec: gitStub("/nowhere"),
    fs: { mkdir: async () => { throw new Error("EACCES: permission denied"); } },
    log: (m) => messages.push(m),
  });
  assert.equal(await logs.prepare("issue", 71), null);
  assert.match(messages.join("\n"), /permission denied/);
});

test("prepare returns null when the git common dir cannot be resolved", async () => {
  const messages = [];
  const logs = createWorkerLogs({
    exec: async () => { throw new Error("not a git repository"); },
    log: (m) => messages.push(m),
  });
  assert.equal(await logs.prepare("issue", 71), null);
  assert.match(messages.join("\n"), /not a git repository/);
});

test("prepare returns null when existing attempts cannot be listed", async () => {
  const logs = createWorkerLogs({
    exec: gitStub("/nowhere"),
    fs: { mkdir: async () => {}, readdir: async () => { throw new Error("EIO"); } },
  });
  assert.equal(await logs.prepare("issue", 71), null);
});

test("prepare still returns the new path when pruning fails", async () => {
  const messages = [];
  const logs = createWorkerLogs({
    exec: gitStub("/nowhere"),
    fs: {
      mkdir: async () => {},
      readdir: async () => ["issue-71.1.log", "issue-71.2.log", "issue-71.3.log"],
      unlink: async () => { throw new Error("EBUSY"); },
    },
    log: (m) => messages.push(m),
  });
  assert.equal(await logs.prepare("issue", 71), join("/nowhere", LOG_DIR_NAME, "issue-71.4.log"));
  assert.match(messages.join("\n"), /EBUSY/);
});

// ---------------------------------------------------------------------------
// diagnostics
// ---------------------------------------------------------------------------
test("diagnostics returns the newest attempt with a bounded tail", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["issue-71.1.log", "issue-71.2.log"]);
  await writeFile(join(dir, "issue-71.2.log"), "first\nsecond\nthird\n");
  const logs = logsFor(gitDir);
  const info = await logs.diagnostics("issue", 71);
  assert.equal(info.path, join(dir, "issue-71.2.log"));
  assert.equal(info.tail, "first\nsecond\nthird");
});

test("diagnostics bounds the tail to the last lines of a long log", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["review-41.1.log"]);
  const lines = Array.from({ length: TAIL_LINES + 25 }, (_, i) => `line ${i + 1}`);
  await writeFile(join(dir, "review-41.1.log"), `${lines.join("\n")}\n`);
  const info = await logsFor(gitDir).diagnostics("review", 41);
  const tailLines = info.tail.split("\n");
  assert.equal(tailLines.length, TAIL_LINES);
  assert.equal(tailLines.at(-1), `line ${lines.length}`);
  assert.equal(tailLines[0], `line ${lines.length - TAIL_LINES + 1}`);
});

test("diagnostics truncates an oversized tail from the front", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["issue-71.1.log"]);
  const lines = Array.from({ length: 10 }, (_, i) => `${i}`.padEnd(1000, "x"));
  await writeFile(join(dir, "issue-71.1.log"), `${lines.join("\n")}\n`);
  const info = await logsFor(gitDir).diagnostics("issue", 71);
  assert.equal(info.tail.length <= TAIL_CHARS, true);
  assert.equal(info.tail.endsWith(lines.at(-1)), true, "the end of the log is what is kept");
});

test("diagnostics redacts secret-like values from the tail", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["issue-71.1.log"]);
  await writeFile(
    join(dir, "issue-71.1.log"),
    "cloning with ghs_fixturetokenvalue0123456789abcd\nGH_TOKEN=ghp_anotherfixturevalue0123456789\nfailed\n",
  );
  const info = await logsFor(gitDir).diagnostics("issue", 71);
  assert.equal(info.tail.includes("ghs_fixturetokenvalue"), false);
  assert.equal(info.tail.includes("ghp_anotherfixturevalue"), false);
  assert.equal(info.tail.includes("failed"), true);
});

// The character bound cuts from the front, so a secret straddling that cut
// would lose the prefix its pattern keys on and survive as a remnant. Sized so
// the cut lands five characters into the token.
test("diagnostics does not leak a secret split by the character bound", async () => {
  const gitDir = await tempGitDir();
  const dir = await seedAttempts(gitDir, ["issue-71.1.log"]);
  const token = `ghs_S3cr3tValu3${"0".repeat(25)}`;
  const prefix = `${"x".repeat(99)} `; // 100 chars, the last a separator so the token starts a word
  const after = "y".repeat(3964); // sized so the cut index is exactly prefix.length + 5
  await writeFile(join(dir, "issue-71.1.log"), `${prefix}${token}\n${after}\n`);
  const info = await logsFor(gitDir).diagnostics("issue", 71);
  assert.equal(info.tail.includes("3cr3tValu3"), false, "the split token's remnant survived");
  assert.equal(info.tail.length <= TAIL_CHARS, true);
  assert.equal(info.tail.endsWith("y"), true, "the end of the log is still what is kept");
});

test("diagnostics returns null when no attempt exists or the read fails", async () => {
  const gitDir = await tempGitDir();
  await seedAttempts(gitDir, []);
  assert.equal(await logsFor(gitDir).diagnostics("issue", 71), null);

  const failing = createWorkerLogs({
    exec: gitStub("/nowhere"),
    fs: { readdir: async () => ["issue-71.1.log"], readFile: async () => { throw new Error("EIO"); } },
  });
  assert.equal(await failing.diagnostics("issue", 71), null);
});

test("diagnostics refuses an invalid role or number", async () => {
  const gitDir = await tempGitDir();
  await seedAttempts(gitDir, ["issue-71.1.log"]);
  assert.equal(await logsFor(gitDir).diagnostics("../etc", 71), null);
  assert.equal(await logsFor(gitDir).diagnostics("issue", "71; rm -rf /"), null);
});

function logsFor(gitDir) {
  return createWorkerLogs({ exec: gitStub(gitDir) });
}
