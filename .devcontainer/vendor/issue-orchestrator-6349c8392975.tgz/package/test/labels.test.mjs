import { test } from "node:test";
import assert from "node:assert/strict";
import {
  BLOCKED, MERGE_REVIEW, PHASE_LABELS, REQUIRED_LABELS, REVIEW, RUNNING,
  ensureLabels, phaseOf,
} from "../src/labels.mjs";

function harness({ existing = [], createImpl } = {}) {
  const created = [];
  return {
    created,
    listLabels: async () => existing.map((name) => ({ name })),
    createLabel: async (label) => {
      created.push(label);
      if (createImpl) return createImpl(label, created.length);
    },
  };
}

test("REQUIRED_LABELS carries the exact names and colours from the issue", () => {
  assert.deepEqual(REQUIRED_LABELS.map((l) => [l.name, l.color]), [
    ["agent-ready", "0e8a16"],
    ["agent-running", "1d76db"],
    ["agent-review", "5319e7"],
    ["agent-blocked", "d73a4a"],
    ["user-merge-review", "fbca04"],
  ]);
  for (const label of REQUIRED_LABELS) assert.ok(label.description.length > 0);
});

test("phaseOf returns the single active phase label, or null", () => {
  assert.equal(phaseOf(["agent-running", REVIEW]), REVIEW);
  assert.equal(phaseOf(["agent-running"]), null);
  assert.deepEqual(PHASE_LABELS, [REVIEW, BLOCKED, MERGE_REVIEW]);
});

test("phaseOf prefers the earliest declared phase when several are present", () => {
  assert.equal(phaseOf([MERGE_REVIEW, REVIEW]), REVIEW);
});

test("ensureLabels on an empty repository creates every label", async () => {
  const h = harness();
  const result = await ensureLabels(h);
  assert.deepEqual(result.created, REQUIRED_LABELS.map((l) => l.name));
  assert.deepEqual(result.existing, []);
  assert.deepEqual(h.created, REQUIRED_LABELS);
});

test("ensureLabels creates only the missing labels and never touches existing ones", async () => {
  const h = harness({ existing: ["agent-ready", "agent-review"] });
  const result = await ensureLabels(h);
  assert.deepEqual(result.created, [RUNNING, BLOCKED, MERGE_REVIEW]);
  assert.deepEqual(result.existing, ["agent-ready", "agent-review"]);
  assert.deepEqual(h.created.map((l) => l.name), [RUNNING, BLOCKED, MERGE_REVIEW]);
});

test("ensureLabels on a complete repository creates nothing", async () => {
  const h = harness({ existing: REQUIRED_LABELS.map((l) => l.name) });
  const result = await ensureLabels(h);
  assert.deepEqual(result.created, []);
  assert.deepEqual(h.created, []);
});

test("ensureLabels ignores label-name case when matching existing labels", async () => {
  const h = harness({ existing: ["Agent-Ready"] });
  const result = await ensureLabels(h);
  assert.ok(!result.created.includes("agent-ready"));
  assert.deepEqual(result.existing, ["Agent-Ready"]);
});

test("ensureLabels propagates an authentication failure from listing", async () => {
  const h = harness();
  h.listLabels = async () => { throw new Error("HTTP 401: Bad credentials"); };
  await assert.rejects(() => ensureLabels(h), /label bootstrap failed: HTTP 401/);
});

test("ensureLabels propagates a permission failure from creation", async () => {
  const h = harness({
    createImpl: (label) => { throw new Error(`HTTP 403 creating ${label.name}`); },
  });
  await assert.rejects(() => ensureLabels(h), /label bootstrap failed: HTTP 403/);
});

test("ensureLabels treats a concurrent creator's 'already exists' as success", async () => {
  const h = harness({
    createImpl: (label) => {
      if (label.name === RUNNING) throw new Error('label with name "agent-running" already exists');
    },
  });
  const result = await ensureLabels(h);
  assert.deepEqual(result.created, REQUIRED_LABELS.map((l) => l.name));
});

test("ensureLabels retries only what is still missing after a partial creation", async () => {
  // First run dies after creating agent-ready and agent-running.
  const first = harness({
    createImpl: (label) => {
      if (label.name === REVIEW) throw new Error("HTTP 500 gateway");
    },
  });
  await assert.rejects(() => ensureLabels(first), /HTTP 500/);
  assert.deepEqual(first.created.map((l) => l.name), ["agent-ready", RUNNING, REVIEW]);

  // Second run sees the two that landed and creates only the remaining three.
  const second = harness({ existing: ["agent-ready", RUNNING] });
  const result = await ensureLabels(second);
  assert.deepEqual(result.created, [REVIEW, BLOCKED, MERGE_REVIEW]);
});
