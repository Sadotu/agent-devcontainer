import { test } from "node:test";
import assert from "node:assert/strict";
import {
  MARKER_TAG, computeFingerprint, parseReviewMarkers, selectApplicableMarker,
} from "../src/reviewMarker.mjs";

const HEAD = "a".repeat(40);
const BASE = "b".repeat(40);
const ISSUE_BODY = "Issue body\n";
const PR_BODY = "PR body\n";
// Golden digest produced by the shipped producer algorithm itself:
//   printf '%s\x1e%s\x1e%s\x1e%s' <head> <base> 'Issue body' 'PR body' | sha256sum
const FINGERPRINT = "26f7b8e6a52a81d78ef04602e559159747e63c25764b912cb12e0a3eb47eb885";

const LIVE = { issue: 22, pr: 24, head: HEAD, base: BASE, issueBody: ISSUE_BODY, prBody: PR_BODY };

// The literal shape emitted by review-pr/scripts/publish-review.sh: one line,
// compact JSON, jq key order.
function producerMarker(overrides = {}) {
  const payload = {
    fingerprint: FINGERPRINT, head: HEAD, base: BASE,
    issueUpdatedAt: "2026-08-01T10:00:00Z", prUpdatedAt: "2026-08-01T10:05:00Z",
    issue: 22, pr: 24, pass: 1, verdict: "PASS", ...overrides,
  };
  return `<!-- review-pr:v1 ${JSON.stringify(payload)} -->`;
}

const own = (body) => ({ body, viewerDidAuthor: true });

test("MARKER_TAG is the producer's tag", () => {
  assert.equal(MARKER_TAG, "review-pr:v1");
});

test("computeFingerprint reproduces the producer's sha256 over 0x1e-joined inputs", () => {
  assert.equal(
    computeFingerprint({ head: HEAD, base: BASE, issueBody: ISSUE_BODY, prBody: PR_BODY }),
    FINGERPRINT,
  );
});

test("computeFingerprint strips trailing newlines exactly as command substitution does", () => {
  const bare = computeFingerprint({ head: HEAD, base: BASE, issueBody: "Issue body", prBody: "PR body" });
  assert.equal(bare, FINGERPRINT);
  const many = computeFingerprint({ head: HEAD, base: BASE, issueBody: "Issue body\n\n\n", prBody: "PR body\n" });
  assert.equal(many, FINGERPRINT);
});

test("computeFingerprint keeps a trailing CR, which the producer's shell also keeps", () => {
  const crlf = computeFingerprint({ head: HEAD, base: BASE, issueBody: "Issue body\r\n", prBody: "PR body\n" });
  assert.notEqual(crlf, FINGERPRINT);
});

test("computeFingerprint separates fields so concatenation cannot collide", () => {
  const a = computeFingerprint({ head: HEAD, base: BASE, issueBody: "ab", prBody: "c" });
  const b = computeFingerprint({ head: HEAD, base: BASE, issueBody: "a", prBody: "bc" });
  assert.notEqual(a, b);
});

test("parseReviewMarkers reads the literal producer marker out of a full comment body", () => {
  const body = `## Review pass 1\n\nFindings...\n\n${producerMarker()}\n`;
  assert.deepEqual(parseReviewMarkers(body), [{
    fingerprint: FINGERPRINT, head: HEAD, base: BASE,
    issueUpdatedAt: "2026-08-01T10:00:00Z", prUpdatedAt: "2026-08-01T10:05:00Z",
    issue: 22, pr: 24, pass: 1, verdict: "PASS",
  }]);
});

test("parseReviewMarkers tolerates CRLF line endings from a web-UI edit", () => {
  const body = `Findings...\r\n\r\n${producerMarker()}\r\n`;
  assert.equal(parseReviewMarkers(body)[0].verdict, "PASS");
});

test("parseReviewMarkers ignores an unsupported marker version", () => {
  const body = producerMarker().replace("review-pr:v1", "review-pr:v2");
  assert.deepEqual(parseReviewMarkers(body), []);
});

test("parseReviewMarkers ignores a crosslink marker", () => {
  const body = producerMarker().replace("review-pr:v1", "review-pr-crosslink:v1");
  assert.deepEqual(parseReviewMarkers(body), []);
});

test("parseReviewMarkers ignores malformed JSON", () => {
  assert.deepEqual(parseReviewMarkers("<!-- review-pr:v1 {not json} -->"), []);
});

test("parseReviewMarkers ignores an incomplete payload", () => {
  for (const field of [
    "fingerprint", "head", "base", "issueUpdatedAt", "prUpdatedAt", "issue", "pr", "pass", "verdict",
  ]) {
    const payload = JSON.parse(producerMarker().replace(/^<!-- review-pr:v1 /, "").replace(/ -->$/, ""));
    delete payload[field];
    assert.deepEqual(
      parseReviewMarkers(`<!-- review-pr:v1 ${JSON.stringify(payload)} -->`), [],
      `missing ${field} must be rejected`,
    );
  }
});

test("parseReviewMarkers ignores ill-typed numeric fields", () => {
  assert.deepEqual(parseReviewMarkers(producerMarker({ pr: "24" })), []);
  assert.deepEqual(parseReviewMarkers(producerMarker({ pass: 1.5 })), []);
});

test("parseReviewMarkers keeps an unrecognised verdict for the caller to fail closed on", () => {
  assert.equal(parseReviewMarkers(producerMarker({ verdict: "pass" }))[0].verdict, "pass");
});

test("parseReviewMarkers returns every marker in a body, in order", () => {
  const body = [producerMarker({ pass: 1 }), producerMarker({ pass: 2, verdict: "BLOCKING" })].join("\n\n");
  assert.deepEqual(parseReviewMarkers(body).map((m) => m.pass), [1, 2]);
});

test("selectApplicableMarker accepts the producer's own fresh marker", () => {
  assert.equal(selectApplicableMarker([own(producerMarker())], LIVE).verdict, "PASS");
});

test("selectApplicableMarker ignores a marker authored by anyone else", () => {
  assert.equal(selectApplicableMarker([{ body: producerMarker(), viewerDidAuthor: false }], LIVE), null);
  assert.equal(selectApplicableMarker([{ body: producerMarker() }], LIVE), null);
});

test("selectApplicableMarker ignores a marker naming another issue or PR", () => {
  assert.equal(selectApplicableMarker([own(producerMarker({ issue: 23 }))], LIVE), null);
  assert.equal(selectApplicableMarker([own(producerMarker({ pr: 25 }))], LIVE), null);
});

test("selectApplicableMarker ignores a forged fingerprint", () => {
  assert.equal(selectApplicableMarker([own(producerMarker({ fingerprint: "0".repeat(64) }))], LIVE), null);
});

test("selectApplicableMarker goes stale on a head, base, issue-body, or PR-body change", () => {
  const comments = [own(producerMarker())];
  assert.equal(selectApplicableMarker(comments, { ...LIVE, head: "c".repeat(40) }), null);
  assert.equal(selectApplicableMarker(comments, { ...LIVE, base: "d".repeat(40) }), null);
  assert.equal(selectApplicableMarker(comments, { ...LIVE, issueBody: "Issue body edited\n" }), null);
  assert.equal(selectApplicableMarker(comments, { ...LIVE, prBody: "PR body edited\n" }), null);
});

test("selectApplicableMarker survives a comment that only moved prUpdatedAt", () => {
  const comments = [own(producerMarker({ prUpdatedAt: "2026-08-01T09:00:00Z" })), own("Just a comment")];
  assert.equal(selectApplicableMarker(comments, LIVE).verdict, "PASS");
});

test("selectApplicableMarker takes the last applicable marker when several match", () => {
  const comments = [own(producerMarker({ pass: 1 })), own(producerMarker({ pass: 2, verdict: "BLOCKING" }))];
  assert.equal(selectApplicableMarker(comments, LIVE).verdict, "BLOCKING");
});

test("selectApplicableMarker prefers an older matching marker over a newer stale one", () => {
  const comments = [
    own(producerMarker()),
    own(producerMarker({ fingerprint: "f".repeat(64), verdict: "BLOCKING" })),
  ];
  assert.equal(selectApplicableMarker(comments, LIVE).verdict, "PASS");
});

test("selectApplicableMarker returns null when the reviewer posted nothing (crash)", () => {
  assert.equal(selectApplicableMarker([own("I ran out of context")], LIVE), null);
  assert.equal(selectApplicableMarker([], LIVE), null);
});
