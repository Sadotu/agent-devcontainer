import { test } from "node:test";
import assert from "node:assert/strict";
import { createManagedContainerClient, resolveContainerId } from "../src/managedContainer.mjs";

const ID = "a".repeat(64);
const MOUNTINFO = [
  "1697 1610 0:394 / / rw,relatime - overlay overlay rw",
  `1709 1698 8:80 /data/docker/containers/${ID}/resolv.conf /etc/resolv.conf rw,relatime - ext4 /dev/sdf rw`,
  `1710 1698 8:80 /data/docker/containers/${ID}/hostname /etc/hostname rw,relatime - ext4 /dev/sdf rw`,
  "",
].join("\n");

test("resolveContainerId reads the full 64-hex ID from mountinfo", async () => {
  const read = [];
  const id = await resolveContainerId({
    readFileImpl: async (path, encoding) => {
      read.push([path, encoding]);
      return MOUNTINFO;
    },
  });
  assert.equal(id, ID);
  assert.deepEqual(read, [["/proc/self/mountinfo", "utf8"]]);
});

test("resolveContainerId rejects when no container mount is present", async () => {
  await assert.rejects(
    resolveContainerId({ readFileImpl: async () => "1697 1610 0:394 / / rw - overlay overlay rw\n" }),
    /cannot resolve the current Docker container ID/,
  );
});

test("resolveContainerId rejects ambiguous container IDs", async () => {
  const other = "b".repeat(64);
  const raw = `${MOUNTINFO}1711 1698 8:80 /data/docker/containers/${other}/hosts /etc/hosts rw - ext4 /dev/sdf rw\n`;
  await assert.rejects(resolveContainerId({ readFileImpl: async () => raw }), /ambiguous/);
});

test("resolveContainerId propagates an unreadable mountinfo", async () => {
  await assert.rejects(
    resolveContainerId({ readFileImpl: async () => { throw new Error("EACCES"); } }),
    /EACCES/,
  );
});

test("register PUTs the exact ID and reports a new lease", async () => {
  const calls = [];
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async (url, options) => {
      calls.push([url, options.method]);
      return { status: 201, json: async () => ({ containerId: ID, status: "registered" }) };
    },
  });
  assert.deepEqual(await client.register(ID), { status: "registered" });
  assert.deepEqual(calls, [[`http://usage-sentinel:4317/managed-containers/${ID}`, "PUT"]]);
});

test("register reports a refreshed lease on 200", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317/",
    fetchImpl: async () => ({ status: 200, json: async () => ({ containerId: ID, status: "refreshed" }) }),
  });
  assert.deepEqual(await client.register(ID), { status: "refreshed" });
});

test("register rejects an unexpected status without inventing an admission decision", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => ({ status: 400, json: async () => ({ error: "invalid container ID" }) }),
  });
  await assert.rejects(client.register(ID), /unexpected managed-container registration status 400/);
});

test("register rejects a malformed body", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => ({ status: 201, json: async () => ({ status: "nonsense" }) }),
  });
  await assert.rejects(client.register(ID), /invalid managed-container registration response/);
});

test("register rejects unparseable JSON", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => ({ status: 201, json: async () => { throw new Error("Unexpected end of JSON input"); } }),
  });
  await assert.rejects(client.register(ID), /invalid managed-container registration response/);
});

test("register rejects a response object without a status", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => undefined,
  });
  await assert.rejects(client.register(ID), /sentinel returned no response/);
});

test("register rejects an unreachable Sentinel", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => { throw new Error("ECONNREFUSED"); },
  });
  await assert.rejects(client.register(ID), /sentinel unreachable: ECONNREFUSED/);
});

test("register times out instead of stalling the poll", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    timeoutMs: 5,
    fetchImpl: (_url, options) => new Promise((_resolve, reject) => {
      options.signal.addEventListener("abort", () => reject(new Error("aborted")));
    }),
  });
  await assert.rejects(client.register(ID), /sentinel request timed out/);
});

test("register times out when the headers arrive but the body never does", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    timeoutMs: 5,
    // Sentinel answers with headers, then stalls or disconnects mid-body. The
    // deadline must still fire: a hung body would otherwise stall the poll loop.
    fetchImpl: async () => ({ status: 201, json: () => new Promise(() => {}) }),
  });
  await assert.rejects(client.register(ID), /sentinel request timed out/);
});

test("register reports a malformed body as invalid, not as a timeout", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    timeoutMs: 5000,
    fetchImpl: async () => ({ status: 201, json: async () => { throw new Error("Unexpected token <"); } }),
  });
  await assert.rejects(client.register(ID), /invalid managed-container registration response/);
});

test("unregister DELETEs the lease and accepts 204", async () => {
  const calls = [];
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async (url, options) => {
      calls.push([url, options.method]);
      return { status: 204 };
    },
  });
  await client.unregister(ID);
  assert.deepEqual(calls, [[`http://usage-sentinel:4317/managed-containers/${ID}`, "DELETE"]]);
});

test("unregister rejects an unexpected status", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => ({ status: 500 }),
  });
  await assert.rejects(client.unregister(ID), /unexpected managed-container deletion status 500/);
});

test("both operations reject an ID that is not a full 64-hex container ID", async () => {
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async () => { throw new Error("must not be called"); },
  });
  for (const bad of ["907008dccf1f", `${ID}/../usage`, "A".repeat(64), "", undefined]) {
    await assert.rejects(client.register(bad), /invalid container ID/);
    await assert.rejects(client.unregister(bad), /invalid container ID/);
  }
});

test("the client requests no usage or worker-admission endpoint", async () => {
  const urls = [];
  const client = createManagedContainerClient({
    url: "http://usage-sentinel:4317",
    fetchImpl: async (url) => {
      urls.push(url);
      return { status: 201, json: async () => ({ status: "registered" }) };
    },
  });
  await client.register(ID);
  const paths = urls.map((url) => new URL(url).pathname);
  assert.deepEqual(paths, [`/managed-containers/${ID}`]);
  assert.ok(paths.every((path) => !/^\/(usage|workers)\b/.test(path)));
});
