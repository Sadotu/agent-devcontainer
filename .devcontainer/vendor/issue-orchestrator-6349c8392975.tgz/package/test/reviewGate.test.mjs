import { test } from "node:test";
import assert from "node:assert/strict";
import { BLOCKED, MERGE_REVIEW, REVIEW, RUNNING } from "../src/labels.mjs";
import {
  applyReviewPlan, classifyChecks, failClosed, failingChecks, mirrorLabels,
  planLabelMirror, planVerdict, resolveManagedPrs, stuckChecks,
} from "../src/reviewGate.mjs";

function issue(number, labels = [RUNNING], updatedAt = "2026-08-01T10:00:00Z") {
  return { number, labels, updatedAt };
}
function pr(number, overrides = {}) {
  return {
    number,
    headRefName: `agent/41-slug`,
    headRefOid: "a".repeat(40),
    baseRefOid: "b".repeat(40),
    isDraft: true,
    url: `https://github.com/o/r/pull/${number}`,
    updatedAt: "2026-08-01T10:05:00Z",
    createdAt: "2026-08-01T09:00:00Z",
    labels: [],
    closingIssuesReferences: [{ number: 41 }],
    statusCheckRollup: [],
    ...overrides,
  };
}

test("resolveManagedPrs pairs an agent-running issue with its closing PR", () => {
  const { managed, problems } = resolveManagedPrs([issue(41)], [pr(72)]);
  assert.equal(managed.length, 1);
  assert.equal(managed[0].issue.number, 41);
  assert.equal(managed[0].pr.number, 72);
  assert.deepEqual(problems, []);
});

test("resolveManagedPrs ignores a PR with no linked agent-running issue", () => {
  const manual = pr(90, { headRefName: "feature/manual", closingIssuesReferences: [{ number: 99 }] });
  const { managed, problems } = resolveManagedPrs([issue(41)], [pr(72), manual]);
  assert.deepEqual(managed.map((m) => m.pr.number), [72]);
  assert.deepEqual(problems, []);
});

test("resolveManagedPrs ignores an unrelated agent/* branch with no closing reference", () => {
  const stray = pr(91, { headRefName: "agent/99-other", closingIssuesReferences: [] });
  const { managed, problems } = resolveManagedPrs([issue(41)], [pr(72), stray]);
  assert.deepEqual(managed.map((m) => m.pr.number), [72]);
  assert.deepEqual(problems, []);
});

test("resolveManagedPrs falls back to the branch prefix when a PR has no closing reference", () => {
  const branchOnly = pr(72, { closingIssuesReferences: [] });
  const { managed, problems } = resolveManagedPrs([issue(41)], [branchOnly]);
  assert.deepEqual(managed.map((m) => m.pr.number), [72]);
  assert.deepEqual(problems, []);
});

test("resolveManagedPrs fails closed when two PRs close the same issue", () => {
  const { managed, problems } = resolveManagedPrs([issue(41)], [pr(72), pr(73)]);
  assert.deepEqual(managed, []);
  assert.equal(problems.length, 1);
  assert.equal(problems[0].reason, "duplicate-linkage");
  assert.equal(problems[0].issue.number, 41);
  assert.equal(problems[0].pr, null);
  assert.match(problems[0].message, /#72/);
  assert.match(problems[0].message, /#73/);
});

test("resolveManagedPrs fails closed when the branch and closing reference disagree", () => {
  const conflicting = pr(72, { headRefName: "agent/77-other", closingIssuesReferences: [{ number: 41 }] });
  const { managed, problems } = resolveManagedPrs([issue(41)], [conflicting]);
  assert.deepEqual(managed, []);
  assert.equal(problems[0].reason, "conflicting-linkage");
  assert.equal(problems[0].pr.number, 72);
  assert.match(problems[0].message, /agent\/77-other/);
});

test("resolveManagedPrs fails closed when an agent-review issue has no PR", () => {
  const { managed, problems } = resolveManagedPrs([issue(41, [RUNNING, REVIEW])], []);
  assert.deepEqual(managed, []);
  assert.equal(problems[0].reason, "missing-linkage");
  assert.equal(problems[0].pr, null);
});

test("resolveManagedPrs does not flag a still-working issue that has no PR yet", () => {
  const { managed, problems } = resolveManagedPrs([issue(41)], []);
  assert.deepEqual(managed, []);
  assert.deepEqual(problems, []);
});

test("resolveManagedPrs does not re-flag an issue already blocked with no PR", () => {
  const { problems } = resolveManagedPrs([issue(41, [RUNNING, BLOCKED])], []);
  assert.deepEqual(problems, []);
});

test("resolveManagedPrs matches closing references by exact number, not superstring", () => {
  const other = pr(72, { headRefName: "agent/410-x", closingIssuesReferences: [{ number: 410 }] });
  const { managed, problems } = resolveManagedPrs([issue(41, [RUNNING, REVIEW])], [other]);
  assert.deepEqual(managed, []);
  assert.equal(problems[0].reason, "missing-linkage");
});

test("resolveManagedPrs returns issues in ascending number order", () => {
  const a = pr(72, { headRefName: "agent/41-a", closingIssuesReferences: [{ number: 41 }] });
  const b = pr(71, { headRefName: "agent/12-b", closingIssuesReferences: [{ number: 12 }] });
  const { managed } = resolveManagedPrs([issue(41), issue(12)], [a, b]);
  assert.deepEqual(managed.map((m) => m.issue.number), [12, 41]);
});

// --- check classification ---------------------------------------------------
const NOW = Date.parse("2026-08-01T12:00:00Z");
const HOUR = 60 * 60 * 1000;
const checkRun = (over) => ({ __typename: "CheckRun", name: "build", status: "COMPLETED", conclusion: "SUCCESS", startedAt: "2026-08-01T10:00:00Z", detailsUrl: "https://ci/1", ...over });
const statusContext = (over) => ({ __typename: "StatusContext", context: "ci/legacy", state: "SUCCESS", createdAt: "2026-08-01T10:00:00Z", targetUrl: "https://ci/2", ...over });

test("classifyChecks treats no configured checks as green", () => {
  assert.equal(classifyChecks([]), "green");
});

test("classifyChecks does not conflate absent data with no checks", () => {
  assert.equal(classifyChecks(null), "unknown");
  assert.equal(classifyChecks(undefined), "unknown");
  assert.equal(classifyChecks("not an array"), "unknown");
});

test("classifyChecks is green when every check run succeeded, was neutral, or was skipped", () => {
  assert.equal(classifyChecks([
    checkRun({ conclusion: "SUCCESS" }),
    checkRun({ name: "lint", conclusion: "NEUTRAL" }),
    checkRun({ name: "e2e", conclusion: "SKIPPED" }),
  ]), "green");
});

test("classifyChecks is pending while any check has not completed", () => {
  for (const status of ["QUEUED", "IN_PROGRESS", "WAITING", "PENDING", "REQUESTED"]) {
    assert.equal(classifyChecks([checkRun({ conclusion: "SUCCESS" }), checkRun({ name: "slow", status, conclusion: null })], NOW), "pending", status);
  }
});

test("classifyChecks is failing for every failure-shaped conclusion", () => {
  for (const conclusion of ["FAILURE", "TIMED_OUT", "CANCELLED", "ACTION_REQUIRED", "STARTUP_FAILURE", "STALE"]) {
    assert.equal(classifyChecks([checkRun({ conclusion })]), "failing", conclusion);
  }
});

test("classifyChecks lets a definite failure win over a pending check", () => {
  assert.equal(classifyChecks([checkRun({ conclusion: "FAILURE" }), checkRun({ name: "slow", status: "IN_PROGRESS", conclusion: null })]), "failing");
});

test("classifyChecks reports unknown rather than green when an entry is unreadable", () => {
  assert.equal(classifyChecks([checkRun({ conclusion: "SUCCESS" }), { __typename: "Mystery" }]), "unknown");
});

test("classifyChecks understands legacy status contexts", () => {
  assert.equal(classifyChecks([statusContext({ state: "SUCCESS" })]), "green");
  assert.equal(classifyChecks([statusContext({ state: "PENDING" })], NOW), "pending");
  assert.equal(classifyChecks([statusContext({ state: "EXPECTED" })], NOW), "pending");
  assert.equal(classifyChecks([statusContext({ state: "FAILURE" })]), "failing");
  assert.equal(classifyChecks([statusContext({ state: "ERROR" })]), "failing");
});

test("classifyChecks keeps check runs pending through exactly six hours", () => {
  assert.equal(classifyChecks([checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - 5 * HOUR).toISOString() })], NOW), "pending");
  assert.equal(classifyChecks([checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - 6 * HOUR).toISOString() })], NOW), "pending");
});

test("classifyChecks marks a check run stuck after more than six hours", () => {
  assert.equal(classifyChecks([checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - 6 * HOUR - 1).toISOString() })], NOW), "stuck");
});

test("classifyChecks reports pending checks with missing or malformed timestamps as unknown", () => {
  assert.equal(classifyChecks([checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: undefined })], NOW), "unknown");
  assert.equal(classifyChecks([checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: "not-a-date" })], NOW), "unknown");
  assert.equal(classifyChecks([checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW + 1).toISOString() })], NOW), "unknown");
});

test("classifyChecks uses createdAt for legacy pending status contexts", () => {
  assert.equal(classifyChecks([statusContext({ state: "PENDING", createdAt: new Date(NOW - 6 * HOUR - 1).toISOString() })], NOW), "stuck");
});

test("classifyChecks marks a mixed pending rollup stuck when one entry is stale", () => {
  const rollup = [
    checkRun({ name: "fresh", status: "QUEUED", conclusion: null, startedAt: new Date(NOW - HOUR).toISOString() }),
    checkRun({ name: "stale", status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - 7 * HOUR).toISOString() }),
  ];
  assert.equal(classifyChecks(rollup, NOW), "stuck");
});

test("classifyChecks produces the same stuck result after a model restart", () => {
  const rollup = [checkRun({ status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - 7 * HOUR).toISOString() })];
  assert.equal(classifyChecks(rollup, NOW), "stuck");
  assert.equal(classifyChecks(structuredClone(rollup), NOW), "stuck");
});

test("stuckChecks lists only stale pending entries with elapsed time", () => {
  const rollup = [
    checkRun({ name: "fresh", status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - HOUR).toISOString(), detailsUrl: "https://ci/fresh" }),
    checkRun({ name: "stale", status: "QUEUED", conclusion: null, startedAt: new Date(NOW - 7 * HOUR).toISOString(), detailsUrl: "https://ci/stale" }),
    statusContext({ context: "old legacy", state: "PENDING", createdAt: new Date(NOW - 8 * HOUR).toISOString(), targetUrl: "https://ci/legacy-stale" }),
    checkRun({ name: "failed", conclusion: "FAILURE" }),
  ];
  assert.deepEqual(stuckChecks(rollup, NOW), [
    { name: "stale", url: "https://ci/stale", elapsedMs: 7 * HOUR },
    { name: "old legacy", url: "https://ci/legacy-stale", elapsedMs: 8 * HOUR },
  ]);
});

test("failingChecks lists only the failures, with their names and URLs", () => {
  const rollup = [
    checkRun({ name: "build", conclusion: "SUCCESS" }),
    checkRun({ name: "test", conclusion: "FAILURE", detailsUrl: "https://ci/test" }),
    statusContext({ context: "legacy", state: "ERROR", targetUrl: "https://ci/legacy" }),
  ];
  assert.deepEqual(failingChecks(rollup), [
    { name: "test", url: "https://ci/test" },
    { name: "legacy", url: "https://ci/legacy" },
  ]);
});

// --- verdict planning -------------------------------------------------------
const clean = { verdict: "PASS" };
const blocking = { verdict: "BLOCKING" };

test("planVerdict asks for a review pass when no applicable marker exists", () => {
  assert.deepEqual(planVerdict({ marker: null, checks: "green", isDraft: true }), { action: "review" });
});

test("planVerdict blocks on a blocking verdict regardless of checks", () => {
  assert.deepEqual(planVerdict({ marker: blocking, checks: "green", isDraft: false }), { action: "block", reason: "blocking-verdict" });
});

test("planVerdict fails closed on an unrecognised verdict rather than re-reviewing", () => {
  assert.deepEqual(planVerdict({ marker: { verdict: "mostly-fine" }, checks: "green", isDraft: true }), { action: "block", reason: "unrecognised-verdict" });
});

test("planVerdict fails closed on the old lowercase verdicts", () => {
  assert.deepEqual(planVerdict({ marker: { verdict: "clean" }, checks: "green", isDraft: true }), { action: "block", reason: "unrecognised-verdict" });
  assert.deepEqual(planVerdict({ marker: { verdict: "blocking" }, checks: "green", isDraft: false }), { action: "block", reason: "unrecognised-verdict" });
});

test("planVerdict opens a clean draft PR and defers checks to the next poll", () => {
  assert.deepEqual(planVerdict({ marker: clean, checks: "green", isDraft: true }), { action: "open" });
});

test("planVerdict passes a clean, ready PR whose checks are green", () => {
  assert.deepEqual(planVerdict({ marker: clean, checks: "green", isDraft: false }), { action: "pass" });
});

test("planVerdict waits while a clean, ready PR still has pending checks", () => {
  assert.deepEqual(planVerdict({ marker: clean, checks: "pending", isDraft: false }), { action: "wait" });
});

test("planVerdict blocks a clean, ready PR whose checks failed", () => {
  assert.deepEqual(planVerdict({ marker: clean, checks: "failing", isDraft: false }), { action: "fail-checks" });
});

test("planVerdict blocks a clean, ready PR whose checks are stuck", () => {
  assert.deepEqual(planVerdict({ marker: clean, checks: "stuck", isDraft: false }), { action: "stuck-checks" });
});

test("planVerdict transitions nothing when check data is unreadable", () => {
  assert.deepEqual(planVerdict({ marker: clean, checks: "unknown", isDraft: false }), { action: "retry" });
});

// --- label mirroring --------------------------------------------------------
test("planLabelMirror adds the missing durable and phase labels to the PR", () => {
  assert.deepEqual(planLabelMirror([RUNNING, REVIEW], []), { add: [RUNNING, REVIEW], remove: [] });
});

test("planLabelMirror removes a stale phase label from the PR", () => {
  assert.deepEqual(planLabelMirror([RUNNING, BLOCKED], [RUNNING, REVIEW]), { add: [BLOCKED], remove: [REVIEW] });
});

test("planLabelMirror is a no-op when the PR already agrees", () => {
  assert.deepEqual(planLabelMirror([RUNNING, REVIEW], [REVIEW, RUNNING]), { add: [], remove: [] });
});

test("planLabelMirror never touches labels outside the managed vocabulary", () => {
  assert.deepEqual(planLabelMirror([RUNNING, REVIEW], [RUNNING, REVIEW, "enhancement"]), { add: [], remove: [] });
});

// --- verdict execution ------------------------------------------------------
function ghRecorder() {
  const calls = [];
  return {
    calls,
    gh: {
      setIssueLabels: async (n, d) => calls.push(["setIssueLabels", n, d]),
      setPrLabels: async (n, d) => calls.push(["setPrLabels", n, d]),
      markPrReady: async (n) => calls.push(["markPrReady", n]),
      markPrDraft: async (n) => calls.push(["markPrDraft", n]),
      commentIssue: async (n, b) => calls.push(["commentIssue", n, b]),
      commentPr: async (n, b) => calls.push(["commentPr", n, b]),
    },
  };
}

test("applyReviewPlan block returns the PR to draft and swaps in agent-blocked", async () => {
  const { gh, calls } = ghRecorder();
  const result = await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    plan: { action: "block", reason: "blocking-verdict" }, rollup: [], log: () => {},
  });
  assert.equal(result.phase, BLOCKED);
  assert.deepEqual(calls, [
    ["markPrDraft", 72],
    ["setIssueLabels", 41, { add: [BLOCKED], remove: [REVIEW] }],
    ["setPrLabels", 72, { add: [BLOCKED], remove: [REVIEW] }],
  ]);
});

test("applyReviewPlan block does not re-draft a PR that is already draft", async () => {
  const { gh, calls } = ghRecorder();
  await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: true }),
    plan: { action: "block", reason: "blocking-verdict" }, rollup: [], log: () => {},
  });
  assert.ok(!calls.some((c) => c[0] === "markPrDraft"));
});

test("applyReviewPlan block posts no comment — the reviewer's findings stand alone", async () => {
  const { gh, calls } = ghRecorder();
  await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    plan: { action: "block", reason: "blocking-verdict" }, rollup: [], log: () => {},
  });
  assert.ok(!calls.some((c) => c[0].startsWith("comment")));
});

test("applyReviewPlan block on an unrecognised verdict explains itself", async () => {
  const { gh, calls } = ghRecorder();
  await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: true }),
    plan: { action: "block", reason: "unrecognised-verdict" }, rollup: [], log: () => {},
  });
  const comment = calls.find((c) => c[0] === "commentPr");
  assert.match(comment[2], /unrecognised verdict/i);
});

test("applyReviewPlan open marks the PR ready and keeps agent-review", async () => {
  const { gh, calls } = ghRecorder();
  const result = await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: true }),
    plan: { action: "open" }, rollup: [], log: () => {},
  });
  assert.equal(result.phase, REVIEW);
  assert.deepEqual(calls, [["markPrReady", 72]]);
});

test("applyReviewPlan pass swaps agent-review for user-merge-review on both", async () => {
  const { gh, calls } = ghRecorder();
  const result = await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    plan: { action: "pass" }, rollup: [], log: () => {},
  });
  assert.equal(result.phase, MERGE_REVIEW);
  assert.deepEqual(calls, [
    ["setIssueLabels", 41, { add: [MERGE_REVIEW], remove: [REVIEW] }],
    ["setPrLabels", 72, { add: [MERGE_REVIEW], remove: [REVIEW] }],
  ]);
});

test("applyReviewPlan never approves or merges on a pass", async () => {
  const { gh, calls } = ghRecorder();
  await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    plan: { action: "pass" }, rollup: [], log: () => {},
  });
  assert.ok(!calls.some((c) => /approve|merge/i.test(c[0])));
});

test("applyReviewPlan wait and retry mutate nothing", async () => {
  for (const action of ["wait", "retry"]) {
    const { gh, calls } = ghRecorder();
    const result = await applyReviewPlan({
      gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
      plan: { action }, rollup: [], log: () => {},
    });
    assert.deepEqual(calls, [], action);
    assert.equal(result.phase, REVIEW, action);
  }
});

test("applyReviewPlan fail-checks drafts, blocks, and posts the failing check names and URLs", async () => {
  const { gh, calls } = ghRecorder();
  const rollup = [
    checkRun({ name: "unit", conclusion: "FAILURE", detailsUrl: "https://ci/unit" }),
    checkRun({ name: "lint", conclusion: "SUCCESS" }),
  ];
  const result = await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    plan: { action: "fail-checks" }, rollup, log: () => {},
  });
  assert.equal(result.phase, BLOCKED);
  const comment = calls.find((c) => c[0] === "commentPr")[2];
  assert.match(comment, /unit/);
  assert.match(comment, /https:\/\/ci\/unit/);
  assert.ok(!comment.includes("lint"));
  assert.deepEqual(calls.map((c) => c[0]), ["commentPr", "markPrDraft", "setIssueLabels", "setPrLabels"]);
});

test("applyReviewPlan stuck-checks drafts, blocks, and names only stale checks with elapsed time and URLs", async () => {
  const { gh, calls } = ghRecorder();
  const rollup = [
    checkRun({ name: "fresh", status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - HOUR).toISOString(), detailsUrl: "https://ci/fresh" }),
    checkRun({ name: "stale", status: "IN_PROGRESS", conclusion: null, startedAt: new Date(NOW - 7 * HOUR).toISOString(), detailsUrl: "https://ci/stale" }),
  ];
  const result = await applyReviewPlan({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    plan: { action: "stuck-checks" }, rollup, now: NOW, log: () => {},
  });
  assert.equal(result.phase, BLOCKED);
  const comment = calls.find((c) => c[0] === "commentPr")[2];
  assert.match(comment, /stale/);
  assert.match(comment, /7 hours/);
  assert.match(comment, /https:\/\/ci\/stale/);
  assert.ok(!comment.includes("fresh"));
  assert.deepEqual(calls.map((c) => c[0]), ["commentPr", "markPrDraft", "setIssueLabels", "setPrLabels"]);
});

test("mirrorLabels issues no API call when the PR already agrees", async () => {
  const { gh, calls } = ghRecorder();
  await mirrorLabels({ gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { labels: [RUNNING, REVIEW] }) });
  assert.deepEqual(calls, []);
});

test("mirrorLabels repairs a disagreeing PR on the next poll", async () => {
  const { gh, calls } = ghRecorder();
  await mirrorLabels({ gh, issue: issue(41, [RUNNING, BLOCKED]), pr: pr(72, { labels: [REVIEW] }) });
  assert.deepEqual(calls, [["setPrLabels", 72, { add: [RUNNING, BLOCKED], remove: [REVIEW] }]]);
});

test("failClosed comments and blocks on both issue and PR", async () => {
  const { gh, calls } = ghRecorder();
  await failClosed({
    gh, issue: issue(41, [RUNNING, REVIEW]), pr: pr(72, { isDraft: false }),
    message: "Issue #41 is closed by more than one open PR.", log: () => {},
  });
  assert.deepEqual(calls.map((c) => c[0]), ["commentIssue", "markPrDraft", "setIssueLabels", "setPrLabels"]);
  assert.match(calls[0][2], /more than one open PR/);
});

test("failClosed works with no PR identified", async () => {
  const { gh, calls } = ghRecorder();
  await failClosed({ gh, issue: issue(41, [RUNNING, REVIEW]), pr: null, message: "no open PR closes it", log: () => {} });
  assert.deepEqual(calls.map((c) => c[0]), ["commentIssue", "setIssueLabels"]);
});

test("failClosed is idempotent for an already-blocked issue", async () => {
  const { gh, calls } = ghRecorder();
  await failClosed({ gh, issue: issue(41, [RUNNING, BLOCKED]), pr: null, message: "still broken", log: () => {} });
  assert.deepEqual(calls, []);
});
