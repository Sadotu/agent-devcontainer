import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import { chmod, mkdtemp, mkdir, open, rm, symlink, writeFile } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  acquireSupervisorOwnership,
  createConfiguredLease,
  createGitHub,
  createTmux,
  formatLogLine,
  isAgentSetupReady,
  runOnce,
  main,
} from "../bin/supervisor.mjs";
import { resolveContainerId } from "../src/managedContainer.mjs";
import { computeFingerprint } from "../src/reviewMarker.mjs";

// ---------------------------------------------------------------------------
// managed-container lease helpers
// ---------------------------------------------------------------------------
const CONTAINER = "c".repeat(64);

// A lease that always succeeds, for tests whose subject is not the lease.
function stubLease() {
  return {
    resolveContainerId: async () => CONTAINER,
    createLeaseClient: () => ({
      register: async () => ({ status: "registered" }),
      unregister: async () => {},
    }),
  };
}

function leaseHarness({ registerImpl, unregisterImpl } = {}) {
  const calls = [];
  return {
    calls,
    lease: {
      register: async (id) => {
        calls.push(["register", id]);
        if (registerImpl) return registerImpl(id, calls.length);
        return { status: calls.length === 1 ? "registered" : "refreshed" };
      },
      unregister: async (id) => {
        calls.push(["unregister", id]);
        if (unregisterImpl) return unregisterImpl(id);
      },
    },
  };
}

test("isAgentSetupReady checks the devcontainer setup marker", async () => {
  const paths = [];
  const ready = await isAgentSetupReady({ accessImpl: async (path) => paths.push(path) });
  assert.equal(ready, true);
  assert.deepEqual(paths, ["/run/agent-devcontainer/agent-setup-complete"]);
});

test("isAgentSetupReady returns false when the setup marker is inaccessible", async () => {
  const ready = await isAgentSetupReady({ accessImpl: async () => { throw new Error("missing"); } });
  assert.equal(ready, false);
});

// ---------------------------------------------------------------------------
// log line formatting
// ---------------------------------------------------------------------------
test("formatLogLine prefixes an ISO timestamp inside the orchestrator tag", () => {
  const now = new Date("2026-07-21T12:34:56.000Z");
  assert.equal(
    formatLogLine("Started worker for #82", now),
    "[orchestrator 2026-07-21T12:34:56.000Z] Started worker for #82",
  );
});

test("main bootstraps labels after the auth check and before the first poll", async () => {
  const order = [];
  await main({
    ...stubLease(),
    exec: async () => ({ stdout: "" }),
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => {},
    mintToken: async () => "t",
    authExec: () => async () => { order.push("auth"); return { stdout: "o/r" }; },
    createTmux: () => ({ ensureSession: async () => {} }),
    bootstrapLabels: async () => { order.push("labels"); },
    runPoll: async () => { order.push("poll"); return { done: true }; },
    sleepImpl: async () => {},
    log: () => {},
  });
  assert.deepEqual(order, ["auth", "labels", "poll"]);
});

test("main gives the same worker-log helper to the tmux adapter and the poll", async () => {
  let tmuxLogs;
  let pollLogs;
  const helper = { prepare: async () => null, diagnostics: async () => null };
  await main({
    ...stubLease(),
    exec: async () => ({ stdout: "" }),
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => {},
    mintToken: async () => "t",
    authExec: () => async () => ({ stdout: "o/r" }),
    createWorkerLogs: () => helper,
    createTmux: ({ logs }) => { tmuxLogs = logs; return { ensureSession: async () => {} }; },
    bootstrapLabels: async () => {},
    runPoll: async ({ logs }) => { pollLogs = logs; return { done: true }; },
    sleepImpl: async () => {},
    log: () => {},
  });
  assert.equal(tmuxLogs, helper);
  assert.equal(pollLogs, helper);
});

test("main fails fast when the label bootstrap is denied", async () => {
  await assert.rejects(
    () => main({
      ...stubLease(),
      exec: async () => ({ stdout: "" }),
      resolveRepo: async () => "o/r",
      acquireOwnership: async () => async () => {},
      mintToken: async () => "t",
      authExec: () => async () => ({ stdout: "o/r" }),
      createTmux: () => ({ ensureSession: async () => {} }),
      bootstrapLabels: async () => { throw new Error("label bootstrap failed: HTTP 403"); },
      runPoll: async () => { throw new Error("poll must not run"); },
      sleepImpl: async () => {},
      log: () => {},
    }),
    /label bootstrap failed: HTTP 403/,
  );
});

test("main releases ownership when the label bootstrap fails", async () => {
  let released = false;
  await assert.rejects(() => main({
    ...stubLease(),
    exec: async () => ({ stdout: "" }),
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { released = true; },
    mintToken: async () => "t",
    authExec: () => async () => ({ stdout: "o/r" }),
    createTmux: () => ({ ensureSession: async () => {} }),
    bootstrapLabels: async () => { throw new Error("label bootstrap failed: HTTP 403"); },
    runPoll: async () => ({ done: true }),
    sleepImpl: async () => {},
    log: () => {},
  }), /HTTP 403/);
  assert.equal(released, true);
});

// ---------------------------------------------------------------------------
// supervisor ownership
// ---------------------------------------------------------------------------
test("installed symlink runs the supervisor for the repository in process cwd", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "orchestrator-installed-"));
  let child;
  t.after(async () => {
    if (child?.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    await rm(root, { recursive: true, force: true });
  });
  const repo = join(root, "target");
  const tools = join(root, "tools");
  await mkdir(repo);
  await mkdir(tools);
  const launcher = join(root, "issue-orchestrator");
  await symlink(new URL("../bin/supervisor.mjs", import.meta.url), launcher);
  const helper = join(tools, "token-helper");
  await writeFile(helper, "#!/bin/sh\nprintf token\n");
  await chmod(helper, 0o755);
  for (const name of ["gh", "tmux"]) {
    const file = join(tools, name);
    await writeFile(file, "#!/bin/sh\nexit 0\n");
    await chmod(file, 0o755);
  }
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["init", "-q"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git init exited ${code}`)));
  });
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["remote", "add", "origin", "git@github.com:target-owner/target-repo.git"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git remote exited ${code}`)));
  });

  // Stand in for Sentinel's lease API so the run never depends on a deployed
  // Sentinel, and record exactly what the supervisor asks it for.
  const leaseRequests = [];
  const sentinel = http.createServer((req, res) => {
    leaseRequests.push([req.method, req.url]);
    if (req.method === "PUT") {
      res.writeHead(201, { "content-type": "application/json" });
      res.end(JSON.stringify({ containerId: req.url.split("/").pop(), status: "registered" }));
      return;
    }
    res.writeHead(req.method === "DELETE" ? 204 : 404);
    res.end();
  });
  sentinel.listen(0, "127.0.0.1");
  await once(sentinel, "listening");
  t.after(() => new Promise((resolve) => sentinel.close(resolve)));

  child = spawn(launcher, [], {
    cwd: repo,
    env: {
      ...process.env,
      PATH: `${tools}:${process.env.PATH}`,
      GH_APP_TOKEN_SCRIPT: helper,
      SENTINEL_URL: `http://127.0.0.1:${sentinel.address().port}`,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let stdout = ""; let stderr = "";
  child.stdout.on("data", (chunk) => { stdout += chunk; });
  child.stderr.on("data", (chunk) => { stderr += chunk; });
  const timeout = setTimeout(() => child.kill("SIGKILL"), 3000);
  timeout.unref();
  t.after(() => clearTimeout(timeout));
  const [code] = await once(child, "exit");
  assert.equal(code, 0, stderr);
  assert.match(stdout, /Authenticated as GitHub App for target-owner\/target-repo/);
  assert.match(stdout, /Queue empty and no live workers/);

  // The lease carries this container's exact 64-hex ID, and nothing else on
  // Sentinel is ever contacted — no usage telemetry, no worker admission.
  const containerId = await resolveContainerId();
  assert.deepEqual(leaseRequests, [
    ["PUT", `/managed-containers/${containerId}`],
    ["DELETE", `/managed-containers/${containerId}`],
  ]);
  assert.match(stdout, new RegExp(`Managed container lease registered for ${containerId}`));
});

test("main rejects duplicate ownership before auth, the lease, or tmux setup", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => { events.push("resolve"); return "o/r"; },
    acquireOwnership: async () => { events.push("acquire"); throw new Error("supervisor already running for o/r"); },
    mintToken: async () => { events.push("auth"); },
    resolveContainerId: async () => { events.push("container"); return CONTAINER; },
    createTmux: () => events.push("tmux"),
  }), /already running/);
  assert.deepEqual(events, ["resolve", "acquire"]);
});

test("main releases ownership after normal completion", async () => {
  const events = [];
  await main({
    ...stubLease(),
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "" }),
    createTmux: () => ({}),
    runPoll: async () => ({ done: true }),
    log: () => {},
  });
  assert.deepEqual(events, ["release"]);
});

// ---------------------------------------------------------------------------
// managed-container lease wiring
// ---------------------------------------------------------------------------
function mainDeps(overrides = {}) {
  return {
    exec: async () => ({ stdout: "git@github.com:owner/repo.git\n", stderr: "" }),
    acquireOwnership: async () => async () => {},
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "owner/repo", stderr: "" }),
    createTmux: () => ({}),
    // These tests are about the lease, not the label bootstrap; stub it out so
    // the fake `authExec` need not answer `gh label list`.
    bootstrapLabels: async () => {},
    resolveContainerId: async () => CONTAINER,
    runPoll: async () => ({ done: true }),
    sleepImpl: async () => {},
    log: () => {},
    ...overrides,
  };
}

test("main registers the exact container ID at startup and unregisters on clean shutdown", async () => {
  const { calls, lease } = leaseHarness();
  await main(mainDeps({ createLeaseClient: () => lease }));
  assert.deepEqual(calls, [["register", CONTAINER], ["unregister", CONTAINER]]);
});

test("main refreshes the same lease on every poll", async () => {
  const { calls, lease } = leaseHarness();
  let polls = 0;
  await main(mainDeps({
    createLeaseClient: () => lease,
    runPoll: async () => ({ done: ++polls === 3 }),
  }));
  assert.deepEqual(calls, [
    ["register", CONTAINER], ["register", CONTAINER], ["register", CONTAINER],
    ["unregister", CONTAINER],
  ]);
});

test("main fails fast when the container ID cannot be resolved", async () => {
  const { calls, lease } = leaseHarness();
  let polled = false;
  await assert.rejects(() => main(mainDeps({
    createLeaseClient: () => lease,
    resolveContainerId: async () => { throw new Error("no container mount"); },
    runPoll: async () => { polled = true; return { done: true }; },
  })), /managed-container registration failed: no container mount/);
  assert.equal(polled, false);
  assert.deepEqual(calls, []);
});

test("main fails fast when startup registration fails", async () => {
  let polled = false;
  await assert.rejects(() => main(mainDeps({
    createLeaseClient: () => ({
      register: async () => { throw new Error("sentinel unreachable: ECONNREFUSED"); },
      unregister: async () => {},
    }),
    runPoll: async () => { polled = true; return { done: true }; },
  })), /managed-container registration failed: sentinel unreachable: ECONNREFUSED/);
  assert.equal(polled, false);
});

test("main logs a failed heartbeat and keeps polling", async () => {
  const logs = [];
  let polls = 0;
  const { calls, lease } = leaseHarness({
    registerImpl: (_id, call) => {
      if (call === 2) throw new Error("sentinel request timed out: exceeded 5000ms");
      return { status: "refreshed" };
    },
  });
  await main(mainDeps({
    createLeaseClient: () => lease,
    runPoll: async () => ({ done: ++polls === 3 }),
    log: (message) => logs.push(message),
  }));
  assert.equal(calls.filter(([name]) => name === "register").length, 3);
  assert.equal(polls, 3);
  assert.ok(logs.some((line) => /lease heartbeat failed: sentinel request timed out/.test(line)));
});

test("main logs but does not fail when best-effort unregister fails", async () => {
  const logs = [];
  await main(mainDeps({
    createLeaseClient: () => ({
      register: async () => ({ status: "registered" }),
      unregister: async () => { throw new Error("sentinel unreachable: ECONNREFUSED"); },
    }),
    log: (message) => logs.push(message),
  }));
  assert.ok(logs.some((line) => /lease unregister failed \(Sentinel lease expiry recovers this\)/.test(line)));
});

test("createConfiguredLease targets the configured Sentinel base URL", async () => {
  const urls = [];
  const lease = createConfiguredLease({
    env: { SENTINEL_URL: "http://host.docker.internal:4317" },
    fetchImpl: async (url) => { urls.push(url); return { status: 204 }; },
  });
  await lease.unregister(CONTAINER);
  assert.deepEqual(urls, [`http://host.docker.internal:4317/managed-containers/${CONTAINER}`]);
});

test("main releases ownership when startup authentication fails", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => { throw new Error("token unavailable"); },
    createTmux: () => ({}),
  }), /GitHub App auth check failed: token unavailable/);
  assert.deepEqual(events, ["release"]);
});

test("supervisor ownership rejects a simultaneous owner and release permits reacquisition", async () => {
  const repo = `test/${randomUUID()}`;
  let listenedAddress;
  const first = await acquireSupervisorOwnership(repo, {
    createServer: () => {
      const server = createNetServer();
      const listen = server.listen.bind(server);
      server.listen = (address, callback) => {
        listenedAddress = address;
        return listen(address, callback);
      };
      return server;
    },
  });
  assert.equal(listenedAddress.startsWith("\0issue-orchestrator-"), true);
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  await first();
  await first();
  const second = await acquireSupervisorOwnership(repo);
  await second();
});

test("simultaneous supervisor acquisitions produce exactly one owner", async () => {
  const repo = `test/${randomUUID()}`;
  const results = await Promise.allSettled([
    acquireSupervisorOwnership(repo),
    acquireSupervisorOwnership(repo),
  ]);
  const winners = results.filter((result) => result.status === "fulfilled");
  assert.equal(winners.length, 1);
  assert.match(results.find((result) => result.status === "rejected").reason.message, /already running/);
  await winners[0].value();
});

test("supervisor ownership is released when its process dies", async () => {
  const repo = `test/${randomUUID()}`;
  const script = `
    import { acquireSupervisorOwnership } from "./bin/supervisor.mjs";
    await acquireSupervisorOwnership(${JSON.stringify(repo)});
    process.stdout.write("READY\\n");
    setInterval(() => {}, 1000);
  `;
  const child = spawn(process.execPath, ["--input-type=module", "--eval", script], {
    cwd: new URL("..", import.meta.url),
    stdio: ["ignore", "pipe", "inherit"],
  });
  await once(child.stdout, "data");
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  child.kill("SIGKILL");
  await once(child, "exit");

  const release = await acquireSupervisorOwnership(repo);
  await release();
});

// ---------------------------------------------------------------------------
// GitHub adapter
// ---------------------------------------------------------------------------
function fakeExec(responses) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push([file, ...args]);
    const key = args.join(" ");
    for (const [match, out] of responses) {
      if (key.includes(match)) return { stdout: out };
    }
    return { stdout: "" };
  };
  return { exec, calls };
}

test("github listReadyIssues returns ascending numbers", async () => {
  const { exec } = fakeExec([["--label agent-ready", JSON.stringify([{ number: 9 }, { number: 3 }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listReadyIssues(), [3, 9]);
});

test("github listOpenPrs queries only open PRs", async () => {
  const { exec, calls } = fakeExec([["pr list", JSON.stringify([{ headRefName: "agent/1-x", isDraft: true, url: "u" }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  const prs = await gh.listOpenPrs();
  assert.equal(prs.length, 1);
  const c = calls.find((c) => c.includes("list") && c.includes("pr"));
  assert.ok(c.includes("--state") && c.includes("open"));
  assert.ok(!c.includes("all"));
});

test("github claim swaps ready->running", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.claim(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-ready"));
  assert.ok(c.includes("--add-label") && c.includes("agent-running"));
});

test("github restore swaps running back to ready", async () => {
  const { exec, calls } = fakeExec([]);
  await createGitHub({ exec, repo: "o/r" }).restore(5);
  const c = calls.find((call) => call.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(c.includes("--add-label") && c.includes("agent-ready"));
});

test("github listRunningIssues returns numbers, label names, updatedAt, and the body", async () => {
  const { exec, calls } = fakeExec([["--label agent-running", JSON.stringify([
    { number: 41, labels: [{ name: "agent-running" }, { name: "agent-review" }], updatedAt: "2026-08-01T10:00:00Z", body: "Issue body" },
  ])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listRunningIssues(), [
    { number: 41, labels: ["agent-running", "agent-review"], updatedAt: "2026-08-01T10:00:00Z", body: "Issue body" },
  ]);
  const fields = calls.find((c) => c.includes("issue") && c.includes("list")).at(-3);
  assert.ok(fields.includes("body"), fields);
});

test("github listOpenPrs requests the fingerprint, label, and check fields in one call", async () => {
  const { exec, calls } = fakeExec([["pr list", JSON.stringify([
    { number: 72, headRefName: "agent/41-x", headRefOid: "a", baseRefOid: "b", isDraft: true,
      url: "u", updatedAt: "t", createdAt: "c", labels: [{ name: "agent-running" }],
      closingIssuesReferences: [{ number: 41 }], statusCheckRollup: [] },
  ])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  const [pr] = await gh.listOpenPrs();
  assert.deepEqual(pr.labels, ["agent-running"]);
  assert.equal(pr.headRefOid, "a");
  assert.deepEqual(pr.statusCheckRollup, []);
  const fields = calls.find((c) => c.includes("pr") && c.includes("list")).at(-3);
  for (const field of ["headRefOid", "baseRefOid", "body", "updatedAt", "createdAt", "labels", "statusCheckRollup", "closingIssuesReferences"]) {
    assert.ok(fields.includes(field), field);
  }
});

test("github listPrComments returns comment bodies in order", async () => {
  const { exec } = fakeExec([["pr view", JSON.stringify({ comments: [{ body: "first" }, { body: "second" }] })]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listPrComments(72), [{ body: "first" }, { body: "second" }]);
});

test("github setIssueLabels sends only the non-empty halves of the delta", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.setIssueLabels(41, { add: ["agent-blocked"], remove: [] });
  const c = calls.find((call) => call.includes("edit"));
  assert.ok(c.includes("--add-label") && c.includes("agent-blocked"));
  assert.ok(!c.includes("--remove-label"));
});

test("github setPrLabels edits the pull request, not the issue", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.setPrLabels(72, { add: ["a"], remove: ["b"] });
  const c = calls.find((call) => call.includes("edit"));
  assert.equal(c[1], "pr");
  assert.ok(c.includes("--add-label") && c.includes("--remove-label"));
});

test("github setIssueLabels makes no call for an empty delta", async () => {
  const { exec, calls } = fakeExec([]);
  await createGitHub({ exec, repo: "o/r" }).setIssueLabels(41, { add: [], remove: [] });
  assert.deepEqual(calls, []);
});

test("github markPrReady and markPrDraft use gh pr ready", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.markPrReady(72);
  await gh.markPrDraft(72);
  assert.deepEqual(calls[0].slice(0, 4), ["gh", "pr", "ready", "72"]);
  assert.ok(calls[1].includes("--undo"));
});

test("github never exposes an approve or merge operation", () => {
  const gh = createGitHub({ exec: async () => ({ stdout: "" }), repo: "o/r" });
  assert.deepEqual(Object.keys(gh).filter((k) => /approve|merge/i.test(k)), []);
});

test("github listLabels and createLabel drive gh label", async () => {
  const { exec, calls } = fakeExec([["label list", JSON.stringify([{ name: "agent-ready" }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listLabels(), [{ name: "agent-ready" }]);
  await gh.createLabel({ name: "agent-review", color: "5319e7", description: "d" });
  const c = calls.find((call) => call[1] === "label" && call[2] === "create");
  assert.ok(c.includes("--color") && c.includes("5319e7"));
  assert.ok(c.includes("--description") && c.includes("d"));
});

// ---------------------------------------------------------------------------
// tmux adapter
// ---------------------------------------------------------------------------
function tmuxRecorder({ listOutput = "", listError = null, killError = null } = {}) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push(args);
    if (args[0] === "list-windows" && listError) throw listError;
    if (args[0] === "list-windows") return { stdout: listOutput };
    if (args[0] === "kill-window" && killError) throw killError;
    return { stdout: "" };
  };
  return { exec, calls };
}

test("tmux listWorkerIssues collects issue windows by name", async () => {
  const { exec, calls } = tmuxRecorder({ listOutput: "supervisor\nissue-3\nissue-12\nnotes\n" });
  const tmux = createTmux({ exec });
  const set = await tmux.listWorkerIssues();
  assert.deepEqual([...set].sort((a, b) => a - b), [3, 12]);
  assert.equal(calls[0].at(-1), "#{window_name}");
});

test("tmux listWorkerIssues propagates list-windows inspection failures", async () => {
  const error = new Error("temporary tmux server failure");
  const { exec } = tmuxRecorder({ listError: error });
  const tmux = createTmux({ exec });
  await assert.rejects(() => tmux.listWorkerIssues(), error);
});

test("tmux openWorker creates a self-closing auto-mode issue worker with no pause environment", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  await tmux.openWorker(7);
  const c = calls.find((a) => a[0] === "new-window");
  assert.deepEqual(c, [
    "new-window",
    "-t",
    "orchestrator",
    "-n",
    "issue-7",
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"'`,
  ]);
});

test("tmux openWorker rejects a non-integer issue number (no shell injection)", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  assert.throws(() => tmux.openWorker('7" && rm -rf /'), /invalid issue number/);
  assert.equal(calls.length, 0);
});

test("tmux closeWorker treats a confirmed missing window as success", async () => {
  const err = new Error("kill-window failed");
  err.stderr = "can't find window: orchestrator:issue-7";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec });
  await tmux.closeWorker(7); // must not throw
});

test("tmux closeWorker propagates a non-absent failure (e.g. server down)", async () => {
  const err = new Error("no server running on /tmp/tmux-1000/default");
  err.stderr = "no server running on /tmp/tmux-1000/default";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec });
  await assert.rejects(() => tmux.closeWorker(7), /no server running/);
});

test("tmux listReviewIssues collects review windows without matching issue windows", async () => {
  const { exec } = tmuxRecorder({ listOutput: "supervisor\nissue-3\nreview-41\nreview-7\n" });
  const tmux = createTmux({ exec });
  assert.deepEqual([...await tmux.listReviewIssues()].sort((a, b) => a - b), [7, 41]);
  assert.deepEqual([...await tmux.listWorkerIssues()], [3]);
});

test("tmux openReviewer names the window for the issue and reviews the PR", async () => {
  const { exec, calls } = tmuxRecorder();
  await createTmux({ exec }).openReviewer(41, 72);
  assert.deepEqual(calls.find((a) => a[0] === "new-window"), [
    "new-window", "-t", "orchestrator", "-n", "review-41",
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/review-pr 72"'`,
  ]);
});

test("tmux openReviewer rejects a non-integer PR number (no shell injection)", async () => {
  const { exec, calls } = tmuxRecorder();
  assert.throws(() => createTmux({ exec }).openReviewer(41, '72" && rm -rf /'), /invalid issue number/);
  assert.equal(calls.length, 0);
});

// ---------------------------------------------------------------------------
// worker logs
// ---------------------------------------------------------------------------
// A log helper that hands out a fixed path per role, recording what it was
// asked to reserve.
function stubLogs({ prepared = {}, diagnostics = {} } = {}) {
  const calls = [];
  return {
    calls,
    logs: {
      prepare: async (role, number) => {
        calls.push(["prepare", role, number]);
        return prepared[`${role}-${number}`] ?? null;
      },
      diagnostics: async (role, number) => {
        calls.push(["diagnostics", role, number]);
        return diagnostics[`${role}-${number}`] ?? null;
      },
    },
  };
}

test("tmux openWorker tees the worker's combined output into its reserved log", async () => {
  const { exec, calls } = tmuxRecorder();
  const { logs, calls: logCalls } = stubLogs({ prepared: { "issue-7": "/gitdir/logs/issue-7.2.log" } });
  await createTmux({ exec, logs }).openWorker(7);
  assert.deepEqual(logCalls, [["prepare", "issue", 7]]);
  assert.deepEqual(calls.find((a) => a[0] === "new-window"), [
    "new-window", "-t", "orchestrator", "-n", "issue-7",
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"'`
      + ` 2>&1 | tee '/gitdir/logs/issue-7.2.log'`,
  ]);
});

test("tmux openReviewer tees the reviewer's combined output into its reserved log", async () => {
  const { exec, calls } = tmuxRecorder();
  const { logs } = stubLogs({ prepared: { "review-41": "/gitdir/logs/review-41.1.log" } });
  await createTmux({ exec, logs }).openReviewer(41, 72);
  assert.deepEqual(calls.find((a) => a[0] === "new-window"), [
    "new-window", "-t", "orchestrator", "-n", "review-41",
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/review-pr 72"'`
      + ` 2>&1 | tee '/gitdir/logs/review-41.1.log'`,
  ]);
});

test("tmux quotes a log path before it crosses the shell boundary", async () => {
  const { exec, calls } = tmuxRecorder();
  const { logs } = stubLogs({ prepared: { "issue-7": "/git dir/logs/it's.log" } });
  await createTmux({ exec, logs }).openWorker(7);
  const command = calls.find((a) => a[0] === "new-window").at(-1);
  assert.equal(command.endsWith(`2>&1 | tee '/git dir/logs/it'"'"'s.log'`), true);
});

test("tmux launches the worker unchanged when no log could be reserved", async () => {
  const { exec, calls } = tmuxRecorder();
  const { logs } = stubLogs(); // prepare resolves to null
  await createTmux({ exec, logs }).openWorker(7);
  assert.equal(
    calls.find((a) => a[0] === "new-window").at(-1),
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"'`,
  );
});

test("tmux validates the worker identity synchronously, before reserving a log", async () => {
  const { exec } = tmuxRecorder();
  const { logs, calls } = stubLogs();
  assert.throws(() => createTmux({ exec, logs }).openWorker('7" && rm -rf /'), /invalid issue number/);
  assert.throws(() => createTmux({ exec, logs }).openReviewer(41, "x"), /invalid issue number/);
  assert.deepEqual(calls, []);
});


// ---------------------------------------------------------------------------
// runOnce
// ---------------------------------------------------------------------------
function stubGh(overrides = {}) {
  return {
    listReadyIssues: async () => [],
    listRunningIssues: async () => [],
    listOpenPrs: async () => [],
    listPrComments: async () => [],
    claim: async () => {},
    restore: async () => {},
    setIssueLabels: async () => {},
    setPrLabels: async () => {},
    markPrReady: async () => {},
    markPrDraft: async () => {},
    commentIssue: async () => {},
    commentPr: async () => {},
    ...overrides,
  };
}
function stubTmux(overrides = {}) {
  return {
    ensureSession: async () => {},
    listWorkerIssues: async () => new Set(),
    listReviewIssues: async () => new Set(),
    openWorker: async () => {},
    openReviewer: async () => {},
    closeWorker: async () => {},
    ...overrides,
  };
}
const ISSUE_BODY = "Issue body\n";
const PR_BODY = "PR body\n";
const runIssue = (number, labels = ["agent-running"]) =>
  ({ number, labels, updatedAt: "2026-08-01T10:00:00Z", body: ISSUE_BODY });
const runPr = (number, over = {}) => ({
  number, headRefName: "agent/41-x", headRefOid: "a".repeat(40), baseRefOid: "b".repeat(40),
  body: PR_BODY, isDraft: true, url: `https://gh/pr/${number}`, updatedAt: "2026-08-01T10:05:00Z",
  createdAt: "2026-08-01T09:00:00Z", labels: ["agent-running", "agent-review"],
  closingIssuesReferences: [{ number: 41 }], statusCheckRollup: [], ...over,
});
// The literal single line publish-review.sh posts — assembled here rather than
// by a supervisor-side formatter, so producer/consumer drift fails these tests.
function markerComment(verdict, {
  head = "a".repeat(40), base = "b".repeat(40), issueBody = ISSUE_BODY, prBody = PR_BODY,
  issue = 41, pr = 72, viewerDidAuthor = true, fingerprint,
} = {}) {
  const payload = {
    fingerprint: fingerprint ?? computeFingerprint({ head, base, issueBody, prBody }),
    head, base, issueUpdatedAt: "2026-08-01T10:00:00Z", prUpdatedAt: "2026-08-01T10:05:00Z",
    issue, pr, pass: 1, verdict,
  };
  return { body: `Findings...\n\n<!-- review-pr:v1 ${JSON.stringify(payload)} -->`, viewerDidAuthor };
}

test("runOnce aborts without lifecycle mutations when tmux inspection fails", async () => {
  const events = [];
  const inspectionError = new Error("temporary tmux inspection failure");
  const gh = stubGh({
    listOpenPrs: async () => { events.push("list-prs"); return []; },
    listReadyIssues: async () => { events.push("list-ready"); return [8]; },
    claim: async () => events.push("claim"),
    setIssueLabels: async () => events.push("set-labels"),
  });
  const tmux = stubTmux({ listWorkerIssues: async () => { throw inspectionError; } });
  await assert.rejects(
    () => runOnce({ gh, tmux, log: () => {}, runningIssues: [runIssue(7)] }),
    inspectionError,
  );
  assert.deepEqual(events, []);
});

test("runOnce claims ready issues and launches implementation workers", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [4] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(opened, [4]);
  assert.equal(res.done, false);
});

test("runOnce caps implementation workers at two, counting orphan issue windows", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([50]), openWorker: async (n) => opened.push(n) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(opened, [1]); // 1 orphan + 1 new = 2
});

test("runOnce never borrows the reviewer slot for implementation", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({ listReviewIssues: async () => new Set(), openWorker: async (n) => opened.push(n) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(opened, [1, 2]);
});

test("runOnce keeps agent-running when implementation finishes and closes its window", async () => {
  const closed = [];
  const calls = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
    listPrComments: async () => [],
    setIssueLabels: async (...a) => calls.push(["issue", ...a]),
  });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([41]), closeWorker: async (n) => closed.push(n) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(closed, [41]);
  assert.ok(!calls.some((c) => JSON.stringify(c).includes("agent-ready")));
});

test("runOnce fails closed when an implementation worker vanishes with no phase label", async () => {
  const calls = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41)],
    listOpenPrs: async () => [runPr(72, { labels: [] })],
    commentIssue: async (n, b) => calls.push(["comment", n, b]),
    setIssueLabels: async (n, d) => calls.push(["labels", n, d]),
  });
  await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.equal(calls[0][0], "comment");
  assert.deepEqual(calls.find((c) => c[0] === "labels")[2], { add: ["agent-blocked"], remove: [] });
});

test("runOnce surfaces the log path and bounded tail when an implementation worker vanishes", async () => {
  const calls = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41)],
    listOpenPrs: async () => [runPr(72, { labels: [] })],
    commentIssue: async (n, b) => calls.push(["comment", n, b]),
  });
  const { logs, calls: logCalls } = stubLogs({
    diagnostics: { "issue-41": { path: "/gitdir/logs/issue-41.2.log", tail: "Error: context exhausted" } },
  });
  await runOnce({ gh, tmux: stubTmux(), logs, log: () => {} });
  const body = calls.find((c) => c[0] === "comment")[2];
  assert.deepEqual(logCalls, [["diagnostics", "issue", 41]]);
  assert.match(body, /#41/);
  assert.match(body, /https:\/\/gh\/pr\/72/);
  assert.match(body, /\/gitdir\/logs\/issue-41\.2\.log/);
  assert.match(body, /Error: context exhausted/);
});

test("runOnce surfaces the vanished worker's log even with no linked PR", async () => {
  const calls = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41)],
    listOpenPrs: async () => [],
    commentIssue: async (n, b) => calls.push(["comment", n, b]),
  });
  const { logs } = stubLogs({
    diagnostics: { "issue-41": { path: "/gitdir/logs/issue-41.1.log", tail: "boom" } },
  });
  await runOnce({ gh, tmux: stubTmux(), logs, log: () => {} });
  const body = calls.find((c) => c[0] === "comment")[2];
  assert.match(body, /\/gitdir\/logs\/issue-41\.1\.log/);
  assert.match(body, /boom/);
  assert.equal(body.includes("https://gh/pr/"), false);
});

test("runOnce omits the log section when a vanished worker left no log", async () => {
  const calls = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41)],
    listOpenPrs: async () => [runPr(72, { labels: [] })],
    commentIssue: async (n, b) => calls.push(["comment", n, b]),
  });
  await runOnce({ gh, tmux: stubTmux(), logs: stubLogs().logs, log: () => {} });
  const body = calls.find((c) => c[0] === "comment")[2];
  assert.equal(body.includes("Worker log"), false);
  assert.match(body, /exited before reaching a review phase/);
});

test("runOnce surfaces the previous reviewer's log before relaunching it", async () => {
  const reviews = [];
  const lines = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
    listPrComments: async () => [{ body: "I ran out of context" }],
  });
  const tmux = stubTmux({ openReviewer: async (...a) => reviews.push(a) });
  const { logs } = stubLogs({
    diagnostics: { "review-41": { path: "/gitdir/logs/review-41.1.log", tail: "reviewer crashed" } },
  });
  await runOnce({ gh, tmux, logs, log: (m) => lines.push(m) });
  assert.deepEqual(reviews, [[41, 72]], "the relaunch still happens");
  const diagnostic = lines.find((m) => m.includes("review-41.1.log"));
  assert.match(diagnostic, /#41/);
  assert.match(diagnostic, /https:\/\/gh\/pr\/72/);
  assert.match(diagnostic, /reviewer crashed/);
});

test("runOnce logs no reviewer diagnostic on a first launch", async () => {
  const lines = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
  });
  await runOnce({ gh, tmux: stubTmux(), logs: stubLogs().logs, log: (m) => lines.push(m) });
  assert.equal(lines.some((m) => m.includes("previous reviewer")), false);
});

test("runOnce launches one reviewer for an agent-review PR with no applicable marker", async () => {
  const reviews = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
  });
  const tmux = stubTmux({ openReviewer: async (i, p) => reviews.push([i, p]) });
  const res = await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(reviews, [[41, 72]]);
  assert.equal(res.reviewsStarted, 1);
});

test("runOnce launches at most one reviewer, oldest PR first", async () => {
  const reviews = [];
  const gh = stubGh({
    listRunningIssues: async () => [
      runIssue(41, ["agent-running", "agent-review"]),
      runIssue(12, ["agent-running", "agent-review"]),
    ],
    listOpenPrs: async () => [
      runPr(72, { createdAt: "2026-08-01T09:00:00Z" }),
      runPr(60, { headRefName: "agent/12-y", createdAt: "2026-07-30T09:00:00Z", closingIssuesReferences: [{ number: 12 }] }),
    ],
  });
  const tmux = stubTmux({ openReviewer: async (i, p) => reviews.push([i, p]) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(reviews, [[12, 60]]);
});

test("runOnce does not relaunch a reviewer that is still running", async () => {
  const reviews = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
  });
  const tmux = stubTmux({ listReviewIssues: async () => new Set([41]), openReviewer: async (...a) => reviews.push(a) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(reviews, []);
});

test("runOnce relaunches a reviewer that crashed without posting a marker", async () => {
  const reviews = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
    listPrComments: async () => [{ body: "I ran out of context" }],
  });
  const tmux = stubTmux({ listReviewIssues: async () => new Set(), openReviewer: async (...a) => reviews.push(a) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(reviews, [[41, 72]]);
});

test("runOnce discards a stale review and queues a fresh pass without transitioning", async () => {
  const reviews = [];
  const transitions = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, { headRefOid: "f".repeat(40) })],
    listPrComments: async () => [markerComment("PASS")],
    setIssueLabels: async (...a) => transitions.push(a),
    markPrReady: async (...a) => transitions.push(["ready", ...a]),
  });
  const tmux = stubTmux({ openReviewer: async (...a) => reviews.push(a) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(transitions, []);
  assert.deepEqual(reviews, [[41, 72]]);
});

test("runOnce applies a clean verdict by opening the draft PR", async () => {
  const ready = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, { isDraft: true })],
    listPrComments: async () => [markerComment("PASS")],
    markPrReady: async (n) => ready.push(n),
  });
  await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.deepEqual(ready, [72]);
});

test("runOnce ignores a marker authored by anyone but the supervisor's App identity", async () => {
  const reviews = [];
  const transitions = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, { isDraft: true })],
    listPrComments: async () => [markerComment("PASS", { viewerDidAuthor: false })],
    markPrReady: async (...a) => transitions.push(["ready", ...a]),
    setIssueLabels: async (...a) => transitions.push(a),
  });
  const tmux = stubTmux({ openReviewer: async (...a) => reviews.push(a) });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(transitions, []);
  assert.deepEqual(reviews, [[41, 72]]);
});

test("runOnce ignores a marker that names another issue or PR", async () => {
  for (const override of [{ issue: 40 }, { pr: 71 }]) {
    const transitions = [];
    const gh = stubGh({
      listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
      listOpenPrs: async () => [runPr(72, { isDraft: true })],
      listPrComments: async () => [markerComment("PASS", override)],
      markPrReady: async (...a) => transitions.push(["ready", ...a]),
      setIssueLabels: async (...a) => transitions.push(a),
    });
    await runOnce({ gh, tmux: stubTmux(), log: () => {} });
    assert.deepEqual(transitions, [], JSON.stringify(override));
  }
});

test("runOnce discards a marker whose fingerprint predates an issue- or PR-body edit", async () => {
  const edits = [
    { issue: { body: "Issue body edited\n" }, pr: {} },
    { issue: {}, pr: { body: "PR body edited\n" } },
  ];
  for (const edit of edits) {
    const transitions = [];
    const gh = stubGh({
      listRunningIssues: async () => [{ ...runIssue(41, ["agent-running", "agent-review"]), ...edit.issue }],
      listOpenPrs: async () => [runPr(72, { isDraft: true, ...edit.pr })],
      listPrComments: async () => [markerComment("PASS")],
      markPrReady: async (...a) => transitions.push(["ready", ...a]),
      setIssueLabels: async (...a) => transitions.push(a),
    });
    await runOnce({ gh, tmux: stubTmux(), log: () => {} });
    assert.deepEqual(transitions, [], JSON.stringify(edit));
  }
});

test("runOnce reconciles an applicable marker after a restart without launching a second reviewer", async () => {
  const ready = [];
  const reviews = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, { isDraft: true })],
    // A later comment moved prUpdatedAt; the pass still applies.
    listPrComments: async () => [markerComment("PASS"), { body: "unrelated chatter", viewerDidAuthor: false }],
    markPrReady: async (n) => ready.push(n),
  });
  const tmux = stubTmux({ openReviewer: async (...a) => reviews.push(a) });
  const res = await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(ready, [72]);
  assert.deepEqual(reviews, []);
  assert.equal(res.reviewsStarted, 0);
});

test("runOnce promotes a clean, ready, green PR to user-merge-review", async () => {
  const labels = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, { isDraft: false, statusCheckRollup: [] })],
    listPrComments: async () => [markerComment("PASS")],
    setIssueLabels: async (n, d) => labels.push([n, d]),
  });
  const res = await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.deepEqual(labels, [[41, { add: ["user-merge-review"], remove: ["agent-review"] }]]);
  assert.equal(res.done, true);
});

test("runOnce blocks a PR whose review verdict is blocking", async () => {
  const labels = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, { isDraft: false })],
    listPrComments: async () => [markerComment("BLOCKING")],
    setIssueLabels: async (n, d) => labels.push([n, d]),
  });
  const res = await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.deepEqual(labels, [[41, { add: ["agent-blocked"], remove: ["agent-review"] }]]);
  assert.equal(res.done, true);
});

test("runOnce keeps agent-review while checks are pending and starts no reviewer", async () => {
  const reviews = [];
  const labels = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, {
      isDraft: false,
      statusCheckRollup: [{ __typename: "CheckRun", name: "ci", status: "IN_PROGRESS", conclusion: null }],
    })],
    listPrComments: async () => [markerComment("PASS")],
    setIssueLabels: async (n, d) => labels.push([n, d]),
  });
  const tmux = stubTmux({ openReviewer: async (...a) => reviews.push(a) });
  const res = await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(labels, []);
  assert.deepEqual(reviews, []);
  assert.equal(res.done, false);
});

test("runOnce blocks a clean reviewed PR when its check is stale at the poll clock", async () => {
  const calls = [];
  let clockReads = 0;
  const checkedAt = Date.parse("2026-08-02T12:00:00Z");
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, {
      isDraft: false,
      statusCheckRollup: [{
        __typename: "CheckRun",
        name: "integration",
        status: "IN_PROGRESS",
        conclusion: null,
        startedAt: "2026-08-02T05:00:00Z",
        detailsUrl: "https://ci.example/integration",
      }],
    })],
    listPrComments: async () => [markerComment("PASS")],
    commentPr: async (n, body) => calls.push(["commentPr", n, body]),
    markPrDraft: async (n) => calls.push(["markPrDraft", n]),
    setIssueLabels: async (n, delta) => calls.push(["setIssueLabels", n, delta]),
    setPrLabels: async (n, delta) => calls.push(["setPrLabels", n, delta]),
  });

  const result = await runOnce({
    gh,
    tmux: stubTmux(),
    now: () => { clockReads += 1; return checkedAt; },
    log: () => {},
  });

  assert.equal(clockReads, 1);
  assert.match(calls[0][2], /integration/);
  assert.match(calls[0][2], /7 hours/);
  assert.match(calls[0][2], /https:\/\/ci\.example\/integration/);
  assert.deepEqual(calls.slice(1), [
    ["markPrDraft", 72],
    ["setIssueLabels", 41, { add: ["agent-blocked"], remove: ["agent-review"] }],
    ["setPrLabels", 72, { add: ["agent-blocked"], remove: ["agent-review"] }],
  ]);
  assert.equal(result.done, true);
});

test("runOnce blocks and comments when required checks fail", async () => {
  const comments = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72, {
      isDraft: false,
      statusCheckRollup: [{ __typename: "CheckRun", name: "unit", status: "COMPLETED", conclusion: "FAILURE", detailsUrl: "https://ci/unit" }],
    })],
    listPrComments: async () => [markerComment("PASS")],
    commentPr: async (n, b) => comments.push(b),
  });
  await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.match(comments[0], /unit/);
  assert.match(comments[0], /https:\/\/ci\/unit/);
});

test("runOnce ignores a manual PR with no linked agent-running issue", async () => {
  const events = [];
  const gh = stubGh({
    listRunningIssues: async () => [],
    listOpenPrs: async () => [runPr(99, { headRefName: "agent/5-manual", closingIssuesReferences: [{ number: 5 }] })],
    listPrComments: async () => { events.push("comments"); return []; },
    setPrLabels: async () => events.push("labels"),
  });
  const res = await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.deepEqual(events, []);
  assert.equal(res.done, true);
});

test("runOnce repairs a PR whose labels disagree with the issue", async () => {
  const prLabels = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "user-merge-review"])],
    listOpenPrs: async () => [runPr(72, { isDraft: false, labels: ["agent-review"] })],
    setPrLabels: async (n, d) => prLabels.push([n, d]),
  });
  await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.deepEqual(prLabels, [[72, { add: ["agent-running", "user-merge-review"], remove: ["agent-review"] }]]);
});

test("runOnce fails closed when two PRs close the same issue", async () => {
  const comments = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72), runPr(73)],
    commentIssue: async (n, b) => comments.push(b),
  });
  await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.match(comments[0], /more than one open PR/);
});

test("runOnce fails closed when an agent-review issue has no PR", async () => {
  const comments = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [],
    commentIssue: async (n, b) => comments.push(b),
  });
  await runOnce({ gh, tmux: stubTmux(), log: () => {} });
  assert.match(comments[0], /no open PR closes it/);
});

test("runOnce isolates one issue's failure from the rest of the poll", async () => {
  const opened = [];
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
    listPrComments: async () => { throw new Error("comment fetch failed"); },
    listReadyIssues: async () => [9],
  });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(opened, [9]);
  assert.equal(res.done, false);
});

test("open failure restores GitHub labels", async () => {
  const restored = [];
  const gh = stubGh({ listReadyIssues: async () => [3], restore: async (n) => restored.push(n) });
  const tmux = stubTmux({ openWorker: async () => { throw new Error("tmux dead"); } });
  await runOnce({ gh, tmux, log: () => {} });
  assert.deepEqual(restored, [3]);
});

test("open failure logs the original failure plus a restore cleanup failure", async () => {
  const logs = [];
  const gh = stubGh({
    listReadyIssues: async () => [3],
    restore: async () => { throw new Error("label API down"); },
  });
  const tmux = stubTmux({ openWorker: async () => { throw new Error("tmux dead"); } });
  await runOnce({ gh, tmux, log: (m) => logs.push(m) });
  const line = logs.find((m) => m.includes("failed to start #3"));
  assert.match(line, /tmux dead/);
  assert.match(line, /label API down/);
});

test("runOnce pauses both worker and reviewer launches until agent setup completes", async () => {
  const opened = [];
  const reviews = [];
  const gh = stubGh({
    listReadyIssues: async () => [9],
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
  });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n), openReviewer: async (...a) => reviews.push(a) });
  const res = await runOnce({ gh, tmux, checkSetupReady: async () => false, log: () => {} });
  assert.deepEqual(opened, []);
  assert.deepEqual(reviews, []);
  assert.equal(res.done, false);
});

test("runOnce is done only when every managed issue rests in a terminal phase", async () => {
  const gh = stubGh({
    listRunningIssues: async () => [
      runIssue(41, ["agent-running", "agent-blocked"]),
      runIssue(12, ["agent-running", "user-merge-review"]),
    ],
    listOpenPrs: async () => [
      runPr(72, { isDraft: true, labels: ["agent-running", "agent-blocked"] }),
      runPr(60, { headRefName: "agent/12-y", isDraft: false, labels: ["agent-running", "user-merge-review"], closingIssuesReferences: [{ number: 12 }] }),
    ],
  });
  assert.equal((await runOnce({ gh, tmux: stubTmux(), log: () => {} })).done, true);
});

test("runOnce is not done while a managed issue is still in review", async () => {
  const gh = stubGh({
    listRunningIssues: async () => [runIssue(41, ["agent-running", "agent-review"])],
    listOpenPrs: async () => [runPr(72)],
    listPrComments: async () => [],
  });
  assert.equal((await runOnce({ gh, tmux: stubTmux(), log: () => {} })).done, false);
});

test("runOnce is done when nothing is queued and nothing is managed", async () => {
  assert.equal((await runOnce({ gh: stubGh(), tmux: stubTmux(), log: () => {} })).done, true);
});
