import { test } from "node:test";
import assert from "node:assert/strict";
import { createSentinelClient } from "../src/usageGate.mjs";

function response(status, body) {
  return {
    status,
    async json() {
      if (body instanceof Error) throw body;
      return body;
    },
  };
}

function recordingFetch(reply) {
  const calls = [];
  return {
    calls,
    fetchImpl: async (...args) => {
      calls.push(args);
      return typeof reply === "function" ? reply(...args) : reply;
    },
  };
}

function validTelemetry({ short = 42, weekly = 73 } = {}) {
  return {
    provider: "claude-code",
    fetchedAt: "2026-07-24T12:00:00.000Z",
    status: "ok",
    windows: {
      short: { usedPercent: short, resetsAt: null, windowSeconds: 18000 },
      long: { usedPercent: weekly, resetsAt: null, windowSeconds: 604800 },
    },
  };
}

test("checkAdmission admits valid telemetry below the default thresholds", async () => {
  const fetch = recordingFetch(response(200, validTelemetry()));

  const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).checkAdmission();

  assert.deepEqual(result, { allowed: true, reason: "admitted" });
  assert.equal(fetch.calls.length, 1);
  const [requestUrl, options] = fetch.calls[0];
  assert.equal(requestUrl, "http://usage-sentinel:4317/usage/claude-code");
  assert.equal(options.method, "GET");
  assert.equal(options.body, undefined);
  assert.ok(options.signal instanceof AbortSignal);
});

test("an explicit URL overrides the default URL", async () => {
  const fetch = recordingFetch(response(200, validTelemetry()));

  await createSentinelClient({ fetchImpl: fetch.fetchImpl, url: "http://sentinel.test:9999/" }).checkAdmission();

  assert.equal(fetch.calls[0][0], "http://sentinel.test:9999/usage/claude-code");
});

for (const [name, telemetry] of [
  ["short threshold", validTelemetry({ short: 80 })],
  ["weekly threshold", validTelemetry({ weekly: 95 })],
]) {
  test(`checkAdmission denies telemetry at the ${name}`, async () => {
    const client = createSentinelClient({ fetchImpl: async () => response(200, telemetry) });
    assert.deepEqual(await client.checkAdmission(), { allowed: false, reason: "threshold_reached" });
  });
}

test("checkAdmission accepts constructor threshold overrides", async () => {
  const client = createSentinelClient({
    fetchImpl: async () => response(200, validTelemetry({ short: 80, weekly: 95 })),
    shortThreshold: 81,
    weeklyThreshold: 96,
  });

  assert.deepEqual(await client.checkAdmission(), { allowed: true, reason: "admitted" });
});

for (const [name, overrides] of [
  ["NaN short threshold", { shortThreshold: Number.NaN }],
  ["string short threshold", { shortThreshold: "80" }],
  ["negative weekly threshold", { weeklyThreshold: -1 }],
  ["weekly threshold above 100", { weeklyThreshold: 101 }],
]) {
  test(`checkAdmission fails closed on ${name}`, async () => {
    const client = createSentinelClient({
      fetchImpl: async () => response(200, validTelemetry()),
      ...overrides,
    });
    assert.deepEqual(await client.checkAdmission(), { allowed: false, reason: "telemetry_unavailable" });
  });
}

for (const [name, telemetry] of [
  ["stale status", { ...validTelemetry(), status: "stale" }],
  ["wrong provider", { ...validTelemetry(), provider: "codex" }],
  ["non-numeric percentage", { ...validTelemetry(), windows: { short: { usedPercent: "42" }, long: { usedPercent: 73 } } }],
  ["missing weekly window", { ...validTelemetry(), windows: { short: { usedPercent: 42 } } }],
]) {
  test(`checkAdmission maps ${name} to telemetry_unavailable`, async () => {
    const client = createSentinelClient({ fetchImpl: async () => response(200, telemetry) });
    assert.deepEqual(await client.checkAdmission(), { allowed: false, reason: "telemetry_unavailable" });
  });
}

test("the timeout fails closed even when fetch ignores the abort signal", async () => {
  const client = createSentinelClient({
    fetchImpl: async () => new Promise(() => {}),
    timeoutMs: 5,
  });

  const result = await Promise.race([
    client.checkAdmission(),
    new Promise((resolve) => setTimeout(() => resolve("test timed out"), 50)),
  ]);

  assert.notEqual(result, "test timed out");
  assert.equal(result.allowed, false);
});

test("the timeout fails closed when the response body never resolves", async () => {
  const client = createSentinelClient({
    fetchImpl: async () => response(200, new Promise(() => {})),
    timeoutMs: 5,
  });

  const result = await Promise.race([
    client.checkAdmission(),
    new Promise((resolve) => setTimeout(() => resolve("test timed out"), 50)),
  ]);

  assert.notEqual(result, "test timed out");
  assert.equal(result.allowed, false);
});

test("registerWorker sends the exact worker registration request", async () => {
  const fetch = recordingFetch((requestUrl) => requestUrl.endsWith("/usage/claude-code")
    ? response(200, validTelemetry())
    : response(201, { allowed: true, reason: "registered" }));

  const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).registerWorker("org/repo#21");

  assert.deepEqual(result, { allowed: true, reason: "registered" });
  assert.equal(fetch.calls.length, 2);
  const [requestUrl, options] = fetch.calls[1];
  assert.equal(requestUrl, "http://usage-sentinel:4317/workers");
  assert.equal(options.method, "POST");
  assert.deepEqual(options.headers, { "content-type": "application/json" });
  assert.equal(options.body, JSON.stringify({ provider: "claude-code", owner: "org/repo#21" }));
  assert.ok(options.signal instanceof AbortSignal);
});

test("registerWorker accepts an existing worker refresh", async () => {
  const client = createSentinelClient({
    fetchImpl: async (requestUrl) => requestUrl.endsWith("/usage/claude-code")
      ? response(200, validTelemetry())
      : response(200, { allowed: true, reason: "refreshed" }),
  });

  assert.deepEqual(await client.registerWorker("org/repo#21"), { allowed: true, reason: "refreshed" });
});

for (const [status, reason] of [
  [409, "capacity_reached"],
  [429, "threshold_reached"],
  [503, "telemetry_unavailable"],
]) {
  test(`registerWorker preserves the ${status} ${reason} denial`, async () => {
    const client = createSentinelClient({
      fetchImpl: async (requestUrl) => requestUrl.endsWith("/usage/claude-code")
        ? response(200, validTelemetry())
        : response(status, { allowed: false, reason }),
    });

    assert.deepEqual(await client.registerWorker("org/repo#21"), { allowed: false, reason });
  });
}

for (const [reason, telemetry] of [
  ["threshold_reached", validTelemetry({ short: 80 })],
  ["telemetry_unavailable", { ...validTelemetry(), status: "stale" }],
]) {
  test(`registerWorker does not POST when admission returns ${reason}`, async () => {
    const fetch = recordingFetch(response(200, telemetry));

    const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).registerWorker("org/repo#21");

    assert.deepEqual(result, { allowed: false, reason });
    assert.equal(fetch.calls.length, 1);
    assert.equal(fetch.calls[0][0], "http://usage-sentinel:4317/usage/claude-code");
  });
}

test("unregisterWorker sends the exact deletion request and accepts only 204", async () => {
  const fetch = recordingFetch(response(204));

  const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).unregisterWorker("org/repo#21");

  assert.deepEqual(result, { allowed: true, reason: "unregistered" });
  const [requestUrl, options] = fetch.calls[0];
  assert.equal(requestUrl, "http://usage-sentinel:4317/workers");
  assert.equal(options.method, "DELETE");
  assert.deepEqual(options.headers, { "content-type": "application/json" });
  assert.equal(options.body, JSON.stringify({ provider: "claude-code", owner: "org/repo#21" }));
  assert.ok(options.signal instanceof AbortSignal);
});

const malformedJson = response(200, new SyntaxError("bad json"));
const failureCases = [
  ["network rejection", async () => { throw new Error("ECONNREFUSED"); }],
  ["abort", async (_url, { signal }) => {
    await new Promise((resolve, reject) => {
      signal.addEventListener("abort", () => reject(signal.reason), { once: true });
    });
  }],
  ["malformed JSON", async () => malformedJson],
  ["unexpected status", async () => response(418, validTelemetry())],
  ["unknown telemetry shape", async () => response(200, { allowed: true, reason: "maybe" })],
  ["non-ok telemetry", async () => response(200, { ...validTelemetry(), status: "error" })],
];

for (const [name, fetchImpl] of failureCases) {
  test(`checkAdmission fails closed on ${name}`, async () => {
    const result = await createSentinelClient({ fetchImpl, timeoutMs: 5 }).checkAdmission();
    assert.equal(result.allowed, false);
    assert.equal(typeof result.reason, "string");
    assert.ok(result.reason.length > 0);
  });
}

for (const [name, fetchImpl] of failureCases) {
  test(`registerWorker fails closed on ${name}`, async () => {
    const result = await createSentinelClient({
      fetchImpl: async (requestUrl, options) => requestUrl.endsWith("/usage/claude-code")
        ? response(200, validTelemetry())
        : fetchImpl(requestUrl, options),
      timeoutMs: 5,
    }).registerWorker("org/repo#21");
    assert.equal(result.allowed, false);
    assert.equal(typeof result.reason, "string");
    assert.ok(result.reason.length > 0);
  });
}

for (const [name, fetchImpl] of [
  ...failureCases.slice(0, 4),
  ["unexpected response body", async () => response(200, { allowed: true, reason: "unregistered" })],
]) {
  test(`unregisterWorker fails closed on ${name}`, async () => {
    const result = await createSentinelClient({ fetchImpl, timeoutMs: 5 }).unregisterWorker("org/repo#21");
    assert.equal(result.allowed, false);
    assert.equal(typeof result.reason, "string");
    assert.ok(result.reason.length > 0);
  });
}
