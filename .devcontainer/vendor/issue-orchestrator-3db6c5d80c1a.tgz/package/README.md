# issue-orchestrator

A small, supervised issue queue. A single Node supervisor picks up open issues
labeled `agent-ready` (ascending) and keeps at most **three** autonomous
`claude` workers alive — each in its own tmux window running:

```bash
claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

Workers are gated by [Usage Sentinel](https://github.com/Sadotu/usage-sentinel).
The full model name pins issue workers to Opus 4.8 instead of the Claude Code
default or the moving `opus` alias.

## Orchestrator

Zero-dependency Node ≥20.8.0 on Linux (the supervisor guard uses a Linux abstract
Unix socket). No build step.

### Installed/current-repository usage

The npm package installs the `issue-orchestrator` binary. Run it from the
target project repository, not from the package checkout:

```bash
cd /path/to/target-project
issue-orchestrator
```

The shared [`agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
also exposes that command through the literal alias:

```bash
start work
```

The supervisor resolves the `origin` of that current working directory,
checks GitHub App authentication, checks Sentinel before admitting/starting
workers, and starts autonomous workers itself:

```bash
claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

Non-interactive print mode skips the workspace-trust prompt, and each process
exits after its command finishes. Sentinel failures fail closed. Do not start
Claude separately.

Only one supervisor per repository per Linux network namespace may run at a
time. A second invocation in the same namespace for the same resolved
`owner/repo` exits nonzero with an `already running` error before
authentication, Sentinel, tmux, or worker startup. Ownership is held by a
kernel-owned Linux abstract Unix socket, so it is released on normal exit and
automatically when the supervisor process dies. Devcontainers normally have
distinct network namespaces and therefore independent guards; containers that
share a network namespace also share this guard.

Neither the image build nor devcontainer startup launches the supervisor or
an LLM. Work begins only when a user explicitly runs `issue-orchestrator` or
its `start work` alias.

### Repository-checkout usage

```bash
npm test                 # node --test over test/
node bin/supervisor.mjs  # start the supervisor loop
tmux attach -t orchestrator   # watch the workers directly
```

### How it works

- **Claim** — the lowest-numbered `agent-ready` issue has its label swapped
  `agent-ready` → `agent-running`, then a tmux window `issue-<n>` opens running
  this autonomous command:

  ```bash
  claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <n>"
  ```

  Non-interactive print mode skips the workspace-trust prompt; the process exits
  and its tmux window closes after the command finishes. State lives entirely in
  GitHub labels, PR draft status, and tmux windows — there is no durable state
  file.
- **Complete** — when a worker's PR flips from draft to ready-for-review, the
  supervisor closes its tmux window, unregisters its stable Sentinel owner,
  then removes `agent-running`. An already-closed window is treated as closed;
  a failure at any later step is logged and retried by the next poll.
- **Vanished** — if a worker window disappears while its PR is still draft,
  its Sentinel owner is unregistered before `agent-running` is removed. The
  issue number and draft PR URL are surfaced, and the issue is **not** restarted
  automatically because its draft PR or worktree may still exist.
- **Admission and capacity** — before registration, the supervisor reads
  Sentinel's `GET /usage/claude-code` telemetry and admits only when short-window
  usage is below 80% and weekly usage is below 95%. Sentinel's `POST /workers`
  remains authoritative for registration and the combined global limit of
  three workers across every connected repository. The supervisor also keeps a
  cheap local maximum-three guard. A
  stable owner (`<repository>#<issue-number>`) is registered before claim and
  tmux creation; claim failure unregisters it, while tmux failure unregisters
  it and restores the labels. Every live worker is heartbeated each poll, and
  `registered` is accepted as well as `refreshed` so Sentinel can rebuild its
  registry after a restart. A failed heartbeat prevents new starts but does not
  stop an existing worker.
- **Stop** — the supervisor exits when no claimable issues and no live workers
  remain. It does not terminate healthy workers merely because admission later
  closes.

### GitHub authentication

`gh` does not auto-consume the GitHub App credential, so the supervisor mints a
short-lived App installation token (via `gh-app-token.sh`, overridable with
`GH_APP_TOKEN_SCRIPT`) and injects it as `GH_TOKEN` for every `gh` call,
re-minting each poll. At startup it runs an authenticated `gh repo view` smoke
check and exits with a clear message if the App is not authenticated — rather
than churning on unauthenticated calls every poll.

### Configuration

The local concurrency guard is fixed at 3. Two knobs are environment-tunable:

| Var | Default | Meaning |
|-----|---------|---------|
| `SENTINEL_URL` | `http://usage-sentinel:4317` | Usage Sentinel base URL on the shared container network; set this explicitly (for example, `http://host.docker.internal:4317`) only when Sentinel is exposed on the host |
| `POLL_MS` | `60000` | Poll interval |

Labels: `agent-ready` (claimable) and `agent-running` (claimed/live). The
repository already defines these; the supervisor only swaps between them.

### Sub-agent usage gate

`.claude/settings.json` registers a `PreToolUse` hook matching the `Agent`
tool at `hooks/pretooluse-usage-gate.mjs`. Before a sub-agent is created, it
uses the same local admission decision as worker registration preflight: read
`GET /usage/claude-code`, require valid telemetry reported with status `ok`, and
require both the short window to be below 80% and the weekly window to be below
95%. The hook never registers another worker because the sub-agent belongs to
the top-level worker tree; only top-level registration calls `POST /workers`.
The hook fails closed and exits `2` for a reached threshold, invalid response,
timeout, or connection failure. Valid telemetry below both thresholds exits `0`.

### Manual two-devcontainer smoke check

Run this integration check manually against a standalone Usage Sentinel; do not
substitute a mocked server. The exact Sentinel image/start command depends on
that repository, but its container must be named `usage-sentinel`, listen on
port `4317`, and join a Docker network named `agent-services`.

1. Start standalone Sentinel and create/connect its network if necessary:
   `docker network create agent-services` followed by the Sentinel repository's
   documented start command, then
   `docker network connect agent-services usage-sentinel` if it was not already
   attached.
2. Start two different project devcontainers. From the host, connect each
   container with `docker network connect agent-services <container-name>`.
3. In **both** devcontainers, run
   `curl -fsS http://usage-sentinel:4317/usage/claude-code` to prove shared DNS
   and reachability. Confirm the response reports provider `claude-code`, status
   `ok`, and numeric `windows.short.usedPercent` and
   `windows.long.usedPercent` values.
4. With both values below their thresholds, exercise the Agent hook from a
   repository checkout:
   `printf '%s' '{"tool_name":"Agent"}' | node hooks/pretooluse-usage-gate.mjs`.
   It should exit `0`. This is the local admission check used by an already-running
   top-level worker before it starts a sub-agent; it does not register a worker.
5. Test Sentinel's shared capacity directly. From the first devcontainer,
   register two owners:

   ```bash
   curl -i -X POST -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/a#1"}' http://usage-sentinel:4317/workers
   curl -i -X POST -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/a#2"}' http://usage-sentinel:4317/workers
   ```

   From the second devcontainer, register a third owner, then attempt a fourth:

   ```bash
   curl -i -X POST -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/b#1"}' http://usage-sentinel:4317/workers
   curl -i -X POST -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/b#2"}' http://usage-sentinel:4317/workers
   ```

   The first three requests should return `201 registered`; the fourth should
   return `409` with `{"allowed":false,"reason":"capacity_reached"}`. These
   direct requests isolate Sentinel's authoritative global capacity. They
   bypass the client's local registration preflight, which is exercised by the
   focused unit/integration tests.
6. The live threshold check is conditional: Sentinel exposes no public command
   here for changing provider usage. If usage naturally or externally reaches
   short >= 80% or weekly >= 95%, first confirm that value with
   `curl -fsS http://usage-sentinel:4317/usage/claude-code`. Then, from a
   repository checkout, run:

   ```bash
   hook_stderr=$(mktemp)
   if printf '%s' '{"tool_name":"Agent"}' | node hooks/pretooluse-usage-gate.mjs 2>"$hook_stderr"; then
     hook_status=0
   else
     hook_status=$?
   fi
   test "$hook_status" -eq 2
   grep -F threshold_reached "$hook_stderr"
   rm "$hook_stderr"
   ```

   Both assertions must succeed. An already-running worker is not terminated,
   but its next Agent invocation is blocked. For an existing live worker, the
   supervisor's next poll should log
   `worker heartbeat failed for #<n>: threshold_reached`; the heartbeat
   preflight makes no `POST /workers`, and its failure short-circuits new starts
   for that poll. `Usage gate closed — pausing new starts` instead applies to a
   new-start registration attempt when no live heartbeat failure has already
   short-circuited the poll.
7. Clean up every registered smoke owner with the same request body used to
   register it, changing the method to DELETE:
   `curl -i -X DELETE -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/a#1"}' http://usage-sentinel:4317/workers`.
   Repeat for all owners, including any denied fourth-owner attempt if Sentinel
   retained it unexpectedly. Optionally detach the test containers afterward
   with `docker network disconnect agent-services <container-name>` (including
   `usage-sentinel` if it should not remain attached).
8. Using the [smoke-check record guide](docs/smoke-checks/README.md), create and
   commit a dated, revision-specific record of the commands, responses,
   environment details, and pass/fail result.
   This repository does not claim that smoke check has run merely from the unit-test result.

## Repo contents

| Path | Purpose |
|------|---------|
| `agents.toml` / `agents.lock` | [dotagents](https://github.com/Sadotu/agent-skills) manifest — declares which skills are installed and pins their source commits |
| `.agents/skills/` | Installed skills (`github-issue`, `setup`) — managed artifacts, restored from the manifest, not committed |
| `.claude/skills` | Symlink to `.agents/skills` so Claude Code picks the skills up |
| `CLAUDE.md` | Agent instructions and gotchas for working in this repo |

## Skills

- **`github-issue`** — runs a GitHub issue end to end: select issue, open a
  draft PR immediately, self-resolve design decisions (logged to the PR),
  implement in an isolated worktree, verify against the issue, mark ready.
- **`setup`** — connects the repo to the `container-coding-agent` GitHub App
  and verifies `git`/`gh` authenticate as the App.

Both are sourced from [`Sadotu/agent-skills`](https://github.com/Sadotu/agent-skills).

## Development environment

Agents work on this repo from a shared, sandboxed devcontainer. That
environment is **not part of this app** — it lives in its own repo:
[`Sadotu/agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
(image, setup scripts, security model, auth docs). A local `.devcontainer/`
folder pointing at that image may exist in a checkout but is gitignored.

GitHub access is via the scoped `container-coding-agent` GitHub App — never a
personal token, never `gh auth login`. See `CLAUDE.md` for the auth wiring.
