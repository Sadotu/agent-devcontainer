#!/usr/bin/env node
import { createSentinelClient } from "../src/usageGate.mjs";
import { writePauseRecord } from "../src/pauseStore.mjs";
import { execFile } from "node:child_process";
export async function terminateCurrentWindow(pane, { execFileImpl = execFile } = {}) {
  await new Promise((resolve, reject) => {
    execFileImpl(
      "tmux",
      ["kill-window", "-t", pane],
      { timeout: 1000, killSignal: "SIGKILL" },
      (error) => error ? reject(error) : resolve(),
    );
  });
}

async function readStdin() {
  const chunks = [];
  for await (const c of process.stdin) chunks.push(c);
  return Buffer.concat(chunks).toString("utf8");
}

export async function runAdmissionHook(payload, {
  env = process.env,
  fetchImpl = fetch,
  writePause = writePauseRecord,
  terminateWindow = terminateCurrentWindow,
  now = () => new Date(),
} = {}) {
  const url = env.SENTINEL_URL || "http://usage-sentinel:4317";
  let admission;
  try {
    admission = await createSentinelClient({ url, fetchImpl }).checkAdmission();
  } catch {
    admission = { allowed: false, reason: "telemetry_unavailable" };
  }
  if (admission.allowed === true && admission.reason === "admitted") return admission;

  const issue = Number(env.ISSUE_ORCHESTRATOR_ISSUE);
  const directory = env.ISSUE_ORCHESTRATOR_PAUSE_DIR;
  const pane = env.TMUX_PANE;
  const values = [payload?.session_id, payload?.tool_use_id, payload?.tool_name, payload?.cwd];
  if (!Number.isInteger(issue) || issue <= 0
    || typeof directory !== "string" || directory.trim() === ""
    || typeof pane !== "string" || !/^%\d+$/.test(pane)
    || values.some((value) => typeof value !== "string" || value.trim() === "")) {
    return { allowed: false, reason: "invalid_pause_context" };
  }

  const record = {
    issue,
    sessionId: payload.session_id,
    toolUseId: payload.tool_use_id,
    toolName: payload.tool_name,
    cwd: payload.cwd,
    reason: admission.reason,
    pausedAt: now().toISOString(),
    tmuxPane: pane,
  };
  try {
    await writePause(directory, record);
  } catch {
    return { allowed: false, reason: "pause_write_failed" };
  }
  try {
    await terminateWindow(pane);
  } catch {
    return { allowed: false, reason: "termination_failed" };
  }
  return admission;
}

async function main() {
  let payload;
  try {
    const raw = await readStdin();
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    process.exit(2);
  }

  const result = await runAdmissionHook(payload);
  if (result.allowed === true && result.reason === "admitted") process.exit(0);
  process.stderr.write(`Usage gate blocked tool use: ${result.reason}\n`);
  process.exit(2);
}

if (import.meta.url === `file://${process.argv[1]}`) main();
