#!/usr/bin/env node
import { open, rename, rm } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { join } from 'node:path';

async function readInput() {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

const input = await readInput();
const directory = process.env.ISSUE_ORCHESTRATOR_PAUSE_DIR;
const expectedSession = process.env.ISSUE_ORCHESTRATOR_RESUME_SESSION;
const generation = process.env.ISSUE_ORCHESTRATOR_RESUME_GENERATION;

if (
  input.source === 'resume'
  && input.session_id === expectedSession
  && typeof directory === 'string'
  && /^\d+-[a-f0-9]{64}\.json$/.test(generation ?? '')
) {
  const destination = join(directory, `.${generation}.resume-ack`);
  const temporary = join(directory, `.${generation}.${randomUUID()}.ack-tmp`);
  let fileHandle;
  let directoryHandle;
  try {
    fileHandle = await open(temporary, 'wx', 0o600);
    await fileHandle.writeFile(`${JSON.stringify({ sessionId: input.session_id, generation })}\n`, 'utf8');
    await fileHandle.sync();
    await fileHandle.close();
    fileHandle = undefined;
    await rename(temporary, destination);
    directoryHandle = await open(directory, 'r');
    await directoryHandle.sync();
    await directoryHandle.close();
    directoryHandle = undefined;
  } catch (error) {
    await fileHandle?.close().catch(() => {});
    await directoryHandle?.close().catch(() => {});
    await rm(temporary, { force: true }).catch(() => {});
    throw error;
  }
}
