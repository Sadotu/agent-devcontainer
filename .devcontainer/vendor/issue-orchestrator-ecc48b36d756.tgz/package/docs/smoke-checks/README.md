# Saved-session smoke check

This is a live integration procedure, not an automated test. It proves that a
real subscription-authenticated `ccode` issue worker is stopped at a tool
boundary and later resumes its exact Claude session. Do not claim PASS unless
all evidence below was captured; no run is claimed by this guide.

## External preconditions

- A disposable GitHub issue in a test repository, labels `agent-ready` and
  `agent-running`, GitHub App authentication, and permission to create a
  worktree, branch, and draft PR.
- The agent devcontainer's subscription-authenticated `ccode` alias and tmux.
  Do not replace `ccode` with API-key authentication.
- A real Usage Sentinel reachable at `SENTINEL_URL`. The operator must have a
  documented, safe way to move its real `claude-code` telemetry from below
  short/weekly thresholds (80%/95%) to closed and back open. This repository
  intentionally provides no command for changing Sentinel telemetry; record the
  Sentinel repository revision and its actual operator commands. Do not use a
  mock.
- Before the test, identify and record the real Sentinel command, log query, or
  UI procedure that shows whether the exact owner is registered. Sentinel has
  no registry-inspection endpoint standardized by this repository. Use that
  same procedure for every registration/unregistration observation below; an
  assumption based only on orchestrator logs is insufficient.
- Set a short `POLL_MS` (for example `1000`) only in this disposable test.
- Use a repository/container with no pre-existing `orchestrator` tmux session;
  the supervisor's session name is fixed and cleanup below removes that session.

## Procedure

1. In the repository root, create both disposable issues, capture their returned
   numbers, initialize the run-specific paths, record revisions, and verify the
   controlled environment:

   ```bash
   set -euo pipefail
   evidence_dir="$(mktemp -d /tmp/issue-orchestrator-smoke.XXXXXX)"
   primary_url="$(gh issue create \
     --title 'Smoke: saved-session pause and resume' \
     --body 'Disposable saved-session smoke issue; concrete harmless instructions will be added before labeling.')"
   second_url="$(gh issue create \
     --title 'Smoke: paused-first ordering competitor' \
     --body 'Disposable smoke issue. If claimed, create the normal draft PR, make no product changes, and report that this ordering-only smoke worker started.')"
   issue="${primary_url##*/}"
   second_issue="${second_url##*/}"
   [[ "$issue" =~ ^[1-9][0-9]*$ ]]
   [[ "$second_issue" =~ ^[1-9][0-9]*$ ]]
   go_file="/tmp/issue-orchestrator-resume-go-${issue}"
   marker="/tmp/issue-orchestrator-resume-marker-${issue}"
   primary_body="$(printf '%s\n' \
     'Disposable smoke issue. Create the normal worktree and draft PR.' \
     "Then use a Bash tool to run: while test ! -e '$go_file'; do sleep 1; done" \
     "After that tool returns, use a separate Bash tool to run: touch '$marker'" \
     'On recovery, reconcile state before retrying any interrupted tool.')"
   gh issue edit "$issue" --body "$primary_body"
   pane_log="$evidence_dir/issue-${issue}-pane.log"
   supervisor_log="$evidence_dir/supervisor.log"
   run_env="$evidence_dir/run.env"
   printf 'export issue=%q\nexport second_issue=%q\nexport evidence_dir=%q\nexport go_file=%q\nexport marker=%q\nexport pane_log=%q\nexport supervisor_log=%q\nexport SENTINEL_URL=%q\n' \
     "$issue" "$second_issue" "$evidence_dir" "$go_file" "$marker" \
     "$pane_log" "$supervisor_log" "$SENTINEL_URL" >"$run_env"
   printf 'In the dedicated supervisor terminal run exactly:\nsource %q\nPOLL_MS=1000 issue-orchestrator 2>&1 | tee "$supervisor_log"\n' "$run_env"
   git rev-parse HEAD
   git rev-parse --git-common-dir
   type ccode
   tmux -V
   ! tmux has-session -t orchestrator 2>/dev/null
   curl -fsS "$SENTINEL_URL/usage/claude-code"
   ```

   The response must be `status: "ok"`, with numeric
   `windows.short.usedPercent < 80` and `windows.long.usedPercent < 95`.

2. Add `agent-ready` only to the primary issue. Its harmless instructions make a
   marker only after an explicit wait point. The worker must first create its normal
   worktree and draft PR, then run a Bash tool containing `while test ! -e
   "$go_file"; do sleep 1; done` (with the issue-specific absolute path from
   step 1 embedded in the issue instructions),
   and only after that tool returns invoke a second Bash tool containing
   `touch "$marker"` (the created issue body contains the corresponding concrete
   issue-number convention). Run `gh issue edit "$issue" --add-label
   agent-ready`. In a dedicated foreground terminal, paste the exact `source`
   and supervisor commands printed by step 1; leave the pipeline running so its
   timestamped logs are preserved. In the control terminal, keep the initialized
   variables (or run `source "$run_env"`). After the primary draft PR exists,
   capture and validate its linked PR number:

   ```bash
   pr_number="$(gh pr list --state open --limit 100 \
     --json number,closingIssuesReferences \
     | jq -er --argjson issue "$issue" \
       '[.[] | select(any(.closingIssuesReferences[]?; .number == $issue)) | .number] | if length == 1 then .[0] else error("expected exactly one linked PR") end')"
   [[ "$pr_number" =~ ^[1-9][0-9]*$ ]]
   ```

   Capture the
   issue number, draft PR URL, worktree path, `issue-<n>` tmux window/pane, and
   Sentinel owner `<owner/repo>#<n>` registration, observed with the pre-recorded
   real-Sentinel registry procedure. The marker must not yet exist.

   Before closing admission, attach a tmux pipe and capture structured window
   evidence so output survives the intentional kill:

   ```bash
   quoted_pane_log="$(printf '%q' "$pane_log")"
   tmux pipe-pane -t "orchestrator:issue-${issue}" -o "cat >>$quoted_pane_log"
   tmux list-windows -t orchestrator -F '#{t:window_activity}\t#{window_name}\t#{pane_id}\t#{pane_pid}\t#{pane_current_command}\t#{pane_start_command}' \
     | tee "$evidence_dir/windows-before-pause.tsv"
   tmux capture-pane -p -S - -t "orchestrator:issue-${issue}" \
     >"$evidence_dir/pane-before-pause.txt"
   ```

3. Let the worker reach the wait point. Before giving it permission to invoke
   the marker tool, use Sentinel's recorded operator procedure to close
   admission, and prove the threshold with:

   ```bash
   curl -fsS "$SENTINEL_URL/usage/claude-code"
   test ! -e "$marker"
   gh issue edit "$second_issue" --add-label agent-ready
   gh issue view "$second_issue" --json labels | tee "$evidence_dir/second-closed.json"
   gh issue view "$second_issue" --json labels --jq '.labels[].name' | grep -Fx agent-ready
   touch "$go_file"
   ```

   The waiting tool may finish, but the separate marker tool is the next request:
   it must traverse the configured all-tools `PreToolUse` hook and must not
   execute. The second issue makes paused-first ordering observable rather than
   vacuous; while admission remains closed, prove it stays `agent-ready`.

4. Capture pause evidence before reopening admission:

   ```bash
   tmux list-windows -t orchestrator -F '#{t:window_activity}\t#{window_name}\t#{pane_id}\t#{pane_pid}\t#{pane_current_command}\t#{pane_start_command}' \
     | tee "$evidence_dir/windows-paused.tsv"
   repo_dir="$(pwd -P)"
   if test -n "${ISSUE_ORCHESTRATOR_PAUSE_DIR:-}"; then
     case "$ISSUE_ORCHESTRATOR_PAUSE_DIR" in
       /*) pause_dir="$ISSUE_ORCHESTRATOR_PAUSE_DIR" ;;
       *) pause_dir="$repo_dir/$ISSUE_ORCHESTRATOR_PAUSE_DIR" ;;
     esac
   else
     git_common="$(git rev-parse --git-common-dir)"
     case "$git_common" in
       /*) ;;
       *) git_common="$repo_dir/$git_common" ;;
     esac
     pause_dir="$git_common/issue-orchestrator/paused"
   fi
   pause_dir="$(realpath -m "$pause_dir")"
   ls -la "$pause_dir"
   mapfile -d '' pause_records < <(
     find "$pause_dir" -maxdepth 1 -type f -name "${issue}-*.json" -print0
   )
   test "${#pause_records[@]}" -eq 1
   pause_record="${pause_records[0]}"
   jq . "$pause_record" | tee "$evidence_dir/pause-record.json"
   session_id="$(jq -er '.sessionId' "$pause_record")"
   gh issue view "$issue" --json labels | tee "$evidence_dir/primary-paused.json"
   gh issue view "$second_issue" --json labels | tee "$evidence_dir/second-paused.json"
   gh pr view "$pr_number" --json isDraft,url,headRefName \
     | tee "$evidence_dir/pr-paused.json"
   test ! -e "$marker"
   grep -F "Usage gate blocked tool use:" "$pane_log"
   ```

   PASS evidence is: `issue-<n>` is absent; the marker is absent; the issue is
   still `agent-running`; the draft PR and worktree still exist; the pre-recorded
   real-Sentinel registry procedure shows the owner absent after the supervisor
   poll; and exactly one valid
   generation records the expected `issue`, exact `sessionId`, `toolUseId`,
   `toolName`, `cwd`, `reason`, `pausedAt`, and old `tmuxPane`. There must be no
   `agent-paused` label. The paused worker must not count as a live slot.

5. Note the current end of the supervisor log, then reopen Sentinel admission
   with its real operator procedure and capture telemetry. Watch the next poll.
   The pre-recorded registry
   procedure must show the owner registered fresh; the supervisor must log
   `Resumed worker for #<n>` and create exactly one `issue-<n>` window. Use
   tmux pane command/process evidence to verify the launch contains the exact
   recorded session ID. Capture labels, windows, and strict log ordering:

   ```bash
   reopen_line_count="$(wc -l <"$supervisor_log")"
   curl -fsS "$SENTINEL_URL/usage/claude-code" | tee "$evidence_dir/telemetry-reopened.json"
   # Run these after both timestamped messages appear in the foreground log.
   tail -n "+$((reopen_line_count + 1))" "$supervisor_log" \
     | tee "$evidence_dir/supervisor-after-reopen.log"
   resume_line="$(grep -nF "Resumed worker for #${issue}" "$evidence_dir/supervisor-after-reopen.log" | head -n1 | cut -d: -f1)"
   start_line="$(grep -nF "Started worker for #${second_issue}" "$evidence_dir/supervisor-after-reopen.log" | head -n1 | cut -d: -f1)"
   test -n "$resume_line" && test -n "$start_line" && test "$resume_line" -lt "$start_line"
   tmux list-windows -t orchestrator -F '#{t:window_activity}\t#{window_name}\t#{pane_id}\t#{pane_pid}\t#{pane_current_command}\t#{pane_start_command}' \
     | tee "$evidence_dir/windows-after-reopen.tsv"
   tmux list-panes -t "orchestrator:issue-${issue}" \
     -F '#{pane_id}\t#{pane_pid}\t#{pane_current_command}\t#{pane_start_command}' \
     | tee "$evidence_dir/resumed-pane.tsv"
   grep -F -- "--resume" "$evidence_dir/resumed-pane.tsv"
   grep -F -- "$session_id" "$evidence_dir/resumed-pane.tsv"
   tmux capture-pane -p -S - -t "orchestrator:issue-${issue}" \
     >"$evidence_dir/pane-after-resume.txt"
   grep -F -- "$session_id" "$evidence_dir/resumed-pane.tsv" \
     | tee "$evidence_dir/resume-session-evidence.txt"
   gh issue view "$issue" --json labels | tee "$evidence_dir/primary-resumed.json"
   gh issue view "$second_issue" --json labels | tee "$evidence_dir/second-started.json"
   ```

   The timestamped supervisor lines must put `Resumed worker` before `Started
   worker`; label snapshots must show the second issue was ready while closed and
   was not claimed/started until after the primary resume. Exactly one window
   for each issue may exist. The recorded launch is
   `ccode --print --permission-mode auto --model claude-opus-4-8 --resume
   "$session_id" <recovery-prompt>`.

6. Observe the resumed conversation. Capture evidence that the injected recovery
   prompt identifies the interrupted tool and says its outcome is unknown; the
   worker must inspect git status, the draft PR, and relevant external state
   before continuing. Only after reconciliation may it retry or otherwise
   continue, at which point the harmless marker may appear. Confirm the same
   draft PR/worktree continues, only one worker window exists, and the selected
   pause generation is removed.

7. While the foreground supervisor still runs, stop only the two test windows
   and let the next poll reconcile them as vanished. Use the pre-recorded
   registry procedure to verify both owners become absent and capture the
   supervisor's timestamped `vanished` lines. Then press Ctrl-C in the supervisor
   terminal and wait for the `tee` pipeline to return; do not leave
   `issue-orchestrator` running. Clean up both disposable issues and their
   PRs/branches/worktrees. Because step 1 required no pre-existing fixed-name
   session, remove precisely the test session and files:

   ```bash
   tmux kill-window -t "orchestrator:issue-${issue}" 2>/dev/null || true
   tmux kill-window -t "orchestrator:issue-${second_issue}" 2>/dev/null || true
   # Wait for and record the next supervisor poll and both registry absences,
   # then stop the foreground supervisor before continuing.
   gh issue edit "$issue" --remove-label agent-running --remove-label agent-ready
   gh issue edit "$second_issue" --remove-label agent-running --remove-label agent-ready
   gh issue close "$issue" --comment 'Saved-session smoke cleanup.'
   gh issue close "$second_issue" --comment 'Saved-session smoke cleanup.'
   tmux kill-session -t orchestrator 2>/dev/null || true
   rm -f -- "$go_file" "$marker"
   test ! -e "$go_file" && test ! -e "$marker"
   ! tmux has-session -t orchestrator 2>/dev/null
   ```

   Return Sentinel to its prior state and use the pre-recorded registry procedure
   to verify that neither smoke owner is registered. Preserve `$evidence_dir`
   until its contents are copied into the record; then remove it. Preserve failed
   or partial evidence as `FAIL`, and redact tokens.

## Record template

````markdown
# Manual saved-session smoke check

- Date (UTC):
- Issue Orchestrator revision:
- Usage Sentinel revision/image:
- Environment (host, Docker/devcontainer, tmux, network, `ccode` auth mode):
- Test repository, both issues, draft PR(s), worktree(s):
- Sentinel admission-control procedure:
- Sentinel owner-registry observation procedure:
- Result: PASS | FAIL

## Commands and responses

### Step 1

```text
Command:
Response:
```

Repeat for every step above, including timestamps, telemetry before/after,
Sentinel owner state, tmux window/pane state, complete pause-record fields,
exact resumed session ID, recovery/reconciliation observations, marker state,
claim/PR/worktree continuity, the second issue's closed-gate ready state,
timestamped resume-before-new-claim ordering, and cleanup of both issues.
````
