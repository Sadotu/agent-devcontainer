# issue-orchestrator

A small, supervised issue queue. A single Node supervisor picks up open issues
labeled `agent-ready` (ascending) and keeps at most **three** autonomous
subscription-authenticated `ccode` workers alive — each in its own tmux window
running:

```bash
ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

Workers are gated by [Usage Sentinel](https://github.com/Sadotu/usage-sentinel).
The full model name pins issue workers to Opus 4.8 instead of the Claude Code
default or the moving `opus` alias.

## Orchestrator

Zero-dependency Node ≥20.8.0 on Linux (the supervisor guard uses a Linux abstract
Unix socket). No build step.

### Installed/current-repository usage

The npm package installs the `issue-orchestrator` binary. Run it from the
target project repository, not from the package checkout:

```bash
cd /path/to/target-project
issue-orchestrator
```

The shared [`agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
also exposes that command through the literal alias:

```bash
start work
```

The supervisor resolves the `origin` of that current working directory,
checks GitHub App authentication, checks Sentinel before admitting/starting
workers, and starts autonomous workers itself:

```bash
ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

Non-interactive print mode skips the workspace-trust prompt, and each process
exits after its command finishes. Sentinel failures fail closed. Do not start
Claude separately.

Only one supervisor per repository per Linux network namespace may run at a
time. A second invocation in the same namespace for the same resolved
`owner/repo` exits nonzero with an `already running` error before
authentication, Sentinel, tmux, or worker startup. Ownership is held by a
kernel-owned Linux abstract Unix socket, so it is released on normal exit and
automatically when the supervisor process dies. Devcontainers normally have
distinct network namespaces and therefore independent guards; containers that
share a network namespace also share this guard.

Neither the image build nor devcontainer startup launches the supervisor or
an LLM. Work begins only when a user explicitly runs `issue-orchestrator` or
its `start work` alias.

### Repository-checkout usage

```bash
npm test                 # node --test over test/
node bin/supervisor.mjs  # start the supervisor loop
tmux attach -t orchestrator   # watch the workers directly
```

### How it works

- **Claim** — the lowest-numbered `agent-ready` issue has its label swapped
  `agent-ready` → `agent-running`, then a tmux window `issue-<n>` opens running
  this autonomous command:

  ```bash
  ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue <n>"
  ```

  Non-interactive print mode skips the workspace-trust prompt; the process exits
  and its tmux window closes after the command finishes.
- **Complete** — when a worker's PR flips from draft to ready-for-review, the
  supervisor closes its tmux window, unregisters its stable Sentinel owner,
  then removes `agent-running`. An already-closed window is treated as closed;
  a failure at any later step is logged and retried by the next poll.
- **Vanished** — if a worker window disappears while its PR is still draft,
  its Sentinel owner is unregistered before `agent-running` is removed. The
  issue number and draft PR URL are surfaced, and the issue is **not** restarted
  automatically because its draft PR or worktree may still exist.
- **New-worker admission and capacity** — before registration, the supervisor
  reads Sentinel's `GET /usage/claude-code` telemetry and admits only when
  short-window usage is below 80% and weekly usage is below 95%. Sentinel's
  `POST /workers`
  remains authoritative for registration and the combined global limit of
  three workers across every connected repository. The supervisor also keeps a
  cheap local maximum-three guard. A
  stable owner (`<repository>#<issue-number>`) is registered before claim and
  tmux creation; claim failure unregisters it, while tmux failure unregisters
  it and restores the labels. Every live worker is heartbeated each poll, and
  `registered` is accepted as well as `refreshed` so Sentinel can rebuild its
  registry after a restart. A failed heartbeat prevents new starts for that
  poll.
- **Pause and resume** — existing workers check the same gate before every tool.
  A denial saves the Claude session and closes its window before the tool runs;
  saved sessions resume before new issues when admission reopens. Recovery
  treats the interrupted tool's outcome as unknown and reconciles state first.
- **Stop** — the supervisor exits when no claimable, live, or paused work remains.

Live pause/resume test: [docs/smoke-checks/README.md](docs/smoke-checks/README.md).

### GitHub authentication

`gh` does not auto-consume the GitHub App credential, so the supervisor mints a
short-lived App installation token (via `gh-app-token.sh`, overridable with
`GH_APP_TOKEN_SCRIPT`) and injects it as `GH_TOKEN` for every `gh` call,
re-minting each poll. At startup it runs an authenticated `gh repo view` smoke
check and exits with a clear message if the App is not authenticated — rather
than churning on unauthenticated calls every poll.

### Configuration

The local concurrency guard is fixed at 3. Two knobs are environment-tunable:

| Var | Default | Meaning |
|-----|---------|---------|
| `SENTINEL_URL` | `http://usage-sentinel:4317` | Usage Sentinel base URL on the shared container network; set this explicitly (for example, `http://host.docker.internal:4317`) only when Sentinel is exposed on the host |
| `POLL_MS` | `60000` | Poll interval |

Labels: `agent-ready` (claimable) and `agent-running` (claimed/live). The
repository already defines these; the supervisor only swaps between them.

## Repo contents

| Path | Purpose |
|------|---------|
| `agents.toml` / `agents.lock` | [dotagents](https://github.com/Sadotu/agent-skills) manifest — declares which skills are installed and pins their source commits |
| `.agents/skills/` | Installed skills (`github-issue`, `setup`) — managed artifacts, restored from the manifest, not committed |
| `.claude/skills` | Symlink to `.agents/skills` so Claude Code picks the skills up |
| `CLAUDE.md` | Agent instructions and gotchas for working in this repo |

## Skills

- **`github-issue`** — runs a GitHub issue end to end: select issue, open a
  draft PR immediately, self-resolve design decisions (logged to the PR),
  implement in an isolated worktree, verify against the issue, mark ready.
- **`setup`** — connects the repo to the `container-coding-agent` GitHub App
  and verifies `git`/`gh` authenticate as the App.

Both are sourced from [`Sadotu/agent-skills`](https://github.com/Sadotu/agent-skills).

## Development environment

Agents work on this repo from a shared, sandboxed devcontainer. That
environment is **not part of this app** — it lives in its own repo:
[`Sadotu/agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
(image, setup scripts, security model, auth docs). A local `.devcontainer/`
folder pointing at that image may exist in a checkout but is gitignored.

GitHub access is via the scoped `container-coding-agent` GitHub App — never a
personal token, never `gh auth login`. See `CLAUDE.md` for the auth wiring.
