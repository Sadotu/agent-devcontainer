import { mkdir, open, readdir, readFile, rename, rm, unlink } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { join } from 'node:path';

const stringFields = ['sessionId', 'toolUseId', 'toolName', 'cwd', 'reason', 'tmuxPane'];
const pauseRecordFieldNames = ['issue', ...stringFields, 'pausedAt'];
const pauseRecordFields = new Set(pauseRecordFieldNames);
const isoTimestamp = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-](\d{2}):(\d{2}))$/;

function isValidIsoTimestamp(value) {
  if (typeof value !== 'string') return false;
  const match = isoTimestamp.exec(value);
  if (!match) return false;

  const [, ...parts] = match;
  const [year, month, day, hour, minute, second] = parts.slice(0, 6).map(Number);
  const offsetHour = parts[6] === undefined ? undefined : Number(parts[6]);
  const offsetMinute = parts[7] === undefined ? undefined : Number(parts[7]);
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return month >= 1
    && month <= 12
    && day >= 1
    && day <= daysInMonth
    && hour <= 23
    && minute <= 59
    && second <= 59
    && (offsetHour === undefined || offsetHour <= 23)
    && (offsetMinute === undefined || offsetMinute <= 59)
    && !Number.isNaN(Date.parse(value));
}

function validateIssue(issue) {
  if (!Number.isInteger(issue) || issue <= 0) {
    throw new TypeError('issue must be a positive integer');
  }
}

async function acquireIssueLock(directory, issue, {
  mkdirImpl = mkdir,
  rmImpl = rm,
  retry = false,
  sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)),
} = {}) {
  const lock = join(directory, `${issue}.lock`);
  for (let attempt = 0; ; attempt += 1) {
    try {
      await mkdirImpl(lock, { mode: 0o700 });
      return async () => rmImpl(lock, { recursive: true, force: false });
    } catch (error) {
      if (error.code !== 'EEXIST' || !retry || attempt >= 99) {
        if (error.code === 'EEXIST') throw new Error(`pause issue ${issue} lock is held or stale`);
        throw error;
      }
      await sleep(10);
    }
  }
}

export function validatePauseRecord(record) {
  if (record === null || typeof record !== 'object' || Array.isArray(record)) {
    throw new TypeError('pause record must be an object');
  }

  const ownFields = Object.keys(record);
  const unknownField = ownFields.find((field) => !pauseRecordFields.has(field));
  if (unknownField !== undefined) {
    throw new TypeError(`pause record has unknown field: ${unknownField}`);
  }
  const missingField = pauseRecordFieldNames.find((field) => !ownFields.includes(field));
  if (missingField !== undefined) {
    throw new TypeError(`pause record must have own enumerable field: ${missingField}`);
  }

  validateIssue(record.issue);
  for (const field of stringFields) {
    if (typeof record[field] !== 'string' || record[field].trim() === '') {
      throw new TypeError(`${field} must be a non-empty string`);
    }
  }

  if (
    !isValidIsoTimestamp(record.pausedAt)
  ) {
    throw new TypeError('pausedAt must be a valid ISO timestamp string');
  }

  return record;
}

export async function writePauseRecord(directory, record, fsOps = {}) {
  validatePauseRecord(record);
  const mkdirImpl = fsOps.mkdir ?? mkdir;
  const openImpl = fsOps.open ?? open;
  const renameImpl = fsOps.rename ?? rename;
  const rmImpl = fsOps.rm ?? rm;
  await mkdirImpl(directory, { recursive: true, mode: 0o700 });
  const releaseLock = await acquireIssueLock(directory, record.issue, {
    mkdirImpl, rmImpl, retry: true, sleep: fsOps.sleep,
  });
  let operationError;

  try {
  const destination = join(directory, filenameFor(record));
  const confirmation = `${destination}.confirmed`;
  const temporary = join(directory, `.${record.issue}.${randomUUID()}.tmp`);
  const confirmationTemporary = join(directory, `.${record.issue}.${randomUUID()}.confirmed.tmp`);
  const contents = `${JSON.stringify(record)}\n`;
  const digest = createHash('sha256').update(contents).digest('hex');
  let handle;
  let directoryHandle;
  let recordPublished = false;
  let confirmationPublished = false;

  try {
    handle = await openImpl(temporary, 'wx', 0o600);
    await handle.writeFile(contents, 'utf8');
    await handle.sync();
    await handle.close();
    handle = undefined;
    await renameImpl(temporary, destination);
    recordPublished = true;
    directoryHandle = await openImpl(directory, 'r');
    await directoryHandle.sync();
    await directoryHandle.close();
    directoryHandle = undefined;
    handle = await openImpl(confirmationTemporary, 'wx', 0o600);
    await handle.writeFile(`${JSON.stringify({ filename: filenameFor(record), digest })}\n`, 'utf8');
    await handle.sync();
    await handle.close();
    handle = undefined;
    await renameImpl(confirmationTemporary, confirmation);
    confirmationPublished = true;
    directoryHandle = await openImpl(directory, 'r');
    await directoryHandle.sync();
    await directoryHandle.close();
    directoryHandle = undefined;
  } catch (error) {
    await handle?.close().catch(() => {});
    await directoryHandle?.close().catch(() => {});
    const cleanupErrors = [];
    const cleanup = async (path) => rmImpl(path, { force: true }).catch((cleanupError) => cleanupErrors.push(cleanupError.message));
    if (confirmationPublished) await cleanup(confirmation);
    if (recordPublished) await cleanup(destination);
    await rmImpl(temporary, { force: true }).catch(() => {});
    await rmImpl(confirmationTemporary, { force: true }).catch(() => {});
    if (cleanupErrors.length > 0) {
      error.message += `; pause cleanup failed: ${cleanupErrors.join('; ')}`;
    }
    throw error;
  }
  } catch (error) {
    operationError = error;
    throw error;
  } finally {
    try {
      await releaseLock();
    } catch (lockError) {
      if (operationError) operationError.message += `; lock release failed: ${lockError.message}`;
      else throw lockError;
    }
  }
}

export function pauseRecordFilename(record) {
  validatePauseRecord(record);
  return filenameFor(record);
}

function filenameFor(record) {
  const generation = createHash('sha256')
    .update(`${record.sessionId}\0${record.toolUseId}\0${record.pausedAt}`)
    .digest('hex');
  return `${record.issue}-${generation}.json`;
}

export async function listPauseRecords(directory) {
  let entries;
  try {
    entries = await readdir(directory);
  } catch (error) {
    if (error.code === 'ENOENT') return { records: [], errors: [] };
    throw error;
  }

  const issues = [...new Set(entries.map((entry) => {
    const match = entry.match(/^(\d+)(?:-|\.json$|\.lock$)/);
    return match ? Number(match[1]) : undefined;
  }).filter((issue) => issue !== undefined))].sort((a, b) => a - b);
  const generationsByIssue = new Map();
  const errors = [];
  for (const issue of issues) {
    let releaseLock;
    try {
      try {
        releaseLock = await acquireIssueLock(directory, issue);
      } catch (error) {
        errors.push({ file: `${issue}.lock`, error: error.message });
        continue;
      }
      const currentEntries = await readdir(directory);
      const entrySet = new Set(currentEntries);
      const files = currentEntries.filter((entry) => entry.endsWith('.json') && (entry === `${issue}.json` || entry.startsWith(`${issue}-`))).sort();
      for (const file of files) {
        const confirmationFile = `${file}.confirmed`;
        if (!entrySet.has(confirmationFile)) continue;
        try {
          const contents = await readFile(join(directory, file), 'utf8');
          let marker;
          try {
            marker = JSON.parse(await readFile(join(directory, confirmationFile), 'utf8'));
          } catch (error) {
            throw new TypeError(`invalid confirmation marker: ${error.message}`);
          }
          if (marker?.filename !== file) throw new TypeError('confirmation marker filename mismatch');
          if (marker?.digest !== createHash('sha256').update(contents).digest('hex')) {
            throw new TypeError('confirmation marker digest mismatch');
          }
          const record = JSON.parse(contents);
          validatePauseRecord(record);
          if (filenameFor(record) !== file) {
            throw new TypeError(`filename issue does not match record issue ${record.issue}`);
          }
          const generations = generationsByIssue.get(record.issue) ?? [];
          generations.push({ file, record });
          generationsByIssue.set(record.issue, generations);
        } catch (error) {
          errors.push({ file, error: error.message });
        }
      }
    } catch (error) {
      errors.push({ file: `${issue}.lock`, error: error.message });
    } finally {
      await releaseLock?.().catch((error) => errors.push({ file: `${issue}.lock`, error: `lock release failed: ${error.message}` }));
    }
  }

  const records = [];
  for (const generations of generationsByIssue.values()) {
    if (generations.length === 1) records.push(generations[0].record);
    else for (const { file } of generations) {
      errors.push({ file, error: 'ambiguous: multiple valid generations for issue' });
    }
  }
  records.sort((left, right) => left.issue - right.issue);
  errors.sort((left, right) => left.file.localeCompare(right.file));
  return { records, errors };
}

export async function removePauseRecord(directory, expected) {
  if (typeof expected === 'object') {
    validatePauseRecord(expected);
    const releaseLock = await acquireIssueLock(directory, expected.issue);
    try {
    const path = join(directory, filenameFor(expected));
    await Promise.all([path, `${path}.confirmed`].map((target) => unlink(target).catch((error) => {
      if (error.code !== 'ENOENT') throw error;
    })));
    } finally {
      await releaseLock();
    }
    return;
  }
  validateIssue(expected);
  let entries;
  try { entries = await readdir(directory); } catch (error) {
    if (error.code === 'ENOENT') return;
    throw error;
  }
  const releaseLock = await acquireIssueLock(directory, expected);
  try {
    entries = await readdir(directory);
    await Promise.all(entries.filter((file) => file === `${expected}.json` || file.startsWith(`${expected}-`))
      .map((file) => unlink(join(directory, file))));
  } finally {
    await releaseLock();
  }
}
