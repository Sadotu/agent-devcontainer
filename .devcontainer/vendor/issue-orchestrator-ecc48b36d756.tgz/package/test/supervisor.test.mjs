import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import { chmod, mkdtemp, mkdir, open, rm, symlink, writeFile } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { listPauseRecords, pauseRecordFilename, removePauseRecord, writePauseRecord } from "../src/pauseStore.mjs";
import {
  acquireSupervisorOwnership,
  createGitHub,
  createTmux,
  formatLogLine,
  isAgentSetupReady,
  prForIssue,
  runOnce,
  main,
  workerOwner,
} from "../bin/supervisor.mjs";
import { createSentinelClient } from "../src/usageGate.mjs";

test("isAgentSetupReady checks the devcontainer setup marker", async () => {
  const paths = [];
  const ready = await isAgentSetupReady({ accessImpl: async (path) => paths.push(path) });
  assert.equal(ready, true);
  assert.deepEqual(paths, ["/run/agent-devcontainer/agent-setup-complete"]);
});

test("isAgentSetupReady returns false when the setup marker is inaccessible", async () => {
  const ready = await isAgentSetupReady({ accessImpl: async () => { throw new Error("missing"); } });
  assert.equal(ready, false);
});

// ---------------------------------------------------------------------------
// log line formatting
// ---------------------------------------------------------------------------
test("formatLogLine prefixes an ISO timestamp inside the orchestrator tag", () => {
  const now = new Date("2026-07-21T12:34:56.000Z");
  assert.equal(
    formatLogLine("Started worker for #82", now),
    "[orchestrator 2026-07-21T12:34:56.000Z] Started worker for #82",
  );
});

// ---------------------------------------------------------------------------
// supervisor ownership
// ---------------------------------------------------------------------------
test("installed symlink runs the supervisor for the repository in process cwd", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "orchestrator-installed-"));
  let child;
  t.after(async () => {
    if (child?.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    await rm(root, { recursive: true, force: true });
  });
  const repo = join(root, "target");
  const tools = join(root, "tools");
  await mkdir(repo);
  await mkdir(tools);
  const launcher = join(root, "issue-orchestrator");
  await symlink(new URL("../bin/supervisor.mjs", import.meta.url), launcher);
  const helper = join(tools, "token-helper");
  await writeFile(helper, "#!/bin/sh\nprintf token\n");
  await chmod(helper, 0o755);
  for (const name of ["gh", "tmux"]) {
    const file = join(tools, name);
    await writeFile(file, "#!/bin/sh\nexit 0\n");
    await chmod(file, 0o755);
  }
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["init", "-q"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git init exited ${code}`)));
  });
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["remote", "add", "origin", "git@github.com:target-owner/target-repo.git"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git remote exited ${code}`)));
  });

  child = spawn(launcher, [], {
    cwd: repo,
    env: { ...process.env, PATH: `${tools}:${process.env.PATH}`, GH_APP_TOKEN_SCRIPT: helper },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let stdout = ""; let stderr = "";
  child.stdout.on("data", (chunk) => { stdout += chunk; });
  child.stderr.on("data", (chunk) => { stderr += chunk; });
  const timeout = setTimeout(() => child.kill("SIGKILL"), 3000);
  timeout.unref();
  t.after(() => clearTimeout(timeout));
  const [code] = await once(child, "exit");
  assert.equal(code, 0, stderr);
  assert.match(stdout, /Authenticated as GitHub App for target-owner\/target-repo/);
  assert.match(stdout, /Queue empty and no live workers/);
});

test("main rejects duplicate ownership before auth, Sentinel, or tmux setup", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => { events.push("resolve"); return "o/r"; },
    acquireOwnership: async () => { events.push("acquire"); throw new Error("supervisor already running for o/r"); },
    mintToken: async () => { events.push("auth"); },
    createSentinel: () => events.push("sentinel"),
    createTmux: () => events.push("tmux"),
  }), /already running/);
  assert.deepEqual(events, ["resolve", "acquire"]);
});

test("main releases ownership after normal completion", async () => {
  const events = [];
  await main({
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "" }),
    createSentinel: () => ({}),
    createTmux: () => ({}),
    runPoll: async () => ({ done: true }),
    log: () => {},
  });
  assert.deepEqual(events, ["release"]);
});

test("main resolves the pause store under the Git common directory and wires it into tmux and each poll", async () => {
  const events = [];
  const checkSetupReady = async () => false;
  const pauseStore = { listPauseRecords: async () => ({ records: [], errors: [] }), removePauseRecord: async () => {} };
  await main({
    exec: async (file, args) => {
      assert.deepEqual([file, args], ["git", ["rev-parse", "--git-common-dir"]]);
      return { stdout: "../shared.git\n", stderr: "" };
    },
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => {},
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "" }),
    createSentinel: () => ({}),
    createTmux: ({ pauseDirectory }) => { events.push(["tmux", pauseDirectory]); return {}; },
    createPauseStore: (pauseDirectory) => { events.push(["store", pauseDirectory]); return pauseStore; },
    checkSetupReady,
    runPoll: async (options) => { events.push(["poll", options.pauseStore, options.checkSetupReady]); return { done: true }; },
    cwd: "/repo/worktree",
    log: () => {},
  });
  assert.deepEqual(events, [
    ["tmux", "/repo/shared.git/issue-orchestrator/paused"],
    ["store", "/repo/shared.git/issue-orchestrator/paused"],
    ["poll", pauseStore, checkSetupReady],
  ]);
});

test("main preserves an absolute Git common directory when wiring pause storage", async () => {
  const directories = [];
  await main({
    exec: async () => ({ stdout: "/srv/repositories/project.git\n", stderr: "" }),
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => {},
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "" }),
    createSentinel: () => ({}),
    createTmux: ({ pauseDirectory }) => { directories.push(pauseDirectory); return {}; },
    createPauseStore: (pauseDirectory) => { directories.push(pauseDirectory); return {}; },
    runPoll: async () => ({ done: true }),
    cwd: "/repo/worktree",
    log: () => {},
  });
  assert.deepEqual(directories, [
    "/srv/repositories/project.git/issue-orchestrator/paused",
    "/srv/repositories/project.git/issue-orchestrator/paused",
  ]);
});

test("main releases ownership when startup authentication fails", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => { throw new Error("token unavailable"); },
    createTmux: () => ({}),
  }), /GitHub App auth check failed: token unavailable/);
  assert.deepEqual(events, ["release"]);
});

test("supervisor ownership rejects a simultaneous owner and release permits reacquisition", async () => {
  const repo = `test/${randomUUID()}`;
  let listenedAddress;
  const first = await acquireSupervisorOwnership(repo, {
    createServer: () => {
      const server = createNetServer();
      const listen = server.listen.bind(server);
      server.listen = (address, callback) => {
        listenedAddress = address;
        return listen(address, callback);
      };
      return server;
    },
  });
  assert.equal(listenedAddress.startsWith("\0issue-orchestrator-"), true);
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  await first();
  await first();
  const second = await acquireSupervisorOwnership(repo);
  await second();
});

test("simultaneous supervisor acquisitions produce exactly one owner", async () => {
  const repo = `test/${randomUUID()}`;
  const results = await Promise.allSettled([
    acquireSupervisorOwnership(repo),
    acquireSupervisorOwnership(repo),
  ]);
  const winners = results.filter((result) => result.status === "fulfilled");
  assert.equal(winners.length, 1);
  assert.match(results.find((result) => result.status === "rejected").reason.message, /already running/);
  await winners[0].value();
});

test("supervisor ownership is released when its process dies", async () => {
  const repo = `test/${randomUUID()}`;
  const script = `
    import { acquireSupervisorOwnership } from "./bin/supervisor.mjs";
    await acquireSupervisorOwnership(${JSON.stringify(repo)});
    process.stdout.write("READY\\n");
    setInterval(() => {}, 1000);
  `;
  const child = spawn(process.execPath, ["--input-type=module", "--eval", script], {
    cwd: new URL("..", import.meta.url),
    stdio: ["ignore", "pipe", "inherit"],
  });
  await once(child.stdout, "data");
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  child.kill("SIGKILL");
  await once(child, "exit");

  const release = await acquireSupervisorOwnership(repo);
  await release();
});

// ---------------------------------------------------------------------------
// prForIssue
// ---------------------------------------------------------------------------
test("prForIssue matches head branch prefix, not a numeric superstring", () => {
  const prs = [
    { headRefName: "agent/12-something", isDraft: true, url: "u12" },
    { headRefName: "agent/120-other", isDraft: false, url: "u120" },
  ];
  assert.deepEqual(prForIssue(prs, 12), { isDraft: true, url: "u12" });
  assert.equal(prForIssue(prs, 99), null);
});

test("prForIssue matches a closing reference even when the branch drifted", () => {
  // Real incident: worker branch drifted to `worktree-agent+81-…` (no `agent/N-`
  // prefix) but the finished PR still closes #81 via its `Closes #81` body.
  const prs = [
    {
      headRefName: "worktree-agent+81-h2-test-scope",
      isDraft: false,
      url: "u81",
      closingIssuesReferences: [{ number: 81 }],
    },
  ];
  assert.deepEqual(prForIssue(prs, 81), { isDraft: false, url: "u81" });
});

test("prForIssue closing-reference match compares exact numbers, not superstrings", () => {
  const prs = [
    { headRefName: "feature-x", isDraft: false, url: "u120", closingIssuesReferences: [{ number: 120 }] },
  ];
  assert.equal(prForIssue(prs, 12), null);
  assert.deepEqual(prForIssue(prs, 120), { isDraft: false, url: "u120" });
});

// ---------------------------------------------------------------------------
// GitHub adapter
// ---------------------------------------------------------------------------
function fakeExec(responses) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push([file, ...args]);
    const key = args.join(" ");
    for (const [match, out] of responses) {
      if (key.includes(match)) return { stdout: out };
    }
    return { stdout: "" };
  };
  return { exec, calls };
}

test("github listReadyIssues returns ascending numbers", async () => {
  const { exec } = fakeExec([["--label agent-ready", JSON.stringify([{ number: 9 }, { number: 3 }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listReadyIssues(), [3, 9]);
});

test("github listOpenPrs queries only open PRs", async () => {
  const { exec, calls } = fakeExec([["pr list", JSON.stringify([{ headRefName: "agent/1-x", isDraft: true, url: "u" }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  const prs = await gh.listOpenPrs();
  assert.equal(prs.length, 1);
  const c = calls.find((c) => c.includes("list") && c.includes("pr"));
  assert.ok(c.includes("--state") && c.includes("open"));
  assert.ok(!c.includes("all"));
});

test("github claim swaps ready->running", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.claim(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-ready"));
  assert.ok(c.includes("--add-label") && c.includes("agent-running"));
});

test("github release removes running and adds no other label", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.release(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(!c.includes("--add-label"));
  assert.ok(!c.join(" ").includes("agent-blocked"));
});

test("github restore swaps running back to ready", async () => {
  const { exec, calls } = fakeExec([]);
  await createGitHub({ exec, repo: "o/r" }).restore(5);
  const c = calls.find((call) => call.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(c.includes("--add-label") && c.includes("agent-ready"));
});

// ---------------------------------------------------------------------------
// tmux adapter
// ---------------------------------------------------------------------------
function tmuxRecorder({ listOutput = "", listError = null, killError = null } = {}) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push(args);
    if (args[0] === "list-windows" && listError) throw listError;
    if (args[0] === "list-windows") return { stdout: listOutput };
    if (args[0] === "kill-window" && killError) throw killError;
    return { stdout: "" };
  };
  return { exec, calls };
}

test("tmux listWorkerIssues uses a printable delimiter and parses pane identities", async () => {
  const { exec, calls } = tmuxRecorder({ listOutput: "supervisor|%0\nissue-3|%1\nissue-12|%2\nnotes|%3\n" });
  const tmux = createTmux({ exec, pauseDirectory: "/var/lib/issue-orchestrator/pauses" });
  const set = await tmux.listWorkerIssues();
  assert.deepEqual([...set].sort((a, b) => a - b), [3, 12]);
  assert.deepEqual([...set.panes], [[3, "%1"], [12, "%2"]]);
  assert.equal(calls[0].at(-1), "#{window_name}|#{pane_id}");
});

test("tmux listWorkerIssues propagates list-windows inspection failures", async () => {
  const error = new Error("temporary tmux server failure");
  const { exec } = tmuxRecorder({ listError: error });
  const tmux = createTmux({ exec, pauseDirectory: "/var/lib/issue-orchestrator/pauses" });
  await assert.rejects(() => tmux.listWorkerIssues(), error);
});

test("tmux openWorker creates a self-closing auto-mode issue worker", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec, pauseDirectory: "/var/lib/issue-orchestrator/pauses" });
  await tmux.openWorker(7);
  const c = calls.find((a) => a[0] === "new-window");
  assert.deepEqual(c, [
    "new-window",
    "-t",
    "orchestrator",
    "-n",
    "issue-7",
    "-e",
    "ISSUE_ORCHESTRATOR_ISSUE=7",
    "-e",
    "ISSUE_ORCHESTRATOR_PAUSE_DIR=/var/lib/issue-orchestrator/pauses",
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"'`,
  ]);
});

test("tmux requires a non-empty pause directory", () => {
  const { exec } = tmuxRecorder();
  assert.throws(() => createTmux({ exec }), /pause directory is required/);
  assert.throws(() => createTmux({ exec, pauseDirectory: "   " }), /pause directory is required/);
});

test("tmux resumeWorker restores the recorded session in its cwd with recovery context", async () => {
  const { exec, calls } = tmuxRecorder();
  const record = {
    issue: 52,
    sessionId: "session-abc",
    toolUseId: "tool-use-xyz",
    toolName: "Bash",
    cwd: "/workspace/issue-52",
    reason: "short-window threshold reached",
    pausedAt: "2026-07-25T12:34:56.000Z",
    tmuxPane: "%52",
  };
  const tmux = createTmux({
    exec, session: "workers", pauseDirectory: "/pauses",
    readFile: async () => JSON.stringify({ sessionId: record.sessionId, generation: pauseRecordFilename(record) }),
    unlink: async () => {},
  });
  await tmux.resumeWorker(record);

  const call = calls.find((args) => args[0] === "new-window");
  assert.deepEqual(call.slice(0, 11), [
    "new-window", "-t", "workers", "-n", "issue-52",
    "-c", "/workspace/issue-52",
    "-e", "ISSUE_ORCHESTRATOR_ISSUE=52",
    "-e", "ISSUE_ORCHESTRATOR_PAUSE_DIR=/pauses",
  ]);
  assert.match(call.at(-1), /^bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 --resume /);
  assert.match(call.at(-1), /session-abc/);
  assert.match(call.at(-1), /2026-07-25T12:34:56\.000Z/);
  assert.match(call.at(-1), /short-window threshold reached/);
  assert.match(call.at(-1), /Bash/);
  assert.match(call.at(-1), /tool-use-xyz/);
  assert.match(call.at(-1), /outcome is unknown and must not be assumed/i);
  assert.match(call.at(-1), /git status/i);
  assert.match(call.at(-1), /draft PR/i);
  assert.match(call.at(-1), /relevant external state/i);
});

test("tmux resumeWorker validates records and shell-quotes hostile recorded strings", async () => {
  const { exec, calls } = tmuxRecorder();
  const record = {
    issue: 9,
    sessionId: "session'$(touch /tmp/session-injection)",
    toolUseId: "use'; touch /tmp/use-injection; '",
    toolName: "Bash 'quoted'",
    cwd: "/workspace/it's-safe",
    reason: "quota'; touch /tmp/reason-injection; '",
    pausedAt: "2026-07-25T12:34:56.000Z",
    tmuxPane: "%9",
  };
  const tmux = createTmux({
    exec, pauseDirectory: "/pauses/it's-safe",
    readFile: async () => JSON.stringify({ sessionId: record.sessionId, generation: pauseRecordFilename(record) }),
    unlink: async () => {},
  });
  await tmux.resumeWorker(record);
  const call = calls.find((args) => args[0] === "new-window");
  assert.equal(call[6], record.cwd);
  assert.equal(call[8], "ISSUE_ORCHESTRATOR_ISSUE=9");
  assert.equal(call[10], "ISSUE_ORCHESTRATOR_PAUSE_DIR=/pauses/it's-safe");
  assert.match(call.at(-1), /'"'"'/);
  assert.doesNotMatch(call.at(-1), /(?<!['])\$\(touch/);

  await assert.rejects(() => tmux.resumeWorker({ ...record, issue: 0 }), /issue must be a positive integer/);
  await assert.rejects(() => tmux.resumeWorker({ ...record, extra: "field" }), /unknown field/);
  assert.equal(calls.filter((args) => args[0] === "new-window").length, 1);
});

test("tmux resumeWorker rejects when tmux accepts the window but the child exits without acknowledgement", async () => {
  const record = pauseRecord(7);
  let windowChecks = 0;
  const { exec: baseExec } = tmuxRecorder();
  const exec = async (file, args) => {
    if (args[0] === "has-session" && ++windowChecks > 1) {
      const error = new Error("can't find window");
      error.stderr = "can't find window";
      throw error;
    }
    return baseExec(file, args);
  };
  const missing = Object.assign(new Error("missing"), { code: "ENOENT" });
  const tmux = createTmux({ exec, pauseDirectory: "/pauses", readFile: async () => { throw missing; }, unlink: async () => {}, sleep: async () => {} });
  await assert.rejects(() => tmux.resumeWorker(record), /exited before resume acknowledgement/);
});

test("tmux resumeWorker rejects an acknowledgement for the wrong resumed session", async () => {
  const record = pauseRecord(7);
  const { exec } = tmuxRecorder();
  const tmux = createTmux({
    exec, pauseDirectory: "/pauses",
    readFile: async () => JSON.stringify({ sessionId: "different-session", generation: pauseRecordFilename(record) }),
    unlink: async () => {},
  });
  await assert.rejects(() => tmux.resumeWorker(record), /acknowledgement mismatch/);
});

test("tmux resumeWorker resolves only after the exact resumed session generation acknowledges", async () => {
  const record = pauseRecord(7);
  const events = [];
  const { exec: baseExec, calls } = tmuxRecorder();
  const tmux = createTmux({
    exec: async (file, args) => { events.push(args[0]); return baseExec(file, args); },
    pauseDirectory: "/pauses",
    readFile: async () => {
      events.push("read-ack");
      return JSON.stringify({ sessionId: record.sessionId, generation: pauseRecordFilename(record) });
    },
    unlink: async () => events.push("cleanup-ack"),
  });
  await tmux.resumeWorker(record);
  const call = calls.find((args) => args[0] === "new-window");
  assert.ok(call.includes(`ISSUE_ORCHESTRATOR_RESUME_SESSION=${record.sessionId}`));
  assert.ok(call.includes(`ISSUE_ORCHESTRATOR_RESUME_GENERATION=${pauseRecordFilename(record)}`));
  assert.deepEqual(events, ["cleanup-ack", "new-window", "has-session", "read-ack", "cleanup-ack"]);
});

test("tmux openWorker rejects a non-integer issue number (no shell injection)", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec, pauseDirectory: "/pauses" });
  assert.throws(() => tmux.openWorker('7" && rm -rf /'), /invalid issue number/);
  assert.equal(calls.length, 0);
});

test("tmux closeWorker treats a confirmed missing window as success", async () => {
  const err = new Error("kill-window failed");
  err.stderr = "can't find window: orchestrator:issue-7";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec, pauseDirectory: "/pauses" });
  await tmux.closeWorker(7); // must not throw
});

test("tmux closeWorker propagates a non-absent failure (e.g. server down)", async () => {
  const err = new Error("no server running on /tmp/tmux-1000/default");
  err.stderr = "no server running on /tmp/tmux-1000/default";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec, pauseDirectory: "/pauses" });
  await assert.rejects(() => tmux.closeWorker(7), /no server running/);
});

// ---------------------------------------------------------------------------
// runOnce
// ---------------------------------------------------------------------------
function stubGh(overrides = {}) {
  return {
    listReadyIssues: async () => [],
    listRunningIssues: async () => [],
    listOpenPrs: async () => [],
    claim: async () => {},
    release: async () => {},
    restore: async () => {},
    ...overrides,
  };
}
function stubTmux(overrides = {}) {
  return {
    ensureSession: async () => {},
    listWorkerIssues: async () => new Set(),
    openWorker: async () => {},
    resumeWorker: async () => {},
    closeWorker: async () => {},
    ...overrides,
  };
}
function pauseRecord(issue, overrides = {}) {
  return {
    issue,
    sessionId: `session-${issue}`,
    toolUseId: `tool-use-${issue}`,
    toolName: "Bash",
    cwd: `/worktrees/issue-${issue}`,
    reason: "usage limit",
    pausedAt: "2026-07-24T12:00:00.000Z",
    tmuxPane: `%${issue}`,
    ...overrides,
  };
}
function stubPauseStore(overrides = {}) {
  return {
    listPauseRecords: async () => ({ records: [], errors: [] }),
    removePauseRecord: async () => {},
    ...overrides,
  };
}
const gateOpen = async () => ({ allowed: true, reason: "ok" });
function stubSentinel(overrides = {}) {
  return {
    registerWorker: async () => ({ allowed: true, reason: "registered" }),
    unregisterWorker: async () => ({ allowed: true, reason: "unregistered" }),
    ...overrides,
  };
}

test("runOnce aborts without lifecycle mutations when tmux inspection fails", async () => {
  const events = [];
  const inspectionError = new Error("temporary tmux inspection failure");
  const gh = stubGh({
    listOpenPrs: async () => { events.push("list-prs"); return []; },
    listReadyIssues: async () => { events.push("list-ready"); return [8]; },
    release: async () => events.push("release"),
    claim: async () => events.push("claim"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => { throw inspectionError; },
    openWorker: async () => events.push("open"),
  });
  const sentinel = stubSentinel({
    registerWorker: async () => { events.push("register"); return { allowed: true, reason: "registered" }; },
    unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; },
  });

  await assert.rejects(
    () => runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] }),
    inspectionError,
  );
  assert.deepEqual(events, []);
});

test("runOnce claims ready issues via gh + tmux when gate open", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [4] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({ gh, tmux, checkGate: gateOpen, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [4]);
  assert.equal(res.done, false);
});

test("runOnce never exceeds concurrency, counting ALL live windows (incl. orphans)", async () => {
  const opened = [];
  // One live window (issue 50) has no matching claimed label — still a worker.
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([50]),
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({ gh, tmux, checkGate: gateOpen, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [1, 2]); // 1 orphan + 2 new = 3
  assert.equal(res.liveCount, 3);
});

test("runOnce fetches fresh admission before EVERY start and pauses mid-fill", async () => {
  const opened = [];
  let gateCalls = 0;
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const checkGate = async () => {
    gateCalls += 1;
    return gateCalls <= 2 ? { allowed: true, reason: "ok" } : { allowed: false, reason: "admission denied" };
  };
  const res = await runOnce({ gh, tmux, checkGate, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [1, 2]); // third blocked by fresh gate
  assert.equal(gateCalls, 3); // one fresh check per start attempt
  assert.equal(res.paused, true);
  assert.equal(res.done, false); // ready remains → keep polling
});

test("runOnce heartbeats live workers but attempts no new registration when full", async () => {
  const owners = [];
  const gh = stubGh({ listReadyIssues: async () => [1] });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([10, 11, 12]) }); // full
  const sentinel = stubSentinel({ registerWorker: async (owner) => { owners.push(owner); return { allowed: true, reason: "refreshed" }; } });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(owners, ["o/r#10", "o/r#11", "o/r#12"]);
  assert.equal(res.started, 0);
});

test("runOnce completion closes, unregisters, then releases and frees the slot", async () => {
  const order = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async (n) => order.push(`release-${n}`),
    listReadyIssues: async () => [8],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async (n) => order.push(`close-${n}`),
    openWorker: async (n) => order.push(`open-${n}`),
  });
  const sentinel = stubSentinel({ unregisterWorker: async (owner) => { order.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; } });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(order, ["close-7", "unregister-o/r#7", "release-7", "open-8"]);
  assert.equal(res.liveCount, 1); // 7 freed, 8 started
});

test("runOnce completion with an already-gone window does not close or double-count", async () => {
  const order = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => order.push("release"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set(), // window already gone
    closeWorker: async () => order.push("close"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { order.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(order, ["unregister", "release"]);
  assert.equal(res.liveCount, 0);
});

test("runOnce surfaces a vanished worker, releases it, and does not restart", async () => {
  const surfaced = [];
  const opened = [];
  const released = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/2-x", isDraft: true, url: "u2" }],
    release: async (n) => released.push(n),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set(), // no live window
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({
    gh, tmux, checkGate: gateOpen, concurrency: 3,
    log: (m) => surfaced.push(m), claimedIssues: [2],
  });
  assert.deepEqual(released, [2]);
  assert.deepEqual(opened, []);
  assert.ok(surfaced.some((m) => /2/.test(m) && /u2/.test(m)));
  assert.equal(res.liveCount, 0);
});

test("missing claimed worker with a pause record retains claim, unregisters owner, and does not consume live capacity", async () => {
  const events = [];
  const record = pauseRecord(7);
  const gh = stubGh({ release: async () => events.push("release") });
  const sentinel = stubSentinel({ unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; } });
  const tmux = stubTmux({ resumeWorker: async (actual) => events.push(`resume-${actual.issue}`) });
  const pauseStore = stubPauseStore({ listPauseRecords: async () => ({ records: [record], errors: [] }) });

  const result = await runOnce({ gh, tmux, sentinel, pauseStore, repo: "o/r", concurrency: 0, log: () => {}, claimedIssues: [7] });

  assert.deepEqual(events, ["unregister-o/r#7"]);
  assert.equal(result.liveCount, 0);
  assert.equal(result.done, false);
});

test("live worker is authoritative and removes its stale pause record without resuming", async () => {
  const events = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [pauseRecord(7)], errors: [] }),
    removePauseRecord: async (issue) => events.push(`remove-${issue}`),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    resumeWorker: async () => events.push("resume"),
  });

  await runOnce({ gh: stubGh(), tmux, sentinel: stubSentinel(), pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });

  assert.deepEqual(events, ["remove-7"]);
});

test("pause written for the live pane closes it, unregisters its owner, and retains the claim and record as resume-eligible", async () => {
  const record = pauseRecord(7, { tmuxPane: "%77" });
  const live = new Set([7]);
  live.panes = new Map([[7, "%77"]]);
  const events = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [record], errors: [] }),
    removePauseRecord: async () => events.push("remove"),
  });
  const sentinel = stubSentinel({
    unregisterWorker: async () => { events.push('unregister'); return { allowed: true, reason: 'unregistered' }; },
    registerWorker: async () => { events.push('register'); return { allowed: true, reason: 'registered' }; },
  });
  await runOnce({
    gh: stubGh({ release: async () => events.push('release') }),
    tmux: stubTmux({ listWorkerIssues: async () => live, closeWorker: async () => events.push('close'), resumeWorker: async () => events.push("resume") }),
    sentinel, pauseStore, repo: "o/r", concurrency: 0, log: () => {}, claimedIssues: [7],
  });
  assert.deepEqual(events, ['close', 'unregister']);
});

test("same-pane pause close failure retains state, skips heartbeat and resume, and retries next poll", async () => {
  const record = pauseRecord(7, { tmuxPane: '%77' });
  const live = new Set([7]);
  live.panes = new Map([[7, '%77']]);
  const events = [];
  let attempts = 0;
  const tmux = stubTmux({
    listWorkerIssues: async () => live,
    closeWorker: async () => { events.push('close'); attempts += 1; if (attempts === 1) throw new Error('kill failed'); },
    resumeWorker: async () => events.push('resume'),
  });
  const sentinel = stubSentinel({
    unregisterWorker: async () => { events.push('unregister'); return { allowed: true, reason: 'unregistered' }; },
    registerWorker: async () => { events.push('register'); return { allowed: true, reason: 'registered' }; },
  });
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [record], errors: [] }),
    removePauseRecord: async () => events.push('remove'),
  });
  const options = { gh: stubGh({ release: async () => events.push('release') }), tmux, sentinel, pauseStore, repo: 'o/r', concurrency: 0, log: () => {}, claimedIssues: [7] };

  await runOnce(options);
  assert.deepEqual(events, ['close']);
  await runOnce(options);
  assert.deepEqual(events, ['close', 'close', 'unregister']);
});

test("directory-sync pause failure cannot trigger same-pane close or unregister", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'failed-pause-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const record = pauseRecord(7, { tmuxPane: '%77' });
  await assert.rejects(writePauseRecord(directory, record, {
    open: async (path, ...args) => {
      const handle = await open(path, ...args);
      if (path === directory) handle.sync = async () => { throw new Error('directory sync failed'); };
      return handle;
    },
  }), /directory sync failed/);
  const live = new Set([7]);
  live.panes = new Map([[7, '%77']]);
  const events = [];
  await runOnce({
    gh: stubGh(),
    tmux: stubTmux({ listWorkerIssues: async () => live, closeWorker: async () => events.push('close') }),
    sentinel: stubSentinel({
      unregisterWorker: async () => { events.push('unregister'); return { allowed: true, reason: 'unregistered' }; },
      registerWorker: async () => ({ allowed: true, reason: 'refreshed' }),
    }),
    pauseStore: {
      listPauseRecords: () => listPauseRecords(directory),
      removePauseRecord: (issue, expected) => removePauseRecord(directory, expected ?? issue),
    },
    repo: 'o/r', concurrency: 1, log: () => {}, claimedIssues: [7],
  });
  assert.deepEqual(events, []);
});

test("supervisor ignores a same-pane record while writer is paused before its durability barrier", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'publishing-pause-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const record = pauseRecord(7, { tmuxPane: '%77' });
  let reachedBarrier;
  const barrierReached = new Promise((resolve) => { reachedBarrier = resolve; });
  let releaseBarrier;
  const barrierRelease = new Promise((resolve) => { releaseBarrier = resolve; });
  let directorySyncs = 0;
  const writing = writePauseRecord(directory, record, {
    open: async (path, ...args) => {
      const handle = await open(path, ...args);
      if (path === directory) {
        const sync = handle.sync.bind(handle);
        handle.sync = async () => {
          directorySyncs += 1;
          if (directorySyncs === 1) { reachedBarrier(); await barrierRelease; }
          await sync();
        };
      }
      return handle;
    },
  });
  await barrierReached;
  const live = new Set([7]);
  live.panes = new Map([[7, '%77']]);
  const events = [];
  await runOnce({
    gh: stubGh(),
    tmux: stubTmux({ listWorkerIssues: async () => live, closeWorker: async () => events.push('close') }),
    sentinel: stubSentinel({
      unregisterWorker: async () => { events.push('unregister'); return { allowed: true, reason: 'unregistered' }; },
      registerWorker: async () => ({ allowed: true, reason: 'refreshed' }),
    }),
    pauseStore: { listPauseRecords: () => listPauseRecords(directory), removePauseRecord: () => {} },
    repo: 'o/r', concurrency: 1, log: () => {}, claimedIssues: [7],
  });
  assert.deepEqual(events, []);
  releaseBarrier();
  await writing;
});

test("lock-only pause issue retains a missing claim without vanished release", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'locked-pause-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(join(directory, '7.lock'));
  const events = [];
  await runOnce({
    gh: stubGh({ release: async () => events.push('release') }),
    tmux: stubTmux(),
    sentinel: stubSentinel({ unregisterWorker: async () => { events.push('unregister'); return { allowed: true, reason: 'unregistered' }; } }),
    pauseStore: { listPauseRecords: () => listPauseRecords(directory), removePauseRecord: () => {} },
    repo: 'o/r', concurrency: 1, log: () => {}, claimedIssues: [7],
  });
  assert.deepEqual(events, []);
});

test("ready PR completion clears a pause record before unregistering and releasing", async () => {
  const events = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => events.push("release"),
  });
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [pauseRecord(7)], errors: [] }),
    removePauseRecord: async () => events.push("remove"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });

  await runOnce({ gh, tmux: stubTmux(), sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });

  assert.deepEqual(events, ["remove", "unregister", "release"]);
});

test("ready PR completion removes a corrupt pause file and still unregisters and releases", async () => {
  const events = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => events.push("release"),
  });
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [], errors: [{ file: "7.json", error: "invalid JSON" }] }),
    removePauseRecord: async (issue) => events.push(`remove-${issue}`),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });

  const result = await runOnce({ gh, tmux: stubTmux(), sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });

  assert.deepEqual(events, ["remove-7", "unregister", "release"]);
  assert.equal(result.done, true);
});

test("ready PR completion uses issue-wide cleanup when valid and corrupt pause siblings coexist", async () => {
  const events = [];
  const selected = pauseRecord(7);
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [selected], errors: [{ file: `7-${"b".repeat(64)}.json`, error: "invalid JSON" }] }),
    removePauseRecord: async (issue, expected) => events.push(["remove", issue, expected]),
  });
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => events.push("release"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });

  const result = await runOnce({ gh, tmux: stubTmux(), sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });

  assert.deepEqual(events, [["remove", 7, undefined], "unregister", "release"]);
  assert.equal(result.done, true);
});

test("ready PR completion clears ambiguous valid generation siblings issue-wide", async () => {
  const events = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [], errors: ["a", "b"].map((hash) => ({ file: `7-${hash.repeat(64)}.json`, error: "ambiguous: multiple valid generations" })) }),
    removePauseRecord: async (issue, expected) => events.push(["remove", issue, expected]),
  });
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => events.push("release"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const result = await runOnce({ gh, tmux: stubTmux(), sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(events, [["remove", 7, undefined], "unregister", "release"]);
  assert.equal(result.done, true);
});

test("paused resumptions are attempted by issue number before ready admissions and delegate the exact record", async () => {
  const events = [];
  const later = pauseRecord(9);
  const earlier = pauseRecord(3);
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [later, earlier], errors: [] }),
    removePauseRecord: async (issue) => events.push(`remove-${issue}`),
  });
  const sentinel = stubSentinel({
    registerWorker: async (owner) => { events.push(`register-${owner}`); return { allowed: true, reason: "registered" }; },
    unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; },
  });
  const tmux = stubTmux({
    resumeWorker: async (record) => events.push(["resume", record]),
    openWorker: async (issue) => events.push(`open-${issue}`),
  });
  const gh = stubGh({ listReadyIssues: async () => [1] });

  const result = await runOnce({ gh, tmux, sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [3, 9] });

  assert.deepEqual(events, [
    "unregister-o/r#3", "unregister-o/r#9",
    "register-o/r#3", ["resume", earlier], "remove-3",
    "register-o/r#9", ["resume", later], "remove-9",
    "register-o/r#1", "open-1",
  ]);
  assert.equal(result.started, 3);
  assert.equal(result.resumed, 2);
});

test("ambiguous preexisting generations are logged and retained without resume or claim release", async () => {
  const old = pauseRecord(7, { toolUseId: "old" });
  const selected = pauseRecord(7, { toolUseId: "selected" });
  const events = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({
      records: [],
      errors: [old, selected].map((record, index) => ({ file: `7-${String(index).repeat(64)}.json`, error: "ambiguous: multiple valid generations" })),
    }),
    removePauseRecord: async (_issue, expected) => events.push(["remove", expected]),
  });
  const logs = [];
  await runOnce({
    gh: stubGh(), tmux: stubTmux({ resumeWorker: async (record) => events.push(["resume", record]) }),
    sentinel: stubSentinel(), pauseStore, repo: "o/r", concurrency: 1, log: (message) => logs.push(message), claimedIssues: [7],
  });
  assert.deepEqual(events, []);
  assert.equal(logs.filter((message) => /ambiguous/.test(message)).length, 2);
});

test("resume registration must be a new registration; refreshed retains pause and blocks new admissions", async () => {
  const events = [];
  const pauseStore = stubPauseStore({ listPauseRecords: async () => ({ records: [pauseRecord(7)], errors: [] }), removePauseRecord: async () => events.push("remove") });
  const sentinel = stubSentinel({
    unregisterWorker: async () => ({ allowed: true, reason: "unregistered" }),
    registerWorker: async () => ({ allowed: true, reason: "refreshed" }),
  });
  const tmux = stubTmux({ resumeWorker: async () => events.push("resume"), openWorker: async () => events.push("open") });
  const result = await runOnce({ gh: stubGh({ listReadyIssues: async () => [8] }), tmux, sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(events, []);
  assert.equal(result.paused, true);
});

test("paused-owner unregister failure retains the record and blocks resumes and new admissions", async () => {
  const events = [];
  const pauseStore = stubPauseStore({ listPauseRecords: async () => ({ records: [pauseRecord(7)], errors: [] }) });
  const sentinel = stubSentinel({
    unregisterWorker: async () => ({ allowed: false, reason: "sentinel unavailable" }),
    registerWorker: async () => { events.push("register"); return { allowed: true, reason: "registered" }; },
  });
  const tmux = stubTmux({ resumeWorker: async () => events.push("resume"), openWorker: async () => events.push("open") });
  const result = await runOnce({ gh: stubGh({ listReadyIssues: async () => [8] }), tmux, sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(events, []);
  assert.equal(result.paused, true);
});

test("resume startup failure unregisters, retains record, and continues to the next paused worker", async () => {
  const events = [];
  const records = [pauseRecord(2), pauseRecord(4)];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records, errors: [] }),
    removePauseRecord: async (issue) => events.push(`remove-${issue}`),
  });
  const sentinel = stubSentinel({
    unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; },
    registerWorker: async (owner) => { events.push(`register-${owner}`); return { allowed: true, reason: "registered" }; },
  });
  const tmux = stubTmux({ resumeWorker: async (record) => { events.push(`resume-${record.issue}`); if (record.issue === 2) throw new Error("tmux failed"); } });
  await runOnce({ gh: stubGh(), tmux, sentinel, pauseStore, repo: "o/r", concurrency: 1, log: () => {}, claimedIssues: [2, 4] });
  assert.deepEqual(events, [
    "unregister-o/r#2", "unregister-o/r#4",
    "register-o/r#2", "resume-2", "unregister-o/r#2",
    "register-o/r#4", "resume-4", "remove-4",
  ]);
});

test("pause removal failure after successful resume counts the live worker and next poll clears stale state without duplicate resume", async () => {
  const record = pauseRecord(7);
  const resumed = [];
  let removalAttempts = 0;
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [record], errors: [] }),
    removePauseRecord: async () => {
      removalAttempts += 1;
      if (removalAttempts === 1) throw new Error("disk busy");
    },
  });
  const sentinel = stubSentinel({
    unregisterWorker: async () => ({ allowed: true, reason: "unregistered" }),
    registerWorker: async () => ({ allowed: true, reason: resumed.length === 0 ? "registered" : "refreshed" }),
  });

  const first = await runOnce({
    gh: stubGh(), tmux: stubTmux({ resumeWorker: async (actual) => resumed.push(actual) }),
    sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7],
  });
  assert.equal(first.liveCount, 1);
  assert.equal(first.started, 1);
  assert.equal(first.resumed, 1);

  const second = await runOnce({
    gh: stubGh(), tmux: stubTmux({ listWorkerIssues: async () => new Set([7]), resumeWorker: async (actual) => resumed.push(actual) }),
    sentinel, pauseStore, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7],
  });
  assert.equal(second.liveCount, 1);
  assert.equal(second.resumed, 0);
  assert.deepEqual(resumed, [record]);
  assert.equal(removalAttempts, 2);
});

test("a second pause generation written during resume survives first-generation cleanup and resumes next poll", async () => {
  const first = pauseRecord(7, { toolUseId: "generation-1", tmuxPane: "%1" });
  const second = pauseRecord(7, { toolUseId: "generation-2", tmuxPane: "%2", pausedAt: "2026-07-23T11:59:00.000Z" });
  let current = first;
  const resumed = [];
  const removed = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [current], errors: [] }),
    removePauseRecord: async (_issue, expected) => {
      removed.push(expected);
      if (expected === current) current = undefined;
    },
  });
  const tmux = stubTmux({ resumeWorker: async (record) => {
    resumed.push(record);
    if (record === first) current = second;
  } });
  const sentinel = stubSentinel();

  await runOnce({ gh: stubGh(), tmux, sentinel, pauseStore, repo: "o/r", concurrency: 1, log: () => {}, claimedIssues: [7] });
  assert.equal(current, second);
  await runOnce({ gh: stubGh(), tmux, sentinel, pauseStore: {
    ...pauseStore,
    listPauseRecords: async () => ({ records: current ? [current] : [], errors: [] }),
  }, repo: "o/r", concurrency: 1, log: () => {}, claimedIssues: [7] });

  assert.deepEqual(resumed, [first, second]);
  assert.deepEqual(removed, [first, second]);
});

test("an equal-timestamp generation written during resume survives selected cleanup", async () => {
  const first = pauseRecord(7, { toolUseId: "generation-1" });
  const second = pauseRecord(7, { toolUseId: "generation-2" });
  let current = first;
  const removed = [];
  const resumed = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: current ? [current] : [], errors: [] }),
    removePauseRecord: async (_issue, expected) => { removed.push(expected); if (expected === current) current = undefined; },
  });
  const tmux = stubTmux({ resumeWorker: async (record) => { resumed.push(record); if (record === first) current = second; } });

  await runOnce({ gh: stubGh(), tmux, sentinel: stubSentinel(), pauseStore, repo: "o/r", concurrency: 1, log: () => {}, claimedIssues: [7] });
  assert.equal(current, second);
  await runOnce({ gh: stubGh(), tmux, sentinel: stubSentinel(), pauseStore, repo: "o/r", concurrency: 1, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(resumed, [first, second]);
  assert.deepEqual(removed, [first, second]);
});

test("corrupt pause record is logged and keeps its matching missing claim without release or resume", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({ release: async () => events.push("release") });
  const tmux = stubTmux({ resumeWorker: async () => events.push("resume") });
  const corruptFilename = `7-${"a".repeat(64)}.json`;
  const pauseStore = stubPauseStore({ listPauseRecords: async () => ({ records: [], errors: [{ file: corruptFilename, error: "invalid JSON" }] }) });
  const result = await runOnce({ gh, tmux, sentinel: stubSentinel(), pauseStore, repo: "o/r", concurrency: 3, log: (message) => logs.push(message), claimedIssues: [7] });
  assert.deepEqual(events, []);
  assert.match(logs.join("\n"), /7-[a-f0-9]+\.json.*invalid JSON/);
  assert.equal(result.done, false);
});

test("runOnce isolates a failed action — a close failure keeps the slot and does not skip fills", async () => {
  const logs = [];
  const opened = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    listReadyIssues: async () => [8],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async () => { throw new Error("no server running"); },
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({
    gh, tmux, checkGate: gateOpen, concurrency: 3,
    log: (m) => logs.push(m), claimedIssues: [7],
  });
  assert.ok(logs.some((m) => /reconcile error for #7/.test(m)));
  // 7's window still counts (close failed → slot not freed), so only 1 free slot left.
  assert.deepEqual(opened, [8]);
  assert.equal(res.liveCount, 2); // 7 (still up) + 8
});

test("workerOwner is stable and live windows heartbeat before a new registration", async () => {
  assert.equal(workerOwner("o/r", 12), "o/r#12");
  const events = [];
  const sentinel = stubSentinel({
    registerWorker: async (owner) => {
      events.push(`register-${owner}`);
      return { allowed: true, reason: owner.endsWith("#9") ? "refreshed" : "registered" };
    },
  });
  const gh = stubGh({ listReadyIssues: async () => [2] });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([9]), openWorker: async () => events.push("open-2") });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["register-o/r#9", "register-o/r#2", "open-2"]);
});

test("heartbeat denial starts nothing and closes no existing worker", async () => {
  const events = [];
  const sentinel = stubSentinel({ registerWorker: async () => ({ allowed: false, reason: "threshold_reached" }) });
  const gh = stubGh({
    listReadyIssues: async () => [2],
    listOpenPrs: async () => [{ headRefName: "agent/9-x", isDraft: true, url: "u9" }],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([9]),
    closeWorker: async () => events.push("close"),
    openWorker: async () => events.push("open"),
  });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [9] });
  assert.deepEqual(events, []);
  assert.equal(res.paused, true);
});

test("reconciles completion before heartbeating surviving live workers", async () => {
  const events = [];
  const sentinel = stubSentinel({
    unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; },
    registerWorker: async (owner) => { events.push(`heartbeat-${owner}`); return { allowed: false, reason: "threshold_reached" }; },
  });
  const gh = stubGh({
    listReadyIssues: async () => [8],
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async (n) => events.push(`release-${n}`),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([3, 5]),
    closeWorker: async (n) => events.push(`close-${n}`),
    openWorker: async () => events.push("open"),
  });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [3, 5] });
  assert.deepEqual(events, ["close-3", "unregister-o/r#3", "release-3", "heartbeat-o/r#5"]);
});

test("heartbeat failure still attempts every live owner exactly once", async () => {
  const owners = [];
  const events = [];
  const sentinel = stubSentinel({ registerWorker: async (owner) => {
    owners.push(owner);
    return owner.endsWith("#3")
      ? { allowed: false, reason: "telemetry_unavailable" }
      : { allowed: true, reason: "refreshed" };
  } });
  const gh = stubGh({
    listReadyIssues: async () => [8],
    listOpenPrs: async () => [],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([3, 5, 7]),
    closeWorker: async () => events.push("close"),
    openWorker: async () => events.push("open"),
  });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 4, log: () => {}, claimedIssues: [] });
  assert.deepEqual(owners, ["o/r#3", "o/r#5", "o/r#7"]);
  assert.deepEqual(events, []);
  assert.equal(res.paused, true);
});

test("new registration must be registered before claim; claim failure unregisters", async () => {
  const events = [];
  const sentinel = stubSentinel({
    registerWorker: async (owner) => { events.push(`register-${owner}`); return { allowed: true, reason: "registered" }; },
    unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; },
  });
  const gh = stubGh({ listReadyIssues: async () => [2], claim: async () => { events.push("claim-2"); throw new Error("claim failed"); } });
  await runOnce({ gh, tmux: stubTmux(), sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["register-o/r#2", "claim-2", "unregister-o/r#2"]);
});

test("open failure unregisters then restores GitHub labels", async () => {
  const events = [];
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const gh = stubGh({
    listReadyIssues: async () => [2], claim: async () => events.push("claim"), restore: async () => events.push("restore"),
  });
  const tmux = stubTmux({ openWorker: async () => { events.push("open"); throw new Error("tmux failed"); } });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["claim", "open", "unregister", "restore"]);
});

test("open failure logs original plus unregister and restore cleanup failures", async () => {
  const logs = [];
  const sentinel = stubSentinel({ unregisterWorker: async () => ({ allowed: false, reason: "delete failed" }) });
  const gh = stubGh({
    listReadyIssues: async () => [2], claim: async () => {}, restore: async () => { throw new Error("labels failed"); },
  });
  const tmux = stubTmux({ openWorker: async () => { throw new Error("tmux failed"); } });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: (m) => logs.push(m) });
  assert.match(logs.join("\n"), /tmux failed.*unregister: delete failed.*restore: labels failed/);
});

test("completion unregister failure logs and does not release", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async () => events.push("release"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => ({ allowed: false, reason: "delete failed" }) });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([3]), closeWorker: async () => events.push("close") });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: (m) => logs.push(m), claimedIssues: [3] });
  assert.deepEqual(events, ["close"]);
  assert.match(logs.join("\n"), /reconcile error for #3.*unregister failed/);
});

test("completion release failure is logged after close and unregister", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async () => { events.push("release"); throw new Error("label failed"); },
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([3]), closeWorker: async () => events.push("close") });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: (m) => logs.push(m), claimedIssues: [3] });
  assert.deepEqual(events, ["close", "unregister", "release"]);
  assert.match(logs.join("\n"), /reconcile error for #3.*label failed/);
});

test("runOnce rejects missing repository when using Sentinel", async () => {
  await assert.rejects(
    () => runOnce({ gh: stubGh(), tmux: stubTmux(), sentinel: stubSentinel(), log: () => {} }),
    /repository/i,
  );
});

test("two supervisors share Sentinel capacity and refresh existing owners", async (t) => {
  const owners = new Set(["a/r#9"]);
  const responses = [];
  let admissionClosedResolve;
  const admissionClosed = new Promise((resolve) => { admissionClosedResolve = resolve; });
  const server = http.createServer(async (req, res) => {
    let body = ""; for await (const chunk of req) body += chunk;
    const owner = body ? JSON.parse(body).owner : "";
    if (req.method === "GET" && req.url === "/usage/claude-code") {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({
        provider: "claude-code",
        status: "ok",
        windows: {
          short: { usedPercent: 20 },
          long: { usedPercent: 20 },
        },
      }));
    } else if (req.method === "POST" && req.url === "/workers") {
      // This decision and mutation are synchronous after body parsing, matching
      // the Sentinel's atomic registration contract.
      if (owners.has(owner)) { responses.push([owner, 200, "refreshed", owners.size]); res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify({ allowed: true, reason: "refreshed" })); }
      else if (owners.size >= 3) { responses.push([owner, 429, "threshold_reached"]); res.writeHead(429, { "content-type": "application/json" }); res.end(JSON.stringify({ allowed: false, reason: "threshold_reached" })); }
      else { owners.add(owner); if (owners.size === 3) admissionClosedResolve(); res.writeHead(201, { "content-type": "application/json" }); res.end(JSON.stringify({ allowed: true, reason: "registered" })); }
    } else if (req.method === "DELETE") { owners.delete(owner); res.writeHead(204); res.end(); }
    else { res.writeHead(404); res.end(); }
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => server.close());
  const url = `http://127.0.0.1:${server.address().port}`;
  const opened = [];
  const seededSupervisor = runOnce({ gh: stubGh({ listOpenPrs: async () => { await admissionClosed; return []; }, listReadyIssues: async () => [1] }), tmux: stubTmux({ listWorkerIssues: async () => new Set([9]), openWorker: async (n) => opened.push(`a#${n}`) }), sentinel: createSentinelClient({ url }), repo: "a/r", concurrency: 3, log: () => {} });
  const fillingSupervisor = runOnce({ gh: stubGh({ listReadyIssues: async () => [4, 5, 6] }), tmux: stubTmux({ openWorker: async (n) => opened.push(`b#${n}`) }), sentinel: createSentinelClient({ url }), repo: "b/r", concurrency: 3, log: () => {} });
  await Promise.all([seededSupervisor, fillingSupervisor]);
  assert.equal(owners.size, 3);
  assert.ok(opened.length <= 2); // seeded worker + opened workers never exceeds three
  assert.ok(responses.some(([owner, status, reason, size]) => owner === "a/r#9" && status === 200 && reason === "refreshed" && size === 3));
  assert.ok(responses.some(([owner, status, reason]) => owner !== "a/r#9" && status === 429 && reason === "threshold_reached"));
});

test("runOnce pauses new starts when gate closed but keeps polling", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [5] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({
    gh, tmux,
    checkGate: async () => ({ allowed: false, reason: "admission denied" }),
    concurrency: 3, log: () => {},
  });
  assert.deepEqual(opened, []);
  assert.equal(res.paused, true);
  assert.equal(res.done, false);
});

test("runOnce heartbeats live workers but pauses launches until agent setup completes", async () => {
  const events = [];
  const logs = [];
  const sentinel = stubSentinel({
    registerWorker: async (owner) => {
      events.push(`register-${owner}`);
      return { allowed: true, reason: owner.endsWith("#9") ? "refreshed" : "registered" };
    },
  });
  const gh = stubGh({
    listReadyIssues: async () => [2],
    claim: async () => events.push("claim-2"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([9]),
    openWorker: async () => events.push("open-2"),
  });

  const result = await runOnce({
    gh, tmux, sentinel, repo: "o/r", concurrency: 3, claimedIssues: [],
    checkSetupReady: async () => false,
    log: (message) => logs.push(message),
  });

  assert.deepEqual(events, ["register-o/r#9"]);
  assert.deepEqual(result, { done: false, liveCount: 1, started: 0, resumed: 0, paused: true });
  assert.match(logs.join("\n"), /agent setup/i);
});

test("runOnce reconciles paused workers but blocks resumes until agent setup completes", async () => {
  const events = [];
  const pauseStore = stubPauseStore({
    listPauseRecords: async () => ({ records: [pauseRecord(7)], errors: [] }),
  });
  const sentinel = stubSentinel({
    unregisterWorker: async (owner) => {
      events.push(`unregister-${owner}`);
      return { allowed: true, reason: "unregistered" };
    },
    registerWorker: async (owner) => {
      events.push(`register-${owner}`);
      return { allowed: true, reason: "registered" };
    },
  });
  const tmux = stubTmux({
    resumeWorker: async () => events.push("resume-7"),
    openWorker: async () => events.push("open-2"),
  });

  const result = await runOnce({
    gh: stubGh({ listReadyIssues: async () => [2] }),
    tmux, sentinel, pauseStore, repo: "o/r", claimedIssues: [7],
    checkSetupReady: async () => false,
    concurrency: 3, log: () => {},
  });

  assert.deepEqual(events, ["unregister-o/r#7"]);
  assert.deepEqual(result, { done: false, liveCount: 0, started: 0, resumed: 0, paused: true });
});

test("runOnce is done when no ready issues and no live workers", async () => {
  const res = await runOnce({
    gh: stubGh(), tmux: stubTmux(), checkGate: gateOpen, concurrency: 3, log: () => {},
  });
  assert.equal(res.done, true);
});
