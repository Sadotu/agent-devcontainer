import { test } from "node:test";
import assert from "node:assert/strict";
import { execFile, spawn, spawnSync } from "node:child_process";
import { createServer } from "node:http";
import { chmod, readFile, readdir, mkdtemp, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { runAdmissionHook, terminateCurrentWindow } from "../hooks/pretooluse-usage-gate.mjs";
import { createConfiguredSentinel } from "../bin/supervisor.mjs";

const execFileAsync = promisify(execFile);

async function startSentinel(handler) {
  const requests = [];
  const server = createServer((req, res) => {
    requests.push({ method: req.method, url: req.url });
    handler(req, res);
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const { port } = server.address();
  return {
    requests,
    url: `http://127.0.0.1:${port}`,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

async function runHook(input, env = {}) {
  const root = await mkdtemp(join(tmpdir(), "pause-hook-cli-"));
  const tmux = join(root, "tmux");
  await writeFile(tmux, "#!/bin/sh\nexit 0\n");
  await chmod(tmux, 0o700);
  const payload = {
    session_id: "cli-session",
    tool_use_id: "cli-tool-use",
    cwd: "/workspace/worker",
    ...input,
  };
  return new Promise((resolve) => {
    const child = spawn("node", ["hooks/pretooluse-usage-gate.mjs"], {
      env: {
        ...process.env,
        ISSUE_ORCHESTRATOR_ISSUE: "52",
        ISSUE_ORCHESTRATOR_PAUSE_DIR: join(root, "pauses"),
        TMUX_PANE: "%1",
        PATH: `${root}:${process.env.PATH}`,
        ...env,
      },
    });
    let stderr = "";
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("close", async (code) => {
      await rm(root, { recursive: true, force: true });
      resolve({ code, stderr });
    });
    child.stdin.end(JSON.stringify(payload));
  });
}

function validTelemetry({ short = 42, weekly = 73 } = {}) {
  return {
    provider: "claude-code",
    fetchedAt: "2026-07-24T12:00:00.000Z",
    status: "ok",
    windows: {
      short: { usedPercent: short, resetsAt: null, windowSeconds: 18000 },
      long: { usedPercent: weekly, resetsAt: null, windowSeconds: 604800 },
    },
  };
}

test("hook without SENTINEL_URL sends GET to shared-network usage telemetry", async () => {
  const calls = [];
  const result = await runAdmissionHook({ tool_name: "Agent" }, {
    env: {},
    fetchImpl: async (...args) => {
      calls.push(args);
      return new Response(JSON.stringify(validTelemetry()), { status: 200 });
    },
  });
  assert.deepEqual(result, { allowed: true, reason: "admitted" });
  assert.equal(calls[0][0], "http://usage-sentinel:4317/usage/claude-code");
  assert.equal(calls[0][1].method, "GET");
});

test("a mid-issue Agent start is denied when short usage reaches its threshold", async () => {
  let invocation = 0;
  const sentinel = await startSentinel((_req, res) => {
    invocation += 1;
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(validTelemetry({ short: invocation === 1 ? 79 : 80 })));
  });

  const first = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  const second = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();

  assert.equal(first.code, 0);
  assert.equal(second.code, 2);
  assert.match(second.stderr, /threshold_reached/);
  assert.deepEqual(sentinel.requests, [
    { method: "GET", url: "/usage/claude-code" },
    { method: "GET", url: "/usage/claude-code" },
  ]);
});

test("supervisor sends requests to its explicit Sentinel override", async () => {
  const calls = [];
  const client = createConfiguredSentinel({
    env: { SENTINEL_URL: "http://sentinel.override:9876" },
    fetchImpl: async (...args) => {
      calls.push(args);
      return new Response(JSON.stringify(validTelemetry()), { status: 200 });
    },
  });
  assert.deepEqual(await client.checkAdmission(), { allowed: true, reason: "admitted" });
  assert.equal(calls[0][0], "http://sentinel.override:9876/usage/claude-code");
});

test("Agent checks admission with GET using the explicit Sentinel override", async () => {
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(validTelemetry()));
  });
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 0);
  assert.deepEqual(sentinel.requests, [{ method: "GET", url: "/usage/claude-code" }]);
});

for (const [reason, telemetry] of [
  ["threshold_reached", validTelemetry({ short: 80 })],
  ["telemetry_unavailable", { ...validTelemetry(), status: "stale" }],
]) {
  test(`Agent exits 2 for normalized ${reason}`, async () => {
    const sentinel = await startSentinel((_req, res) => {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify(telemetry));
    });
    const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
    await sentinel.close();
    assert.equal(result.code, 2);
    assert.match(result.stderr, new RegExp(reason));
  });
}

test("Agent exits 2 with telemetry_unavailable for an unexpected status", async () => {
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(409, { "content-type": "application/json" });
    res.end(JSON.stringify({ allowed: false, reason: "capacity_reached" }));
  });
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 2);
  assert.match(result.stderr, /telemetry_unavailable/);
});

test("Agent exits 2 for malformed JSON", async () => {
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end("not-json");
  });
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 2);
  assert.match(result.stderr, /telemetry_unavailable/);
});

test("Agent exits 2 when Sentinel times out", async () => {
  const sentinel = await startSentinel(() => {});
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 2);
  assert.match(result.stderr, /telemetry_unavailable/);
});

test("Agent exits 2 when Sentinel is unreachable", async () => {
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: "http://127.0.0.1:1" });
  assert.equal(result.code, 2);
  assert.match(result.stderr, /telemetry_unavailable/);
});

test("PreToolUse configuration sends every tool through the hook", async () => {
  const settings = JSON.parse(await readFile(".claude/settings.json", "utf8"));
  assert.equal(settings.hooks.PreToolUse[0].matcher, "");
});

for (const tool_name of ["Read", "Bash", "Agent"]) {
  test(`${tool_name} checks admission`, async () => {
    const calls = [];
    const result = await runAdmissionHook({ tool_name }, {
      env: {},
      fetchImpl: async (...args) => {
        calls.push(args);
        return new Response(JSON.stringify(validTelemetry()), { status: 200 });
      },
      writePause: async () => assert.fail("allowed admission must not write"),
      terminateWindow: async () => assert.fail("allowed admission must not terminate"),
    });
    assert.deepEqual(result, { allowed: true, reason: "admitted" });
    assert.equal(calls.length, 1);
  });
}

test("denial durably records supervisor ownership before terminating its current window", async () => {
  const events = [];
  const directory = await mkdtemp(join(tmpdir(), "pause-hook-"));
  const result = await runAdmissionHook({
    session_id: "session-1", tool_use_id: "tool-2", tool_name: "Read", cwd: "/workspace/worker",
    issue: 999,
  }, {
    env: {
      ISSUE_ORCHESTRATOR_ISSUE: "52",
      ISSUE_ORCHESTRATOR_PAUSE_DIR: directory,
      TMUX_PANE: "%7",
    },
    now: () => new Date("2026-07-25T12:34:56.000Z"),
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async (dir, record) => {
      events.push(["write", dir, record]);
    },
    terminateWindow: async (pane) => events.push(["terminate", pane]),
  });
  assert.deepEqual(result, { allowed: false, reason: "threshold_reached" });
  assert.deepEqual(events, [
    ["write", directory, {
      issue: 52,
      sessionId: "session-1",
      toolUseId: "tool-2",
      toolName: "Read",
      cwd: "/workspace/worker",
      reason: "threshold_reached",
      pausedAt: "2026-07-25T12:34:56.000Z",
      tmuxPane: "%7",
    }],
    ["terminate", "%7"],
  ]);
});

for (const reason of ["threshold_reached", "telemetry_unavailable"]) {
  test(`${reason} never returns allow and persists the normalized reason`, async () => {
    let record;
    const telemetry = reason === "threshold_reached"
      ? validTelemetry({ weekly: 95 })
      : { ...validTelemetry(), provider: "wrong" };
    const result = await runAdmissionHook({
      session_id: "s", tool_use_id: "u", tool_name: "Bash", cwd: "/w",
    }, {
      env: { ISSUE_ORCHESTRATOR_ISSUE: "52", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/pauses", TMUX_PANE: "%1" },
      fetchImpl: async () => new Response(JSON.stringify(telemetry), { status: 200 }),
      writePause: async (_dir, value) => { record = value; },
      terminateWindow: async () => {},
    });
    assert.equal(result.allowed, false);
    assert.equal(record.reason, reason);
  });
}

test("invalid pause context denies without writing or terminating", async () => {
  let wrote = false;
  let terminated = false;
  const result = await runAdmissionHook({ tool_name: "Read" }, {
    env: { ISSUE_ORCHESTRATOR_ISSUE: "payload-is-not-ownership", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/p", TMUX_PANE: "%1" },
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async () => { wrote = true; },
    terminateWindow: async () => { terminated = true; },
  });
  assert.deepEqual(result, { allowed: false, reason: "invalid_pause_context" });
  assert.equal(wrote, false);
  assert.equal(terminated, false);
});

test("pause write failure denies and does not terminate", async () => {
  let terminated = false;
  const result = await runAdmissionHook({ session_id: "s", tool_use_id: "u", tool_name: "Read", cwd: "/w" }, {
    env: { ISSUE_ORCHESTRATOR_ISSUE: "52", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/p", TMUX_PANE: "%1" },
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async () => { throw new Error("disk full"); },
    terminateWindow: async () => { terminated = true; },
  });
  assert.deepEqual(result, { allowed: false, reason: "pause_write_failed" });
  assert.equal(terminated, false);
});

test("termination failure denies after retaining the durable record", async () => {
  let wrote = false;
  const result = await runAdmissionHook({ session_id: "s", tool_use_id: "u", tool_name: "Read", cwd: "/w" }, {
    env: { ISSUE_ORCHESTRATOR_ISSUE: "52", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/p", TMUX_PANE: "%1" },
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async () => { wrote = true; },
    terminateWindow: async () => { throw new Error("tmux failed"); },
  });
  assert.deepEqual(result, { allowed: false, reason: "termination_failed" });
  assert.equal(wrote, true);
});

test("blocked tmux termination is bounded and retains the pause record", async () => {
  let wrote = false;
  let executionOptions;
  const startedAt = Date.now();
  const result = await runAdmissionHook({ session_id: "s", tool_use_id: "u", tool_name: "Read", cwd: "/w" }, {
    env: { ISSUE_ORCHESTRATOR_ISSUE: "52", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/p", TMUX_PANE: "%1" },
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async () => { wrote = true; },
    terminateWindow: (pane) => terminateCurrentWindow(pane, {
      execFileImpl: (_file, _args, options, callback) => {
        executionOptions = options;
        setTimeout(() => callback(Object.assign(new Error("timed out"), { killed: true })), options.timeout);
      },
    }),
  });
  assert.equal(result.reason, "termination_failed");
  assert.equal(wrote, true);
  assert.equal(executionOptions.timeout, 1000);
  assert.equal(executionOptions.killSignal, "SIGKILL");
  assert.ok(Date.now() - startedAt < 1500);
});

test("non-canonical tmux pane is invalid pause context", async () => {
  let wrote = false;
  const result = await runAdmissionHook({ session_id: "s", tool_use_id: "u", tool_name: "Read", cwd: "/w" }, {
    env: { ISSUE_ORCHESTRATOR_ISSUE: "52", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/p", TMUX_PANE: "worker-window" },
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async () => { wrote = true; },
  });
  assert.deepEqual(result, { allowed: false, reason: "invalid_pause_context" });
  assert.equal(wrote, false);
});

test("real tmux termination persists pause state, kills the window, and prevents later work", async (t) => {
  if (spawnSync("tmux", ["-V"], { stdio: "ignore" }).status !== 0) {
    t.skip("tmux is unavailable");
    return;
  }

  const root = await mkdtemp(join(tmpdir(), "pause-hook-tmux-"));
  const session = `pause-hook-${process.pid}-${Date.now()}`;
  const pauseDir = join(root, "pauses");
  const input = join(root, "input.json");
  const marker = join(root, "after-hook");
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(validTelemetry({ short: 80 })));
  });

  try {
    await writeFile(input, JSON.stringify({
      session_id: "real-session",
      tool_use_id: "real-use",
      tool_name: "Bash",
      cwd: "/workspace/worker",
    }));
    const command = `node hooks/pretooluse-usage-gate.mjs < "${input}"; touch "${marker}"`;
    await execFileAsync("tmux", [
      "new-session", "-d", "-s", session,
      "-e", "ISSUE_ORCHESTRATOR_ISSUE=52",
      "-e", `ISSUE_ORCHESTRATOR_PAUSE_DIR=${pauseDir}`,
      "-e", `SENTINEL_URL=${sentinel.url}`,
      command,
    ], { cwd: process.cwd() });

    const deadline = Date.now() + 3000;
    while (Date.now() < deadline) {
      const exists = await readdir(pauseDir).then((files) => files.some((file) => file.startsWith("52-")), () => false);
      const windowAlive = spawnSync("tmux", ["has-session", "-t", session], { stdio: "ignore" }).status === 0;
      if (exists && !windowAlive) break;
      await new Promise((resolve) => setTimeout(resolve, 25));
    }

    const [pauseFile] = await readdir(pauseDir);
    const record = JSON.parse(await readFile(join(pauseDir, pauseFile), "utf8"));
    assert.equal(record.issue, 52);
    assert.equal(record.toolName, "Bash");
    assert.equal(spawnSync("tmux", ["has-session", "-t", session], { stdio: "ignore" }).status, 1);
    assert.equal(await stat(marker).then(() => true, () => false), false);
  } finally {
    spawnSync("tmux", ["kill-session", "-t", session], { stdio: "ignore" });
    await sentinel.close();
    await rm(root, { recursive: true, force: true });
  }
});

test("code after the termination boundary remains pending while termination has not returned", async () => {
  let marker = false;
  const pending = runAdmissionHook({ session_id: "s", tool_use_id: "u", tool_name: "Read", cwd: "/w" }, {
    env: { ISSUE_ORCHESTRATOR_ISSUE: "52", ISSUE_ORCHESTRATOR_PAUSE_DIR: "/p", TMUX_PANE: "%1" },
    fetchImpl: async () => new Response(JSON.stringify(validTelemetry({ short: 80 })), { status: 200 }),
    writePause: async () => {},
    terminateWindow: async () => new Promise(() => {}),
  }).then(() => { marker = true; });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(marker, false);
  void pending;
});
