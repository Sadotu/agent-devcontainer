import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

import {
  listPauseRecords,
  removePauseRecord,
  pauseRecordFilename,
  validatePauseRecord,
  writePauseRecord,
} from '../src/pauseStore.mjs';

const record = (issue, overrides = {}) => ({
  issue,
  sessionId: `session-${issue}`,
  toolUseId: `tool-use-${issue}`,
  toolName: 'shell',
  cwd: '/workspaces/example',
  reason: 'usage limit reached',
  pausedAt: '2026-07-25T12:34:56.000Z',
  tmuxPane: `%${issue}`,
  ...overrides,
});
const confirmationFor = (filename) => `${filename}.confirmed`;
async function confirm(root, filename) {
  const contents = await readFile(join(root, filename), 'utf8');
  const digest = createHash('sha256').update(contents).digest('hex');
  await writeFile(join(root, confirmationFor(filename)), `${JSON.stringify({ filename, digest })}\n`, 'utf8');
}

async function tempDirectory(t) {
  const directory = await mkdtemp(join(tmpdir(), 'pause-store-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  return directory;
}

test('validatePauseRecord accepts the exact pause record shape', () => {
  assert.deepEqual(validatePauseRecord(record(7)), record(7));
});

test('validatePauseRecord rejects unknown enumerable fields', () => {
  assert.throws(() => validatePauseRecord({ ...record(7), extra: true }), /unknown field.*extra/);
});

test('validatePauseRecord rejects required fields inherited from a prototype', () => {
  assert.throws(() => validatePauseRecord(Object.create(record(7))), /own enumerable field.*issue/);
});

test('writePauseRecord persists an exact round trip with restrictive permissions', async (t) => {
  const root = await tempDirectory(t);

  await writePauseRecord(root, record(7));

  const filename = pauseRecordFilename(record(7));
  assert.deepEqual(JSON.parse(await readFile(join(root, filename), 'utf8')), record(7));
  assert.equal((await stat(join(root, filename))).mode & 0o777, 0o600);
  assert.deepEqual((await readdir(root)).sort(), [filename, confirmationFor(filename)].sort());
});

test('writePauseRecord syncs file before rename and directory after rename', async () => {
  const events = [];
  const fileHandle = {
    writeFile: async () => events.push('write'),
    sync: async () => events.push('file-sync'),
    close: async () => events.push('file-close'),
  };
  const directoryHandle = {
    sync: async () => events.push('directory-sync'),
    close: async () => events.push('directory-close'),
  };
  await writePauseRecord('/pauses', record(7), {
    mkdir: async () => events.push('mkdir'),
    open: async (path) => path === '/pauses'
      ? (events.push('directory-open'), directoryHandle)
      : (events.push('file-open'), fileHandle),
    rename: async () => events.push('rename'),
    rm: async () => events.push('rm'),
  });
  assert.deepEqual(events, [
    'mkdir', 'mkdir', 'file-open', 'write', 'file-sync', 'file-close',
    'rename', 'directory-open', 'directory-sync', 'directory-close',
    'file-open', 'write', 'file-sync', 'file-close',
    'rename', 'directory-open', 'directory-sync', 'directory-close', 'rm',
  ]);
});

test('a published record is invisible until its record directory barrier completes and confirmation is published', async (t) => {
  const root = await tempDirectory(t);
  let reachedBarrier;
  const barrierReached = new Promise((resolve) => { reachedBarrier = resolve; });
  let releaseBarrier;
  const barrierRelease = new Promise((resolve) => { releaseBarrier = resolve; });
  let directorySyncs = 0;
  const writing = writePauseRecord(root, record(6), {
    open: async (path, ...args) => {
      const { open } = await import('node:fs/promises');
      const handle = await open(path, ...args);
      if (path === root) {
        const sync = handle.sync.bind(handle);
        handle.sync = async () => {
          directorySyncs += 1;
          if (directorySyncs === 1) {
            reachedBarrier();
            await barrierRelease;
          }
          await sync();
        };
      }
      return handle;
    },
  });
  await barrierReached;
  assert.ok((await readdir(root)).some((file) => file.endsWith('.json')));
  const inProgress = await listPauseRecords(root);
  assert.deepEqual(inProgress.records, []);
  assert.equal(inProgress.errors[0].file, '6.lock');
  releaseBarrier();
  await writing;
  assert.deepEqual((await listPauseRecords(root)).records, [record(6)]);
});

test('list fails closed while writer holds the issue lock after marker publication', async (t) => {
  const root = await tempDirectory(t);
  let reachedFinalBarrier;
  const finalBarrierReached = new Promise((resolve) => { reachedFinalBarrier = resolve; });
  let releaseFinalBarrier;
  const finalBarrierRelease = new Promise((resolve) => { releaseFinalBarrier = resolve; });
  let directorySyncs = 0;
  const writing = writePauseRecord(root, record(6), {
    open: async (path, ...args) => {
      const { open } = await import('node:fs/promises');
      const handle = await open(path, ...args);
      if (path === root) {
        const sync = handle.sync.bind(handle);
        handle.sync = async () => {
          directorySyncs += 1;
          if (directorySyncs === 2) { reachedFinalBarrier(); await finalBarrierRelease; }
          await sync();
        };
      }
      return handle;
    },
  });
  await finalBarrierReached;
  const listing = await listPauseRecords(root);
  assert.deepEqual(listing.records, []);
  assert.match(listing.errors[0].file, /^6\.lock$/);
  releaseFinalBarrier();
  await writing;
});

test('malformed and mismatched confirmation markers are issue-associated errors', async (t) => {
  for (const [issue, marker] of [
    [21, '{bad json'],
    [22, JSON.stringify({ filename: 'wrong.json', digest: 'a'.repeat(64) })],
    [23, JSON.stringify({ filename: pauseRecordFilename(record(23)), digest: 'b'.repeat(64) })],
  ]) {
    const root = await tempDirectory(t);
    const filename = pauseRecordFilename(record(issue));
    await writeFile(join(root, filename), `${JSON.stringify(record(issue))}\n`);
    await writeFile(join(root, `${filename}.confirmed`), marker);
    const listing = await listPauseRecords(root);
    assert.deepEqual(listing.records, []);
    assert.equal(listing.errors[0].file, filename);
    assert.match(listing.errors[0].error, /confirmation/i);
  }
});

test('same-generation concurrent writes serialize and leave one confirmed valid record', async (t) => {
  const root = await tempDirectory(t);
  const candidates = [record(31, { reason: 'first' }), record(31, { reason: 'second' })];
  await Promise.all(candidates.map((candidate) => writePauseRecord(root, candidate)));
  const listing = await listPauseRecords(root);
  assert.equal(listing.records.length, 1);
  assert.ok(candidates.some((candidate) => candidate.reason === listing.records[0].reason));
  assert.deepEqual(listing.errors, []);
});

test('lock-only issue is reported fail-closed and exact removal honors the lock', async (t) => {
  const root = await tempDirectory(t);
  const { mkdir } = await import('node:fs/promises');
  await mkdir(join(root, '41.lock'));
  const listing = await listPauseRecords(root);
  assert.deepEqual(listing.records, []);
  assert.equal(listing.errors[0].file, '41.lock');
  await assert.rejects(removePauseRecord(root, record(41)), /lock/i);
});

test('writePauseRecord rejects a directory sync failure without exposing an actionable record', async (t) => {
  const root = await tempDirectory(t);
  const fsOps = {
    open: async (path, ...args) => {
      const { open } = await import('node:fs/promises');
      const handle = await open(path, ...args);
      if (path === root) handle.sync = async () => { throw new Error('directory sync failed'); };
      return handle;
    },
  };

  await assert.rejects(writePauseRecord(root, record(8), fsOps), /directory sync failed/);
  assert.deepEqual(await listPauseRecords(root), { records: [], errors: [] });
  assert.deepEqual((await readdir(root)).filter((file) => file.endsWith('.tmp')), []);
});

test('record sync failure remains invisible even when withdrawal rename and unlink fail', async (t) => {
  const root = await tempDirectory(t);
  let renames = 0;
  await assert.rejects(writePauseRecord(root, record(9), {
    open: async (path, ...args) => {
      const { open } = await import('node:fs/promises');
      const handle = await open(path, ...args);
      if (path === root) handle.sync = async () => { throw new Error('directory sync failed'); };
      return handle;
    },
    rename: async (...args) => {
      const { rename } = await import('node:fs/promises');
      renames += 1;
      if (renames > 1) throw new Error('withdraw rename failed');
      return rename(...args);
    },
    rm: async () => { throw new Error('withdraw unlink failed'); },
  }), /directory sync failed/);
  assert.ok((await readdir(root)).some((file) => file.endsWith('.json')));
  const listing = await listPauseRecords(root);
  assert.deepEqual(listing.records, []);
  assert.equal(listing.errors[0].file, '9.lock');
});

test('listPauseRecords returns records sorted by issue', async (t) => {
  const root = await tempDirectory(t);
  await writePauseRecord(root, record(12));
  await writePauseRecord(root, record(2));

  assert.deepEqual(await listPauseRecords(root), {
    records: [record(2), record(12)],
    errors: [],
  });
});

test('listPauseRecords reports corrupt and incomplete records without removing them', async (t) => {
  const root = await tempDirectory(t);
  await writeFile(join(root, '3.json'), '{not json', 'utf8');
  await writeFile(join(root, '4.json'), JSON.stringify({ issue: 4 }), 'utf8');
  await confirm(root, '3.json');
  await confirm(root, '4.json');

  const result = await listPauseRecords(root);

  assert.deepEqual(result.records, []);
  assert.deepEqual(result.errors.map(({ file }) => file), ['3.json', '4.json']);
  assert.match(result.errors[0].error, /JSON/);
  assert.match(result.errors[1].error, /sessionId/);
  assert.deepEqual((await readdir(root)).sort(), ['3.json', '3.json.confirmed', '4.json', '4.json.confirmed']);
});

test('listPauseRecords reports and retains a record whose issue differs from its filename', async (t) => {
  const root = await tempDirectory(t);
  await writeFile(join(root, '9.json'), JSON.stringify(record(10)), 'utf8');
  await confirm(root, '9.json');

  const result = await listPauseRecords(root);

  assert.deepEqual(result.records, []);
  assert.deepEqual(result.errors.map(({ file }) => file), ['9.json']);
  assert.match(result.errors[0].error, /filename.*issue/i);
  assert.deepEqual((await readdir(root)).sort(), ['9.json', '9.json.confirmed']);
});

test('listPauseRecords treats a missing directory as empty', async () => {
  const root = join(tmpdir(), `missing-pause-store-${process.pid}-${Date.now()}`);
  assert.deepEqual(await listPauseRecords(root), { records: [], errors: [] });
});

test('removePauseRecord deletes idempotently and validates the issue', async (t) => {
  const root = await tempDirectory(t);
  await writePauseRecord(root, record(5));

  await removePauseRecord(root, 5);
  await removePauseRecord(root, 5);

  assert.deepEqual(await readdir(root), []);
  await assert.rejects(removePauseRecord(root, 0), /positive integer/);
});

test('removing an expected generation cannot delete a newer pause generation', async (t) => {
  const root = await tempDirectory(t);
  const first = record(5, { toolUseId: 'generation-1', pausedAt: '2026-07-25T12:00:00Z' });
  const second = record(5, { toolUseId: 'generation-2', pausedAt: '2026-07-25T12:01:00Z' });
  await writePauseRecord(root, first);
  await writePauseRecord(root, second);

  await removePauseRecord(root, first);

  assert.deepEqual((await listPauseRecords(root)).records, [second]);
  assert.deepEqual((await readdir(root)).sort(), [pauseRecordFilename(second), confirmationFor(pauseRecordFilename(second))].sort());
});

test('multiple preexisting valid generations are ambiguous and retained without selecting either', async (t) => {
  const root = await tempDirectory(t);
  const old = record(5, { toolUseId: 'old', pausedAt: '2026-07-25T12:00:00Z' });
  const fresh = record(5, { toolUseId: 'fresh', pausedAt: '2026-07-25T12:01:00Z' });
  await writePauseRecord(root, old);
  await writePauseRecord(root, fresh);

  const listing = await listPauseRecords(root);
  assert.deepEqual(listing.records, []);
  assert.equal(listing.errors.length, 2);
  assert.ok(listing.errors.every(({ error }) => /ambiguous.*multiple valid generations/i.test(error)));
  assert.equal((await readdir(root)).length, 4);
});

test('exact consumption does not delete a distinct generation with a backward timestamp', async (t) => {
  const root = await tempDirectory(t);
  const selected = record(5, { toolUseId: 'selected', pausedAt: '2026-07-25T12:01:00Z' });
  const newer = record(5, { toolUseId: 'newer', pausedAt: '2026-07-24T12:00:00Z' });
  await writePauseRecord(root, selected);
  await writePauseRecord(root, newer);

  await removePauseRecord(root, selected);

  assert.deepEqual((await listPauseRecords(root)).records, [newer]);
});

test('writePauseRecord rejects every invalid field without writing files', async (t) => {
  const invalidValues = {
    issue: [0, -1, 1.5, '1'],
    sessionId: ['', '   ', null],
    toolUseId: ['', 1],
    toolName: ['', undefined],
    cwd: ['', false],
    reason: [' ', {}],
    pausedAt: ['', 'yesterday', '2026-02-30T12:00:00Z', 1],
  };

  for (const [field, values] of Object.entries(invalidValues)) {
    for (const value of values) {
      const root = await tempDirectory(t);
      await assert.rejects(writePauseRecord(root, record(1, { [field]: value })), new RegExp(field));
      assert.deepEqual(await readdir(root), []);
    }
  }
});

test('writePauseRecord cleans its temporary file when serialization fails', async (t) => {
  const root = await tempDirectory(t);
  const changingRecord = record(8);
  let pausedAtReads = 0;
  Object.defineProperty(changingRecord, 'pausedAt', {
    enumerable: true,
    get() {
      pausedAtReads += 1;
      return pausedAtReads === 1 ? '2026-07-25T12:34:56.000Z' : 1n;
    },
  });

  await assert.rejects(writePauseRecord(root, changingRecord), /BigInt/);

  assert.deepEqual(await readdir(root), []);
});

test('concurrent overwrites leave one complete record and no temporary files', async (t) => {
  const root = await tempDirectory(t);
  const candidates = Array.from({ length: 20 }, (_, index) => record(11, {
    reason: `concurrent-${index}`,
  }));

  await Promise.all(candidates.map((candidate) => writePauseRecord(root, candidate)));

  const files = await readdir(root);
  assert.equal(files.length, 2);
  const recordFile = files.find((file) => file.endsWith('.json'));
  const stored = JSON.parse(await readFile(join(root, recordFile), 'utf8'));
  assert.ok(candidates.some((candidate) => JSON.stringify(candidate) === JSON.stringify(stored)));
  assert.deepEqual(files.sort(), [recordFile, confirmationFor(recordFile)].sort());
});
