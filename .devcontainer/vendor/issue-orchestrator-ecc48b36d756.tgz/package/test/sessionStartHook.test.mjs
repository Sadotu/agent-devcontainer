import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const hook = fileURLToPath(new URL('../hooks/sessionstart-resume-ack.mjs', import.meta.url));

async function runHook(input, env) {
  const child = spawn(process.execPath, [hook], { env: { ...process.env, ...env }, stdio: ['pipe', 'pipe', 'pipe'] });
  child.stdin.end(JSON.stringify(input));
  const stderr = [];
  child.stderr.on('data', (chunk) => stderr.push(chunk));
  const [code] = await once(child, 'exit');
  assert.equal(code, 0, Buffer.concat(stderr).toString());
}

test('resume SessionStart writes an exact session and generation acknowledgement', async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'resume-ack-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const generation = `52-${'a'.repeat(64)}.json`;
  await runHook({ source: 'resume', session_id: 'session-52' }, {
    ISSUE_ORCHESTRATOR_PAUSE_DIR: directory,
    ISSUE_ORCHESTRATOR_RESUME_SESSION: 'session-52',
    ISSUE_ORCHESTRATOR_RESUME_GENERATION: generation,
  });
  const acknowledgement = JSON.parse(await readFile(join(directory, `.${generation}.resume-ack`), 'utf8'));
  assert.deepEqual(acknowledgement, { sessionId: 'session-52', generation });
});

test('SessionStart hook does not acknowledge a new session or wrong resumed session', async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'resume-ack-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const env = {
    ISSUE_ORCHESTRATOR_PAUSE_DIR: directory,
    ISSUE_ORCHESTRATOR_RESUME_SESSION: 'expected-session',
    ISSUE_ORCHESTRATOR_RESUME_GENERATION: `52-${'b'.repeat(64)}.json`,
  };
  await runHook({ source: 'startup', session_id: 'expected-session' }, env);
  await runHook({ source: 'resume', session_id: 'wrong-session' }, env);
  assert.deepEqual(await readdir(directory), []);
});
