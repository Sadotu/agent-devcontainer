import { BLOCKED, MANAGED_LABELS, MERGE_REVIEW, PHASE_LABELS, REVIEW, phaseOf } from "./labels.mjs";

const BRANCH_PREFIX = /^agent\/(\d+)-/;

function branchIssue(pr) {
  const match = BRANCH_PREFIX.exec(String(pr.headRefName || ""));
  return match ? Number(match[1]) : null;
}

function closingIssues(pr) {
  const refs = Array.isArray(pr.closingIssuesReferences) ? pr.closingIssuesReferences : [];
  return refs.map((ref) => Number(ref?.number)).filter((n) => Number.isInteger(n));
}

// Pair each `agent-running` issue with the single open PR that closes it.
// Closing references are authoritative; the `agent/<n>-` branch prefix is only
// a fallback for a PR that declares no closing reference at all. A PR whose
// branch names a different issue than its closing reference is a conflict, not
// a match, and fails closed. PRs that match no managed issue — manual
// `/github-issue` PRs, unrelated `agent/*` branches — are ignored entirely.
export function resolveManagedPrs(issues, prs) {
  const managed = [];
  const problems = [];
  const ordered = [...(issues || [])].sort((a, b) => a.number - b.number);

  for (const issue of ordered) {
    const phase = phaseOf(issue.labels);
    const candidates = [];
    for (const pr of prs || []) {
      const closes = closingIssues(pr);
      const branch = branchIssue(pr);
      if (closes.includes(issue.number)) {
        if (branch !== null && branch !== issue.number) {
          problems.push({
            issue,
            pr,
            reason: "conflicting-linkage",
            message: `PR #${pr.number} closes #${issue.number} but its branch \`${pr.headRefName}\` names #${branch}.`,
          });
          continue;
        }
        candidates.push(pr);
      } else if (closes.length === 0 && branch === issue.number) {
        candidates.push(pr);
      }
    }

    if (candidates.length === 1) {
      managed.push({ issue, pr: candidates[0] });
    } else if (candidates.length > 1) {
      problems.push({
        issue,
        pr: null,
        reason: "duplicate-linkage",
        message: `Issue #${issue.number} is closed by more than one open PR: ${candidates.map((p) => `#${p.number}`).join(", ")}.`,
      });
    } else if (phase === REVIEW) {
      // Only a review-phase issue *must* have a PR. An issue still being
      // implemented legitimately has none yet, and a terminal issue's PR may
      // already be closed.
      problems.push({
        issue,
        pr: null,
        reason: "missing-linkage",
        message: `Issue #${issue.number} is labelled \`${REVIEW}\` but no open PR closes it.`,
      });
    }
  }
  return { managed, problems };
}

const GREEN_CONCLUSIONS = new Set(["SUCCESS", "NEUTRAL", "SKIPPED"]);
const FAILING_CONCLUSIONS = new Set([
  "FAILURE", "TIMED_OUT", "CANCELLED", "ACTION_REQUIRED", "STARTUP_FAILURE", "STALE",
]);
const PENDING_STATUSES = new Set(["QUEUED", "IN_PROGRESS", "WAITING", "PENDING", "REQUESTED"]);
const STUCK_CHECK_MS = 6 * 60 * 60 * 1000;

function checkName(entry) {
  return entry.name ?? entry.context ?? "(unnamed check)";
}
function checkUrl(entry) {
  return entry.detailsUrl ?? entry.targetUrl ?? null;
}

// Normalise one rollup entry. GitHub reports modern CheckRuns (status +
// conclusion) and legacy StatusContexts (state) in the same array.
function checkState(entry) {
  if (!entry || typeof entry !== "object") return "unknown";
  if (typeof entry.state === "string") {
    if (entry.state === "SUCCESS") return "green";
    if (entry.state === "PENDING" || entry.state === "EXPECTED") return "pending";
    if (entry.state === "FAILURE" || entry.state === "ERROR") return "failing";
    return "unknown";
  }
  if (typeof entry.status !== "string") return "unknown";
  if (PENDING_STATUSES.has(entry.status)) return "pending";
  if (entry.status !== "COMPLETED") return "unknown";
  if (GREEN_CONCLUSIONS.has(entry.conclusion)) return "green";
  if (FAILING_CONCLUSIONS.has(entry.conclusion)) return "failing";
  return "unknown";
}

function pendingElapsedMs(entry, now) {
  const timestamp = typeof entry.state === "string" ? entry.createdAt : entry.startedAt;
  if (typeof timestamp !== "string") return null;
  const started = Date.parse(timestamp);
  const elapsed = now - started;
  return Number.isFinite(started) && Number.isFinite(elapsed) && elapsed >= 0 ? elapsed : null;
}

function timedCheckState(entry, now) {
  const state = checkState(entry);
  if (state !== "pending") return state;
  const elapsed = pendingElapsedMs(entry, now);
  if (elapsed === null) return "unknown";
  return elapsed > STUCK_CHECK_MS ? "stuck" : "pending";
}

// Every check GitHub reports is treated as required: reading branch-protection
// required-check names needs an extra admin-scoped call and could only ever
// make this gate more permissive.
//
// An empty array means "no checks configured" and counts as green. Absent or
// unreadable data is `unknown`, which transitions nothing — the two must never
// be conflated, or a failed fetch would silently promote an unverified PR.
export function classifyChecks(rollup, now = Date.now()) {
  if (!Array.isArray(rollup)) return "unknown";
  const states = rollup.map((entry) => timedCheckState(entry, now));
  if (states.includes("failing")) return "failing";
  if (states.includes("unknown")) return "unknown";
  if (states.includes("stuck")) return "stuck";
  if (states.includes("pending")) return "pending";
  return "green";
}

export function failingChecks(rollup) {
  if (!Array.isArray(rollup)) return [];
  return rollup
    .filter((entry) => checkState(entry) === "failing")
    .map((entry) => ({ name: checkName(entry), url: checkUrl(entry) }));
}

export function stuckChecks(rollup, now = Date.now()) {
  if (!Array.isArray(rollup)) return [];
  return rollup
    .filter((entry) => timedCheckState(entry, now) === "stuck")
    .map((entry) => ({
      name: checkName(entry),
      url: checkUrl(entry),
      elapsedMs: pendingElapsedMs(entry, now),
    }));
}

// One action per PR per poll.
//
// A clean verdict marks a draft PR ready and stops there ("open"): checks were
// read before the PR opened, so a repository whose CI triggers on
// `ready_for_review` would still report an empty rollup and be promoted
// without ever running. The next poll evaluates the checks for real.
// Verdicts are the producer's exact literals (review-pr:v1). Anything else —
// including the old lowercase spellings — is a contract violation and fails
// closed rather than being re-reviewed forever.
export function planVerdict({ marker, checks, isDraft }) {
  if (!marker) return { action: "review" };
  if (marker.verdict === "BLOCKING") return { action: "block", reason: "blocking-verdict" };
  if (marker.verdict !== "PASS") return { action: "block", reason: "unrecognised-verdict" };
  if (isDraft) return { action: "open" };
  if (checks === "green") return { action: "pass" };
  if (checks === "pending") return { action: "wait" };
  if (checks === "failing") return { action: "fail-checks" };
  if (checks === "stuck") return { action: "stuck-checks" };
  return { action: "retry" };
}

// PR labels mirror the canonical issue labels, restricted to the managed
// vocabulary so a reviewer's own labels are never disturbed. Returning empty
// lists lets the caller skip the API call entirely when nothing differs.
export function planLabelMirror(issueLabels, prLabels) {
  const managed = new Set(MANAGED_LABELS);
  const desired = (issueLabels || []).filter((name) => managed.has(name));
  const current = new Set((prLabels || []).filter((name) => managed.has(name)));
  const wanted = new Set(desired);
  return {
    add: desired.filter((name) => !current.has(name)),
    remove: [...current].filter((name) => !wanted.has(name)),
  };
}

// Swap the issue's phase label and mirror it onto the PR. `agent-running` is
// never removed here — it survives every phase swap, and only the supervisor
// releases it, once the PR is ready for the owner.
export async function setPhase({ gh, issue, pr, phase }) {
  const deltaFor = (labels) => {
    const current = new Set(labels || []);
    return {
      add: current.has(phase) ? [] : [phase],
      remove: PHASE_LABELS.filter((label) => label !== phase && current.has(label)),
    };
  };
  const issueDelta = deltaFor(issue.labels);
  if (issueDelta.add.length || issueDelta.remove.length) await gh.setIssueLabels(issue.number, issueDelta);
  if (pr) {
    if (!Array.isArray(pr.labels)) throw new Error("PR labels must be provided");
    const prDelta = deltaFor(pr.labels);
    if (prDelta.add.length || prDelta.remove.length) await gh.setPrLabels(pr.number, prDelta);
  }
}

export async function mirrorLabels({ gh, issue, pr }) {
  if (!pr) return;
  const delta = planLabelMirror(issue.labels, pr.labels);
  if (delta.add.length === 0 && delta.remove.length === 0) return;
  await gh.setPrLabels(pr.number, delta);
}

function failingChecksComment(rollup) {
  const lines = failingChecks(rollup).map(
    (check) => `- \`${check.name}\`${check.url ? ` — ${check.url}` : ""}`,
  );
  return [
    "Automated review passed, but required checks failed.",
    "",
    ...lines,
    "",
    `Returned to draft and labelled \`${BLOCKED}\`. This workflow does not repair failures.`,
  ].join("\n");
}

function elapsedDuration(elapsedMs) {
  const hours = Math.floor(elapsedMs / (60 * 60 * 1000));
  if (hours >= 1) return `${hours} ${hours === 1 ? "hour" : "hours"}`;
  const minutes = Math.max(1, Math.floor(elapsedMs / (60 * 1000)));
  return `${minutes} ${minutes === 1 ? "minute" : "minutes"}`;
}

function stuckChecksComment(rollup, now) {
  const lines = stuckChecks(rollup, now).map(
    (check) => `- \`${check.name}\` — stuck for ${elapsedDuration(check.elapsedMs)}${check.url ? ` — ${check.url}` : ""}`,
  );
  return [
    "Automated review passed, but required checks appear stuck.",
    "",
    ...lines,
    "",
    `Returned to draft and labelled \`${BLOCKED}\` for owner attention.`,
  ].join("\n");
}

// Execute exactly one planned action. Returns the phase the issue now carries
// so the caller can decide whether the supervisor may exit.
export async function applyReviewPlan({ gh, issue, pr, plan, rollup, now = Date.now(), log = () => {} }) {
  switch (plan.action) {
    case "open":
      await gh.markPrReady(pr.number);
      log(`#${issue.number}: review clean — PR #${pr.number} marked ready; checks evaluated next poll`);
      return { phase: REVIEW };

    case "pass":
      await setPhase({ gh, issue, pr, phase: MERGE_REVIEW });
      log(`#${issue.number}: checks green — PR #${pr.number} awaiting owner review`);
      return { phase: MERGE_REVIEW };

    case "wait":
      log(`#${issue.number}: PR #${pr.number} checks pending — reviewer slot free`);
      return { phase: REVIEW };

    case "retry":
      log(`#${issue.number}: PR #${pr.number} check data unreadable — retrying next poll`);
      return { phase: REVIEW };

    case "block": {
      if (plan.reason === "unrecognised-verdict") {
        await gh.commentPr(
          pr.number,
          "The review marker for this PR's current content carries an unrecognised verdict, so this PR cannot be gated automatically. Blocking for owner attention.",
        );
      }
      if (pr.isDraft === false) await gh.markPrDraft(pr.number);
      await setPhase({ gh, issue, pr, phase: BLOCKED });
      log(`#${issue.number}: PR #${pr.number} blocked (${plan.reason})`);
      return { phase: BLOCKED };
    }

    case "fail-checks": {
      await gh.commentPr(pr.number, failingChecksComment(rollup));
      if (pr.isDraft === false) await gh.markPrDraft(pr.number);
      await setPhase({ gh, issue, pr, phase: BLOCKED });
      log(`#${issue.number}: PR #${pr.number} blocked on failing checks`);
      return { phase: BLOCKED };
    }

    case "stuck-checks": {
      await gh.commentPr(pr.number, stuckChecksComment(rollup, now));
      if (pr.isDraft === false) await gh.markPrDraft(pr.number);
      await setPhase({ gh, issue, pr, phase: BLOCKED });
      log(`#${issue.number}: PR #${pr.number} blocked on stuck checks`);
      return { phase: BLOCKED };
    }

    default:
      return { phase: phaseOf(issue.labels) };
  }
}

// Every linkage or lifecycle ambiguity ends here: an actionable comment plus
// `agent-blocked`. Already-blocked issues short-circuit so a persistent
// problem is reported once, not every poll.
export async function failClosed({ gh, issue, pr, message, log = () => {} }) {
  if (phaseOf(issue.labels) === BLOCKED) return;
  await gh.commentIssue(
    issue.number,
    `${message}\n\nissue-orchestrator cannot proceed automatically and has labelled this \`${BLOCKED}\`.`,
  );
  if (pr && pr.isDraft === false) await gh.markPrDraft(pr.number);
  await setPhase({ gh, issue, pr, phase: BLOCKED });
  log(`#${issue.number}: blocked — ${message}`);
}
