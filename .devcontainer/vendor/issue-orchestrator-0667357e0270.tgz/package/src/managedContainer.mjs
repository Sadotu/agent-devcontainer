import { readFile } from "node:fs/promises";

const DEFAULT_URL = "http://usage-sentinel:4317";
const DEFAULT_TIMEOUT_MS = 5000;
const CONTAINER_ID = /^[0-9a-f]{64}$/;
// Docker bind-mounts /etc/{resolv.conf,hostname,hosts} out of the container's
// own state directory, so mountinfo carries the full 64-hex ID that the lease
// API requires. `hostname` is only the 12-character short form, which Sentinel
// rejects, and cgroup v2 reports `0::/` with no ID at all.
const MOUNT_CONTAINER_ID = /\/containers\/([0-9a-f]{64})\//g;

export async function resolveContainerId({ readFileImpl = readFile } = {}) {
  const raw = await readFileImpl("/proc/self/mountinfo", "utf8");
  const ids = new Set(Array.from(String(raw).matchAll(MOUNT_CONTAINER_ID), (match) => match[1]));
  if (ids.size === 1) return [...ids][0];
  if (ids.size === 0) {
    throw new Error("cannot resolve the current Docker container ID from /proc/self/mountinfo");
  }
  throw new Error(`ambiguous Docker container IDs in /proc/self/mountinfo: ${[...ids].join(", ")}`);
}

const WINDOWS = new Set(["short", "long"]);

function isPercent(value) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 100;
}

function isReason(value) {
  return (
    typeof value === "object" && value !== null &&
    WINDOWS.has(value.window) &&
    isPercent(value.shortUsedPercent) &&
    isPercent(value.longUsedPercent) &&
    (value.resetsAt === null || typeof value.resetsAt === "string")
  );
}

// Sentinel documents an absent field as `running`, so only a *present* payload
// can be malformed. A malformed one throws: this client never invents a state,
// because a wrong guess would either hide an imminent pause or announce one
// that is not coming.
function parseEnforcement(value) {
  if (value === undefined || value === null) return { state: "running" };
  if (typeof value !== "object") {
    throw new Error("invalid managed-container enforcement: not an object");
  }
  if (value.state === "running") return { state: "running" };
  if (value.state !== "pause_pending" && value.state !== "paused") {
    throw new Error(`invalid managed-container enforcement: unknown state ${value.state}`);
  }
  if (!isReason(value.reason)) {
    throw new Error("invalid managed-container enforcement: invalid reason");
  }
  return value;
}

// Sentinel's `/managed-containers` API is a lease, not admission control: it
// never allows or denies a start, so neither operation here returns anything a
// caller could read as a decision. Any non-lease status is a local or transport
// fault to report, never a refusal to run.
export function createManagedContainerClient({
  url = DEFAULT_URL,
  fetchImpl = fetch,
  timeoutMs = DEFAULT_TIMEOUT_MS,
} = {}) {
  const baseUrl = url.replace(/\/$/, "");

  // One deadline for the whole exchange — headers *and* body. Sentinel can send
  // headers and then stall mid-body; awaiting that without a deadline would hang
  // the supervisor's poll loop. The timer is deliberately ref'd (unlike
  // `AbortSignal.timeout`, whose unref'd timer never fires when nothing else
  // keeps the loop alive) and is cleared only once the caller is done reading.
  function startDeadline() {
    const controller = new AbortController();
    const timer = setTimeout(
      () => controller.abort(new Error(`exceeded ${timeoutMs}ms`)),
      timeoutMs,
    );
    return { signal: controller.signal, done: () => clearTimeout(timer) };
  }

  // The race does not trust the awaited promise to honour the signal itself.
  function withDeadline(promise, signal) {
    if (signal.aborted) return Promise.reject(signal.reason);
    return Promise.race([
      promise,
      new Promise((_resolve, reject) => {
        signal.addEventListener("abort", () => reject(signal.reason), { once: true });
      }),
    ]);
  }

  function transportError(error, signal) {
    const detail = error instanceof Error ? error.message : String(error);
    const prefix = signal.aborted ? "sentinel request timed out" : "sentinel unreachable";
    return new Error(`${prefix}: ${detail}`);
  }

  async function request(containerId, method, suffix = "") {
    if (typeof containerId !== "string" || !CONTAINER_ID.test(containerId)) {
      throw new Error(`invalid container ID: ${containerId}`);
    }
    const { signal, done } = startDeadline();
    const path = `/managed-containers/${encodeURIComponent(containerId)}${suffix}`;
    let response;
    try {
      response = await withDeadline(fetchImpl(`${baseUrl}${path}`, { method, signal }), signal);
      if (!response || !Number.isInteger(response.status)) {
        throw new Error("sentinel returned no response");
      }
    } catch (error) {
      done();
      if (error.message === "sentinel returned no response") throw error;
      throw transportError(error, signal);
    }
    // The deadline stays armed for whatever the caller still reads off this
    // response; `done` disarms it.
    return { response, signal, done };
  }

  async function register(containerId) {
    const { response, signal, done } = await request(containerId, "PUT");
    try {
      // 201 creates the lease; a repeat PUT is its heartbeat and returns 200.
      const expected = { 201: "registered", 200: "refreshed" }[response.status];
      if (!expected) {
        throw new Error(`unexpected managed-container registration status ${response.status}`);
      }
      let body;
      try {
        body = await withDeadline(response.json(), signal);
      } catch (error) {
        if (signal.aborted) throw transportError(error, signal);
        const detail = error instanceof Error ? error.message : String(error);
        throw new Error(`invalid managed-container registration response: ${detail}`);
      }
      if (body?.status !== expected) {
        throw new Error(`invalid managed-container registration response: status ${body?.status}`);
      }
      return { status: expected, enforcement: parseEnforcement(body.enforcement) };
    } finally {
      done();
    }
  }

  // Tells Sentinel the pre-pause message has been printed, so it may pause this
  // container. `409 no pending pause` is not a failure: it only means Sentinel
  // already resolved the transition — its acknowledgment timeout fired, or usage
  // dropped back below the threshold.
  async function acknowledge(containerId) {
    const { response, done } = await request(containerId, "POST", "/acknowledge");
    done();
    if (response.status === 200) return { acknowledged: true };
    if (response.status === 409) return { acknowledged: false };
    throw new Error(`unexpected managed-container acknowledgment status ${response.status}`);
  }

  async function unregister(containerId) {
    const { response, done } = await request(containerId, "DELETE");
    done();
    if (response.status !== 204) {
      throw new Error(`unexpected managed-container deletion status ${response.status}`);
    }
  }

  return { register, unregister, acknowledge };
}
