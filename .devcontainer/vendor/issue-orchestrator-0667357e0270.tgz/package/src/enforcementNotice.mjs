// Sentinel's enforcement state is a lease field, not an admission decision.
// This module only decides what to say about a change in it, and whether the
// change still needs acknowledging; it reads no usage and gates nothing.
const WINDOW_NAMES = { short: "5-hour", long: "weekly" };

function pauseMessage(reason) {
  const window = WINDOW_NAMES[reason.window];
  const short = Math.round(reason.shortUsedPercent);
  const long = Math.round(reason.longUsedPercent);
  const resets = reason.resetsAt === null ? "" : ` Usage resets at ${reason.resetsAt}.`;
  return (
    `Sentinel usage threshold reached on the ${window} window ` +
    `(5-hour ${short}%, weekly ${long}%); pausing this container until usage ` +
    `becomes available.${resets}`
  );
}

export function describeEnforcementTransition(previousState, enforcement) {
  const state = enforcement.state;
  // Acknowledgment is independent of the message: a pause announced on one
  // heartbeat whose acknowledgment failed is retried on the next one without
  // printing a second line.
  const acknowledge = state === "pause_pending" && enforcement.acknowledged !== true;
  if (state === previousState) return { state, message: null, acknowledge };
  if (state === "running") {
    return { state, message: "Sentinel unpaused this container; issue-orchestrator resumed.", acknowledge };
  }
  if (previousState === "running") {
    // Announcing on any first departure from `running` covers a lease seen as
    // `paused` outright — a Sentinel restart, or a pause whose persist raced —
    // which would otherwise freeze the container in silence.
    return { state, message: pauseMessage(enforcement.reason), acknowledge };
  }
  // pause_pending → paused: the same pause, already announced.
  return { state, message: null, acknowledge };
}
