import { BLOCKED, PHASE_LABELS, REVIEW, RUNNING } from "./labels.mjs";
import { selectApplicableMarker } from "./reviewMarker.mjs";
import {
  selectLatestTrustedReview, selectLatestTrustedReviewContext,
  selectRepairHistory, selectRepairReservation,
} from "./repairMarker.mjs";

export function exactPhase(labels, phase) {
  const set = new Set(labels || []);
  return set.has(RUNNING) && set.has(phase)
    && PHASE_LABELS.filter((label) => set.has(label)).length === 1;
}

export function planRepair({ issue, pr, comments, phase, liveRepair, maxAttempts }) {
  if (![BLOCKED, REVIEW].includes(phase)) return { action: "skip" };
  if (!liveRepair && exactPhase(issue.labels, REVIEW) && exactPhase(pr.labels, REVIEW)) return { action: "skip" };

  const identity = { issue: issue.number, pr: pr.number };
  const history = selectRepairHistory(comments, identity);
  const latestReview = selectLatestTrustedReview(comments, identity);
  const latestContext = selectLatestTrustedReviewContext(comments, identity);
  if (!history.valid) return { action: "invalid-history", history, latestReview };
  const reservation = latestReview?.verdict === "BLOCKING"
    ? selectRepairReservation(comments, identity, latestReview.fingerprint)
    : null;
  if (reservation) {
    if (liveRepair) return { action: "live", reservation };
    if (reservation.head !== pr.headRefOid) {
      return { action: "review", reason: "reserved-head-changed", reservation };
    }
    return { action: "failed", reservation };
  }
  if (phase !== BLOCKED || !exactPhase(issue.labels, BLOCKED) || !exactPhase(pr.labels, BLOCKED)) {
    return { action: "skip" };
  }
  const marker = selectApplicableMarker(comments, {
    ...identity, head: pr.headRefOid, base: pr.baseRefOid,
    issueBody: issue.body, prBody: pr.body,
  });
  const applicable = marker && latestReview
    && marker.fingerprint === latestReview.fingerprint && marker.pass === latestReview.pass;
  if (!applicable || marker.verdict !== "BLOCKING") {
    return latestReview?.verdict === "BLOCKING"
      ? { action: "review", reason: "stale-review-snapshot" }
      : { action: "skip" };
  }
  if (!pr.isDraft) return { action: "skip" };
  if (history.attempts.length >= maxAttempts) {
    return { action: "budget", marker, history };
  }
  return {
    action: "eligible", marker, history,
    attempt: history.attempts.length + 1,
    sourceFingerprint: marker.fingerprint,
    blockingCreatedAt: latestContext?.createdAt,
  };
}
