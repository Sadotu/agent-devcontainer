import { parseReviewMarkers } from "./reviewMarker.mjs";

export const REPAIR_MARKER_TAG = "issue-orchestrator:repair-attempt v1";

const ATTEMPT_PATTERN = /^<!-- issue-orchestrator:repair-attempt v1 (\{.*\}) -->$/m;
const ATTEMPT_FIELDS = ["issue", "pr", "attempt", "sourceFingerprint", "head", "log"];
const FAILURE_FIELDS = ["issue", "pr", "attempt", "sourceFingerprint"];
const BUDGET_FIELDS = ["issue", "pr", "sourceFingerprint"];
const INVALID_HISTORY_FIELDS = ["issue", "pr", "sourceFingerprint"];
const FAILURE_PATTERN = /^<!-- issue-orchestrator:repair-failure v1 (\{.*\}) -->$/m;
const BUDGET_PATTERN = /^<!-- issue-orchestrator:repair-budget-exhausted v1 (\{.*\}) -->$/m;
const INVALID_HISTORY_PATTERN = /^<!-- issue-orchestrator:repair-history-invalid v1 (\{.*\}) -->$/m;

function positiveInteger(value) {
  return Number.isInteger(value) && value > 0;
}

function validIdentity(value) {
  return value && positiveInteger(value.issue) && positiveInteger(value.pr);
}

const fingerprint = (value) => typeof value === "string" && /^[0-9a-f]{64}$/.test(value);
const commit = (value) => typeof value === "string" && /^[0-9a-f]{40}$/.test(value);

function exactPayload(value, fields) {
  return value && typeof value === "object" && !Array.isArray(value)
    && Object.keys(value).length === fields.length
    && fields.every((field) => Object.hasOwn(value, field));
}

function attemptPayload(value) {
  if (!exactPayload(value, ATTEMPT_FIELDS)) return null;
  if (!positiveInteger(value.issue) || !positiveInteger(value.pr) || !positiveInteger(value.attempt)) return null;
  if (!fingerprint(value.sourceFingerprint) || !commit(value.head)) return null;
  if (value.log !== null && (typeof value.log !== "string" || value.log.length === 0)) return null;
  return Object.fromEntries(ATTEMPT_FIELDS.map((field) => [field, value[field]]));
}

export function parseRepairAttempt(body) {
  const match = ATTEMPT_PATTERN.exec(String(body ?? ""));
  if (!match) return null;
  try {
    return attemptPayload(JSON.parse(match[1]));
  } catch {
    return null;
  }
}

function trustedAttempt(comment, identity) {
  if (comment?.viewerDidAuthor !== true) return null;
  const marker = parseRepairAttempt(comment.body);
  if (!marker || marker.issue !== identity.issue || marker.pr !== identity.pr) return null;
  return marker;
}

export function selectRepairReservation(comments, identity, sourceFingerprint) {
  if (!validIdentity(identity) || typeof sourceFingerprint !== "string" || sourceFingerprint.length === 0) return null;
  let found = null;
  for (const comment of comments || []) {
    const marker = trustedAttempt(comment, identity);
    if (marker?.sourceFingerprint === sourceFingerprint) found = marker;
  }
  return found;
}

function trustedReviews(comment, identity) {
  if (comment?.viewerDidAuthor !== true) return [];
  return parseReviewMarkers(comment.body).filter((marker) => (
    marker.issue === identity.issue && marker.pr === identity.pr
  ));
}

export function selectLatestTrustedReview(comments, identity) {
  if (!validIdentity(identity)) return null;
  let found = null;
  for (const comment of comments || []) {
    for (const marker of trustedReviews(comment, identity)) found = marker;
  }
  return found;
}

export function selectLatestTrustedReviewContext(comments, identity) {
  if (!validIdentity(identity)) return null;
  let found = null;
  for (const comment of comments || []) {
    for (const marker of trustedReviews(comment, identity)) {
      found = { marker, createdAt: comment.createdAt, url: comment.url };
    }
  }
  return found;
}

export function selectRepairHistory(comments, identity) {
  if (!validIdentity(identity)) return { valid: false, attempts: [], blockingPasses: [] };
  const all = Array.from(comments || []);
  let start = 0;
  for (let index = 0; index < all.length; index += 1) {
    if (trustedReviews(all[index], identity).some(({ verdict }) => verdict === "PASS")) start = index + 1;
  }

  const attempts = [];
  const blockingPasses = [];
  const blockingSources = new Set();
  const attemptedSources = new Set();
  let valid = true;
  for (const comment of all.slice(start)) {
    for (const marker of trustedReviews(comment, identity)) {
      if (marker.verdict === "BLOCKING") {
        blockingPasses.push({ fingerprint: marker.fingerprint, pass: marker.pass, url: comment.url });
        blockingSources.add(`${marker.fingerprint}\0${marker.head}`);
      }
    }
    const marker = trustedAttempt(comment, identity);
    if (!marker) continue;
    if (!blockingSources.has(`${marker.sourceFingerprint}\0${marker.head}`)) continue;
    if (attemptedSources.has(marker.sourceFingerprint)) {
      valid = false;
      continue;
    }
    if (marker.attempt !== attempts.length + 1) {
      valid = false;
      continue;
    }
    attempts.push(marker);
    attemptedSources.add(marker.sourceFingerprint);
  }
  return { valid, attempts, blockingPasses };
}

function hasTrustedMarker(comments, identity, pattern, fields, validPayload, matches) {
  for (const comment of comments || []) {
    if (comment?.viewerDidAuthor !== true) continue;
    const match = pattern.exec(String(comment.body ?? ""));
    if (!match) continue;
    try {
      const marker = JSON.parse(match[1]);
      if (exactPayload(marker, fields) && validPayload(marker)
        && marker.issue === identity.issue && marker.pr === identity.pr
        && matches(marker)) return true;
    } catch {
      // Malformed comments are untrusted state, never durable evidence.
    }
  }
  return false;
}

export function hasRepairFailure(comments, identity, attempt, sourceFingerprint) {
  if (!validIdentity(identity) || !positiveInteger(attempt) || !fingerprint(sourceFingerprint)) return false;
  return hasTrustedMarker(
    comments, identity, FAILURE_PATTERN, FAILURE_FIELDS,
    (marker) => positiveInteger(marker.issue) && positiveInteger(marker.pr)
      && positiveInteger(marker.attempt) && fingerprint(marker.sourceFingerprint),
    (marker) => marker.attempt === attempt && marker.sourceFingerprint === sourceFingerprint,
  );
}

export function hasRepairBudgetComment(comments, identity, sourceFingerprint) {
  if (!validIdentity(identity) || !fingerprint(sourceFingerprint)) return false;
  return hasTrustedMarker(
    comments, identity, BUDGET_PATTERN, BUDGET_FIELDS,
    (marker) => positiveInteger(marker.issue) && positiveInteger(marker.pr)
      && fingerprint(marker.sourceFingerprint),
    (marker) => marker.sourceFingerprint === sourceFingerprint,
  );
}

export function hasInvalidRepairHistoryComment(comments, identity, sourceFingerprint) {
  if (!validIdentity(identity) || !fingerprint(sourceFingerprint)) return false;
  return hasTrustedMarker(
    comments, identity, INVALID_HISTORY_PATTERN, INVALID_HISTORY_FIELDS,
    (marker) => positiveInteger(marker.issue) && positiveInteger(marker.pr)
      && fingerprint(marker.sourceFingerprint),
    (marker) => marker.sourceFingerprint === sourceFingerprint,
  );
}

function requireCommentInput(input, { attempt = false } = {}) {
  if (!validIdentity(input)) throw new TypeError("issue and pr must be positive integers");
  if (!fingerprint(input.sourceFingerprint)) {
    throw new TypeError("sourceFingerprint must be 64 lowercase hex characters");
  }
  if (attempt && !positiveInteger(input.attempt)) throw new TypeError("attempt must be a positive integer");
}

function hidden(tag, payload) {
  return `<!-- ${tag} ${JSON.stringify(payload)} -->`;
}

export function formatRepairAttemptComment(input) {
  requireCommentInput(input, { attempt: true });
  if (!commit(input.head)) throw new TypeError("head must be 40 hex characters");
  if (input.log !== undefined && input.log !== null
    && (typeof input.log !== "string" || input.log.length === 0)) {
    throw new TypeError("log must be a nonempty string or null");
  }
  if (!positiveInteger(input.maxAttempts)) throw new TypeError("maxAttempts must be a positive integer");
  const marker = {
    issue: input.issue, pr: input.pr, attempt: input.attempt,
    sourceFingerprint: input.sourceFingerprint, head: input.head,
    log: input.log ?? null,
  };
  return [
    `Automatic repair attempt ${input.attempt} of ${input.maxAttempts} reserved for review source \`${input.sourceFingerprint}\`.`,
    "",
    hidden(REPAIR_MARKER_TAG, marker),
  ].join("\n");
}

export function formatRepairFailureComment(input) {
  requireCommentInput(input, { attempt: true });
  const details = [];
  if (input.exitCode !== undefined) details.push(`Exit code ${input.exitCode}.`);
  if (typeof input.logUrl === "string" && input.logUrl.length > 0) details.push(`Logs: ${input.logUrl}`);
  else details.push("Log location unavailable.");
  return [
    `Automatic repair attempt ${input.attempt} failed for review source \`${input.sourceFingerprint}\`.`,
    ...details,
    "",
    hidden("issue-orchestrator:repair-failure v1", {
      issue: input.issue, pr: input.pr, attempt: input.attempt, sourceFingerprint: input.sourceFingerprint,
    }),
  ].join("\n");
}

export function formatRepairBudgetComment(input) {
  requireCommentInput(input);
  if (!positiveInteger(input.maxAttempts)) throw new TypeError("maxAttempts must be a positive integer");
  const urls = Array.from(input.blockingReviewUrls || []).filter((url) => typeof url === "string" && url.length > 0);
  return [
    `${input.maxAttempts} automatic repair attempts have been exhausted for review source \`${input.sourceFingerprint}\`.`,
    ...(urls.length > 0 ? ["", "Blocking review passes:", ...urls.map((url) => `- ${url}`)] : []),
    "",
    hidden("issue-orchestrator:repair-budget-exhausted v1", {
      issue: input.issue, pr: input.pr, sourceFingerprint: input.sourceFingerprint,
    }),
  ].join("\n");
}

export function formatInvalidRepairHistoryComment(input) {
  requireCommentInput(input);
  return [
    `Invalid automatic repair history detected for review source \`${input.sourceFingerprint}\`. Manual intervention is required.`,
    "",
    hidden("issue-orchestrator:repair-history-invalid v1", {
      issue: input.issue, pr: input.pr, sourceFingerprint: input.sourceFingerprint,
    }),
  ].join("\n");
}
