// Label vocabulary for the managed workflow. `agent-running` is the durable
// ownership marker; exactly one phase label is active alongside it.
export const READY = "agent-ready";
export const RUNNING = "agent-running";
export const REVIEW = "agent-review";
export const BLOCKED = "agent-blocked";
export const MERGE_REVIEW = "user-merge-review";

// Declaration order is also precedence order for `phaseOf`: a repository that
// somehow carries two phase labels resolves to the earliest one, so the
// supervisor keeps reconciling rather than oscillating.
export const PHASE_LABELS = [REVIEW, BLOCKED, MERGE_REVIEW];
export const MANAGED_LABELS = [READY, RUNNING, ...PHASE_LABELS];

export const REQUIRED_LABELS = [
  { name: READY, color: "0e8a16", description: "Ready for issue-orchestrator claim" },
  { name: RUNNING, color: "1d76db", description: "Managed by issue-orchestrator" },
  { name: REVIEW, color: "5319e7", description: "Waiting for or undergoing automated review" },
  { name: BLOCKED, color: "d73a4a", description: "Automated workflow blocked; findings posted" },
  { name: MERGE_REVIEW, color: "fbca04", description: "Automated review passed; waiting for owner review and merge" },
];

export function phaseOf(labelNames) {
  const present = new Set((labelNames || []).map((name) => String(name)));
  return PHASE_LABELS.find((label) => present.has(label)) || null;
}

function alreadyExists(message) {
  return /already exists/i.test(message);
}

// Idempotent bootstrap: list once, create only what is missing, never modify
// an existing label. A permission/authentication failure rejects, which is
// fatal at startup; whatever was created before the failure is kept, so the
// next startup retries only the remainder.
export async function ensureLabels({ listLabels, createLabel, log = () => {} }) {
  let existingLabels;
  try {
    existingLabels = await listLabels();
  } catch (err) {
    throw new Error(`label bootstrap failed: ${err.message}`);
  }
  // GitHub label names are case-insensitive for uniqueness, so a repository
  // that already has `Agent-Ready` must not get a second `agent-ready`.
  const byName = new Map(
    (existingLabels || []).map((label) => [String(label.name).toLowerCase(), label.name]),
  );

  const created = [];
  const existing = [];
  for (const label of REQUIRED_LABELS) {
    const match = byName.get(label.name.toLowerCase());
    if (match !== undefined) {
      existing.push(match);
      continue;
    }
    try {
      await createLabel(label);
    } catch (err) {
      if (!alreadyExists(err.message)) {
        throw new Error(`label bootstrap failed: ${err.message}`);
      }
    }
    created.push(label.name);
  }
  if (created.length > 0) log(`Created missing labels: ${created.join(", ")}`);
  return { created, existing };
}
