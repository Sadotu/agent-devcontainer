import { createHash } from "node:crypto";

// The contract between the reviewer skill (Sadotu/agent-skills#22) and this
// supervisor. This repo is purely a consumer: the shipped
// `review-pr/scripts/publish-review.sh` is canonical and nothing here ever
// produces a marker.
//
// The producer emits exactly one line per pass:
//   <!-- review-pr:v1 {"fingerprint":…,"head":…,…,"verdict":"PASS"} -->
export const MARKER_TAG = "review-pr:v1";

const MARKER = /^<!-- review-pr:v1 (\{.*\}) -->$/gm;
const TEXT_FIELDS = ["fingerprint", "head", "base", "issueUpdatedAt", "prUpdatedAt"];
const NUMBER_FIELDS = ["issue", "pr", "pass"];
const SEPARATOR = "\x1e";

// The producer captures bodies as `body="$(… | jq -r .body)"`; command
// substitution strips trailing newlines before they reach sha256. Replicate
// that and nothing else — any further normalisation (trimming, CRLF folding)
// yields a different digest and would reject every real marker.
function hashedBody(text) {
  return String(text ?? "").replace(/\n+$/, "");
}

// sha256 of head, base, issue body and PR body joined by the ASCII record
// separator, byte-identical to the producer's `compute_fingerprint`. Bodies —
// not updatedAt — decide freshness, so a label edit or a new comment cannot
// stale a review, while a real content change always does.
export function computeFingerprint({ head, base, issueBody, prBody }) {
  const parts = [String(head ?? ""), String(base ?? ""), hashedBody(issueBody), hashedBody(prBody)];
  return createHash("sha256").update(parts.join(SEPARATOR), "utf8").digest("hex");
}

// Fail closed: an unsupported tag, malformed JSON, or a missing/ill-typed
// field yields no marker at all, so it can never become an applicable review.
// An unrecognised *verdict* is deliberately kept — the caller blocks on it
// rather than relaunching a reviewer forever on input that will never parse.
export function parseReviewMarkers(body) {
  const markers = [];
  // A web-UI edit can rewrite the comment with CRLF endings; strip CR first so
  // the line-anchored match still sees the producer's exact line.
  const text = String(body || "").replaceAll("\r", "");
  for (const [, payload] of text.matchAll(MARKER)) {
    let parsed;
    try {
      parsed = JSON.parse(payload);
    } catch {
      continue;
    }
    if (!parsed || typeof parsed !== "object") continue;
    if (!TEXT_FIELDS.every((f) => typeof parsed[f] === "string" && parsed[f].length > 0)) continue;
    if (!NUMBER_FIELDS.every((f) => Number.isInteger(parsed[f]))) continue;
    if (typeof parsed.verdict !== "string") continue;
    markers.push({
      ...Object.fromEntries(TEXT_FIELDS.map((f) => [f, parsed[f]])),
      ...Object.fromEntries(NUMBER_FIELDS.map((f) => [f, parsed[f]])),
      verdict: parsed.verdict,
    });
  }
  return markers;
}

// A marker counts only if the reviewing App identity authored it
// (`viewerDidAuthor`), it names this exact issue/PR pair, and the state it
// says it reviewed still equals live state. Every fingerprint input is public,
// so without the author check any commenter could forge a PASS. Comparing
// against live state needs no persistence, so a marker survives a supervisor
// restart or a crash between the reviewer's comment and the label transition.
export function selectApplicableMarker(comments, live) {
  const want = computeFingerprint(live);
  let found = null;
  for (const comment of comments || []) {
    if (comment?.viewerDidAuthor !== true) continue;
    for (const marker of parseReviewMarkers(comment.body)) {
      if (marker.issue !== live.issue || marker.pr !== live.pr) continue;
      if (marker.fingerprint === want) found = marker;
    }
  }
  return found;
}
