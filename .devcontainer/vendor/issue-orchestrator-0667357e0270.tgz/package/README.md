# issue-orchestrator

A small, supervised issue queue. A single Node supervisor picks up open issues
labeled `agent-ready` (ascending) and keeps at most **two** autonomous
subscription-authenticated `ccode` implementation workers alive — each in its own
tmux window running:

```bash
ccode --print --permission-mode auto --model claude-opus-5 "/github-issue <number>"
```

The full model name pins implementation workers to Opus 5 rather than the
Claude Code default or the moving `opus` alias. Non-interactive print mode
skips the workspace-trust prompt, and each process exits — closing its tmux
window — once its command finishes.

Usage limits are enforced by
[Usage Sentinel](https://github.com/Sadotu/usage-sentinel), which pauses this
orchestrator's entire Docker container — supervisor and workers together — rather
than this repository stopping workers itself.

A finished implementation PR is marked ready for the repository owner. The
supervisor does not review, repair, approve, or merge it automatically.

## Orchestrator

Zero-dependency Node ≥20.8.0 on Linux (the supervisor guard uses a Linux abstract
Unix socket). No build step.

### Installed/current-repository usage

The package is published publicly on
[npmjs](https://www.npmjs.com/package/@nickysagan/issue-orchestrator), so no
registry configuration or token is needed:

```bash
npm install -g @nickysagan/issue-orchestrator@latest
```

The scope names the package; the installed command is `issue-orchestrator`.

Run it from the target project repository, not from the package checkout:

```bash
cd /path/to/target-project
issue-orchestrator
```

The shared [`agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
also exposes that command through the literal alias `start work`.

The supervisor resolves the `origin` of that working directory, checks GitHub App
authentication, registers its own container with Sentinel, and starts the
autonomous workers itself. Do not start Claude separately. A supervisor that
cannot resolve its container ID or register its lease exits nonzero rather than
run unenforced.

Only one supervisor per repository per Linux network namespace may run at a
time; a second invocation for the same resolved `owner/repo` exits nonzero with
`already running` before authentication, the lease, tmux, or worker startup.
Ownership is a kernel-owned Linux abstract Unix socket, released on normal exit
and automatically when the process dies. Devcontainers normally have distinct
network namespaces and therefore independent guards; containers sharing a
namespace share this guard.

Neither the image build nor devcontainer startup launches the supervisor or an
LLM. Work begins only when a user runs `issue-orchestrator` or `start work`.

### Repository-checkout usage

```bash
npm test                 # node --test over test/
node bin/supervisor.mjs  # start the supervisor loop
tmux attach -t orchestrator   # watch the workers directly
```

### How it works

- **Admission** — before anything is claimed, the primary worktree is checked
  with a read-only `git status --porcelain`. If it has pending changes — or if
  that check cannot be read — no issue is claimed and no worker starts for that
  poll; nothing is stashed, reset, cleaned, or committed. Live workers keep
  running and are reconciled as usual.
- **Claim** — the lowest-numbered `agent-ready` issue has its label swapped
  `agent-ready` → `agent-running`, then a tmux window `issue-<n>` opens.
- **Complete** — Phase 6 marks the implementation PR ready for the owner. The
  next poll closes any remaining worker window, removes `agent-running` from
  the issue, and frees the slot.
- **Vanished** — if a worker disappears while its PR is still draft or absent,
  the claim is released and the draft/worktree is preserved. It is not
  restarted automatically.
- **Worker logs** — every implementation launch writes combined output to
  `<git-common-dir>/issue-orchestrator/logs/issue-<n>.<attempt>.log`, keeping
  the latest three attempts and scrubbing secrets from surfaced tails.
- **Usage enforcement** — Usage Sentinel owns pause/unpause thresholds. This
  repository reads no usage telemetry and never kills a worker for usage.
- **Pause notices** — the managed-container heartbeat carries Sentinel's
  enforcement state. A pending pause prints one flushed line naming the
  triggering window, both observed percentages and the reset time, and is then
  acknowledged so Sentinel may pause; the first heartbeat back to `running`
  prints one resume line. Ordinary refreshes stay quiet, and a payload that is
  present but malformed is reported rather than guessed at.
- **Stop** — the supervisor exits when nothing is queued and no implementation
  window and no legacy window (below) is live.

Live container pause/unpause check:
[docs/smoke-checks/README.md](docs/smoke-checks/README.md).

## Implementation-only handoff

`agent-running` remains the active ownership marker: it is applied when an
issue is claimed and removed only after the implementation PR is ready for the
owner, or when a vanished/failed launch is safely released. Existing review
labels are left untouched in repositories, but the supervisor does not create a
reviewer or repair worker and does not transition issues through them.

Manual and managed `/github-issue` runs both finish by marking the PR ready.
Human review and merge begin there. The supervisor exposes no approve or merge
operation.

Legacy `review-<n>` and `repair-<n>` windows are allowed to finish without being
restarted or killed; both keep the supervisor active, and repairs consume an implementation slot.

## GitHub authentication

`gh` does not auto-consume the GitHub App credential, so the supervisor mints a
short-lived installation token (via `gh-app-token.sh`, overridable with
`GH_APP_TOKEN_SCRIPT`) and injects it as `GH_TOKEN` for every `gh` call,
re-minting each poll. At startup an authenticated `gh repo view` smoke check
exits with a clear message if the App is not authenticated, rather than churning
on unauthenticated calls every poll.

### Configuration

The local concurrency guard is fixed at two implementation slots. Two knobs
are environment-tunable:

| Var | Default | Meaning |
|-----|---------|---------|
| `SENTINEL_URL` | `http://usage-sentinel:4317` | Usage Sentinel base URL for the managed-container lease, on the shared container network; set this explicitly (for example, `http://host.docker.internal:4317`) only when Sentinel is exposed on the host |
| `POLL_MS` | `60000` | Poll interval |

Labels are created at startup — see the managed review gate above.

## Repo contents

| Path | Purpose |
|------|---------|
| `agents.toml` / `agents.lock` | [dotagents](https://github.com/Sadotu/agent-skills) manifest — declares which skills are installed and pins their source commits |
| `.agents/skills/` | Installed skills (`address-review`, `github-issue`, `github-pr-cleanup`, `review-pr`, `setup`) — managed artifacts, restored from the manifest, not committed |
| `.claude/skills` | Symlink to `.agents/skills` so Claude Code picks the skills up |
| `CLAUDE.md` | Agent instructions and gotchas for working in this repo |

## Skills

- **`github-issue`** — runs an issue end to end, opens a draft PR, implements
  in an isolated worktree, verifies the result, and marks the PR ready for the
  owner.
- **`setup`** — connects the repo to the `container-coding-agent` GitHub App
  and verifies `git`/`gh` authenticate as the App.
- **`github-pr-cleanup`** — cleans the worktree, branch and session artifacts of
  one merged or closed pull request. Worktree Warden is the automatic caller: it
  watches for terminal pull requests and runs the skill's cleanup script, so
  cleanup happens outside this repository's supervisor, which ends at "PR ready
  for the owner". The skill is installed here so that script exists in a
  checkout, and so it can also be run by hand for a single pull request.

The standalone `review-pr` and `address-review` skills remain installed for
manual use, but the production supervisor route does not invoke them.

## Releasing

`package.json` holds the version, and merging the bump is the whole release. Bump
it in a normal pull request; when that lands on `main`,
`.github/workflows/publish.yml` sees a version the registry does not carry, runs
the tests, publishes, and pushes the matching `v<version>` tag. A merge without a
bump finds its version already published and exits without releasing. Pushing a
`v*` tag by hand takes the same path, with one extra guard: the tag must equal
`v<version>` or the run fails. A published version cannot be republished; bump
and merge again.

Publishing goes to npmjs via
[trusted publishing](https://docs.npmjs.com/trusted-publishers), so no npm token
is stored anywhere — npm exchanges the workflow's OIDC identity for a short-lived
credential. Tagging is a separate job, so the job holding an npm credential
cannot write to this repository and the job that can push a tag holds no npm
credential.

Two one-time bootstraps, both because they need a package that already exists:
`0.1.0` was published by hand (`npm login && npm publish`) to enable trusted
publishing, and package visibility — set on the package, not inherited from this
private repository — must be set once after the first release under **Sadotu →
Packages → issue-orchestrator → Package settings**.

## Development environment

Agents work on this repo from a shared, sandboxed devcontainer. That
environment is **not part of this app** — it lives in its own repo:
[`Sadotu/agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
(image, setup scripts, security model, auth docs). A local `.devcontainer/`
folder pointing at that image may exist in a checkout but is gitignored.

GitHub access is via the scoped `container-coding-agent` GitHub App — never a
personal token, never `gh auth login`. See `CLAUDE.md` for the auth wiring.
