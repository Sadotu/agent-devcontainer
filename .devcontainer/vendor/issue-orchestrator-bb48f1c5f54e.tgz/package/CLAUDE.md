# issue-orchestrator

## Gotchas

### GitHub auth (App-based — never `gh auth login`)

Auth is via the GitHub App, never a user PAT and never `gh auth login` /
`gh auth setup-git` (which would install `gh auth git-credential` as the git
credential helper and **shadow the App helper**). How it resolves depends on
**where you run** — the two contexts differ and the difference matters:

**Inside the devcontainer** (the agents' normal environment):
- `setup-agents.sh` sets a global `credential."https://github.com"` helper
  pointing at `/opt/agent-devcontainer/git-credential-github-app.sh`, which is
  baked into the image. So `git` fetch/push/PR — including from worktrees —
  authenticate transparently; no per-call token needed.
- Helper scripts live at `/opt/agent-devcontainer/` (`gh-app-token.sh`,
  `git-credential-github-app.sh`). App credentials in `~/.config/github-app/`
  (`app-id`, `private-key.pem`, cached token). `gh-app-token.sh` RS256-signs an
  App JWT, exchanges it for a ~1h installation token, and caches it (reused
  while >5 min life, re-minted when stale).
- `gh` does **not** auto-consume the App token — inject it per call:
  `GH_TOKEN="$(GITHUB_APP_REPO=Sadotu/issue-orchestrator /opt/agent-devcontainer/gh-app-token.sh)" gh <cmd>`

**On the host (WSL, outside the container):**
- `/opt/agent-devcontainer/` does **not** exist on the host. The global
  `~/.gitconfig` helper is `gh`'s (`!/usr/bin/gh auth git-credential`) and its
  token is invalid — `gh auth status` fails. `git` is therefore **not**
  transparently authenticated here.
- This repo's local `.git/config` wires a `credential."https://github.com"`
  helper at `/opt/agent-devcontainer/git-credential-github-app.sh` — the
  **in-container** path. On the host that file is missing, so `git`
  fetch/push/ls-remote fail with `could not read Username`. (Fix: point the
  local helper at the checked-out `../agent-devcontainer/.devcontainer/`
  script, or run git inside the container.)
- The working helper scripts on the host live in the checked-out repo at
  `../agent-devcontainer/.devcontainer/`. For `gh`, mint per call — the only
  path proven to work on the host:
  `GH_TOKEN="$(GITHUB_APP_REPO=Sadotu/issue-orchestrator ../agent-devcontainer/.devcontainer/gh-app-token.sh)" gh <cmd>`
- For a host `git push`/`fetch` before the helper is fixed, inline a token:
  `git push https://x-access-token:"$(GITHUB_APP_REPO=Sadotu/issue-orchestrator ../agent-devcontainer/.devcontainer/gh-app-token.sh)"@github.com/Sadotu/issue-orchestrator <branch>`

### Repo layout
- `.devcontainer/` and `usage-sentinel/` are gitignored. `usage-sentinel/` is a
  full checkout of the separate repo `Sadotu/usage-sentinel` — never commit it
  here.
- `.claude/skills` is a symlink to `.agents/skills`; skill contents are
  dotagents-managed artifacts excluded by `.agents/.gitignore` and restored from
  `agents.toml`/`agents.lock`.
