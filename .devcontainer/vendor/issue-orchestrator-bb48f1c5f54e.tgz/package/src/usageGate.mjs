const DEFAULT_URL = "http://usage-sentinel:4317";
const DEFAULT_TIMEOUT_MS = 5000;

function denied(reason) {
  return { allowed: false, reason };
}

export function createSentinelClient({
  fetchImpl = fetch,
  url = DEFAULT_URL,
  timeoutMs = DEFAULT_TIMEOUT_MS,
} = {}) {
  const baseUrl = url.replace(/\/$/, "");

  async function request(path, options, { parseJson = true } = {}) {
    const controller = new AbortController();
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        reject(new Error(`request exceeded ${timeoutMs}ms`));
      }, timeoutMs);
    });

    try {
      const operation = (async () => {
        const response = await fetchImpl(`${baseUrl}${path}`, {
          ...options,
          signal: controller.signal,
        });
        if (!response || !Number.isInteger(response.status)) {
          return { error: "sentinel returned no response" };
        }
        if (!parseJson) return { response };

        try {
          return { response, body: await response.json() };
        } catch (error) {
          const detail = error instanceof Error ? error.message : String(error);
          return { error: `sentinel returned malformed JSON: ${detail}` };
        }
      })();
      const response = await Promise.race([
        operation,
        timeout,
      ]);
      return response;
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      const prefix = controller.signal.aborted ? "sentinel request timed out" : "sentinel unreachable";
      return { error: `${prefix}: ${detail}` };
    } finally {
      clearTimeout(timer);
    }
  }

  async function checkAdmission() {
    const result = await request("/admission/claude-code", { method: "GET" });
    if (result.error) return denied(result.error);
    if (result.response.status !== 200) {
      return denied(`sentinel returned unexpected admission status ${result.response.status}`);
    }

    if (result.body?.allowed !== true || result.body?.reason !== "admitted") {
      return denied("sentinel returned an invalid admission decision");
    }
    return { allowed: true, reason: "admitted" };
  }

  async function registerWorker(owner) {
    const result = await request("/workers", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ provider: "claude-code", owner }),
    });
    if (result.error) return denied(result.error);

    const { status } = result.response;
    const { allowed, reason } = result.body ?? {};
    if (status === 201 && allowed === true && reason === "registered") {
      return { allowed, reason };
    }
    if (status === 200 && allowed === true && reason === "refreshed") {
      return { allowed, reason };
    }

    const denialStatuses = {
      409: "capacity_reached",
      429: "threshold_reached",
      503: "telemetry_unavailable",
    };
    if (allowed === false && reason === denialStatuses[status]) {
      return { allowed, reason };
    }
    return denied(`sentinel returned an invalid worker registration (${status})`);
  }

  async function unregisterWorker(owner) {
    const result = await request(
      "/workers",
      {
        method: "DELETE",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ provider: "claude-code", owner }),
      },
      { parseJson: false },
    );
    if (result.error) return denied(result.error);
    if (result.response.status !== 204) {
      return denied(`sentinel returned unexpected worker deletion status ${result.response.status}`);
    }
    return { allowed: true, reason: "unregistered" };
  }

  return { checkAdmission, registerWorker, unregisterWorker };
}
