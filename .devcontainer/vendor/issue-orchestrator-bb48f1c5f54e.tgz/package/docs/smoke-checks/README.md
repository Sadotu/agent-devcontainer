# Smoke-check records

Copy the template into a new `YYYY-MM-DD-<short-revision>.md` file after each
manual run and commit it. Include failed or partial runs as `FAIL`, preserve the
failed step's output, and redact credentials and tokens.

## Record template

````markdown
# Manual two-devcontainer smoke check

- Date (UTC):
- Issue Orchestrator revision:
- Usage Sentinel revision/image:
- Environment (host, Docker, devcontainers, network):
- Result: PASS | FAIL

## Commands and responses

### Step 1

```text
Command:
Response:
```

Repeat for every operational step in the root README, including cleanup.
````
