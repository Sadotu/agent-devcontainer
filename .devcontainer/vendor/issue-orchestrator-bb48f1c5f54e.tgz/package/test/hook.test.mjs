import { test } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { runAdmissionHook } from "../hooks/pretooluse-usage-gate.mjs";
import { createConfiguredSentinel } from "../bin/supervisor.mjs";

async function startSentinel(handler) {
  const requests = [];
  const server = createServer((req, res) => {
    requests.push({ method: req.method, url: req.url });
    handler(req, res);
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const { port } = server.address();
  return {
    requests,
    url: `http://127.0.0.1:${port}`,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

function runHook(input, env = {}) {
  return new Promise((resolve) => {
    const child = spawn("node", ["hooks/pretooluse-usage-gate.mjs"], {
      env: { ...process.env, ...env },
    });
    let stderr = "";
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("close", (code) => resolve({ code, stderr }));
    child.stdin.end(JSON.stringify(input));
  });
}

test("hook without SENTINEL_URL sends GET to shared-network admission", async () => {
  const calls = [];
  const result = await runAdmissionHook({ tool_name: "Agent" }, {
    env: {},
    fetchImpl: async (...args) => {
      calls.push(args);
      return new Response(JSON.stringify({ allowed: true, reason: "admitted" }), { status: 200 });
    },
  });
  assert.deepEqual(result, { allowed: true, reason: "admitted" });
  assert.equal(calls[0][0], "http://usage-sentinel:4317/admission/claude-code");
  assert.equal(calls[0][1].method, "GET");
});

test("supervisor sends requests to its explicit Sentinel override", async () => {
  const calls = [];
  const client = createConfiguredSentinel({
    env: { SENTINEL_URL: "http://sentinel.override:9876" },
    fetchImpl: async (...args) => {
      calls.push(args);
      return new Response(JSON.stringify({ allowed: true, reason: "admitted" }), { status: 200 });
    },
  });
  assert.deepEqual(await client.checkAdmission(), { allowed: true, reason: "admitted" });
  assert.equal(calls[0][0], "http://sentinel.override:9876/admission/claude-code");
});

test("Agent checks admission with GET using the explicit Sentinel override", async () => {
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ allowed: true, reason: "admitted" }));
  });
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 0);
  assert.deepEqual(sentinel.requests, [{ method: "GET", url: "/admission/claude-code" }]);
});

for (const reason of ["threshold_reached", "telemetry_unavailable"]) {
  test(`Agent exits 2 for ${reason}`, async () => {
    const sentinel = await startSentinel((_req, res) => {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ allowed: false, reason }));
    });
    const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
    await sentinel.close();
    assert.equal(result.code, 2);
    assert.match(result.stderr, /invalid admission decision/);
  });
}

test("Agent exits 2 for an unexpected capacity-like response", async () => {
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(409, { "content-type": "application/json" });
    res.end(JSON.stringify({ allowed: false, reason: "capacity_reached" }));
  });
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 2);
  assert.match(result.stderr, /unexpected admission status 409/);
});

test("Agent exits 2 for malformed JSON", async () => {
  const sentinel = await startSentinel((_req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end("not-json");
  });
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 2);
  assert.match(result.stderr, /malformed JSON/);
});

test("Agent exits 2 when Sentinel times out", async () => {
  const sentinel = await startSentinel(() => {});
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 2);
  assert.match(result.stderr, /timed out/);
});

test("Agent exits 2 when Sentinel is unreachable", async () => {
  const result = await runHook({ tool_name: "Agent" }, { SENTINEL_URL: "http://127.0.0.1:1" });
  assert.equal(result.code, 2);
  assert.match(result.stderr, /unreachable/);
});

test("non-Agent tools make no Sentinel request", async () => {
  const sentinel = await startSentinel((_req, res) => res.end());
  const result = await runHook({ tool_name: "Bash" }, { SENTINEL_URL: sentinel.url });
  await sentinel.close();
  assert.equal(result.code, 0);
  assert.deepEqual(sentinel.requests, []);
});
