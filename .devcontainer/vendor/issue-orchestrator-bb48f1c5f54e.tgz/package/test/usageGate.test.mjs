import { test } from "node:test";
import assert from "node:assert/strict";
import { createSentinelClient } from "../src/usageGate.mjs";

function response(status, body) {
  return {
    status,
    async json() {
      if (body instanceof Error) throw body;
      return body;
    },
  };
}

function recordingFetch(reply) {
  const calls = [];
  return {
    calls,
    fetchImpl: async (...args) => {
      calls.push(args);
      return typeof reply === "function" ? reply(...args) : reply;
    },
  };
}

test("checkAdmission uses the default Sentinel admission endpoint", async () => {
  const fetch = recordingFetch(response(200, { allowed: true, reason: "admitted" }));

  const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).checkAdmission();

  assert.deepEqual(result, { allowed: true, reason: "admitted" });
  assert.equal(fetch.calls.length, 1);
  const [requestUrl, options] = fetch.calls[0];
  assert.equal(requestUrl, "http://usage-sentinel:4317/admission/claude-code");
  assert.equal(options.method, "GET");
  assert.equal(options.body, undefined);
  assert.ok(options.signal instanceof AbortSignal);
});

test("an explicit URL overrides the default URL", async () => {
  const fetch = recordingFetch(response(200, { allowed: true, reason: "admitted" }));

  await createSentinelClient({ fetchImpl: fetch.fetchImpl, url: "http://sentinel.test:9999/" }).checkAdmission();

  assert.equal(fetch.calls[0][0], "http://sentinel.test:9999/admission/claude-code");
});

test("the timeout fails closed even when fetch ignores the abort signal", async () => {
  const client = createSentinelClient({
    fetchImpl: async () => new Promise(() => {}),
    timeoutMs: 5,
  });

  const result = await Promise.race([
    client.checkAdmission(),
    new Promise((resolve) => setTimeout(() => resolve("test timed out"), 50)),
  ]);

  assert.notEqual(result, "test timed out");
  assert.equal(result.allowed, false);
});

test("the timeout fails closed when the response body never resolves", async () => {
  const client = createSentinelClient({
    fetchImpl: async () => response(200, new Promise(() => {})),
    timeoutMs: 5,
  });

  const result = await Promise.race([
    client.checkAdmission(),
    new Promise((resolve) => setTimeout(() => resolve("test timed out"), 50)),
  ]);

  assert.notEqual(result, "test timed out");
  assert.equal(result.allowed, false);
});

test("registerWorker sends the exact worker registration request", async () => {
  const fetch = recordingFetch(response(201, { allowed: true, reason: "registered" }));

  const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).registerWorker("org/repo#21");

  assert.deepEqual(result, { allowed: true, reason: "registered" });
  const [requestUrl, options] = fetch.calls[0];
  assert.equal(requestUrl, "http://usage-sentinel:4317/workers");
  assert.equal(options.method, "POST");
  assert.deepEqual(options.headers, { "content-type": "application/json" });
  assert.equal(options.body, JSON.stringify({ provider: "claude-code", owner: "org/repo#21" }));
  assert.ok(options.signal instanceof AbortSignal);
});

test("registerWorker accepts an existing worker refresh", async () => {
  const client = createSentinelClient({
    fetchImpl: async () => response(200, { allowed: true, reason: "refreshed" }),
  });

  assert.deepEqual(await client.registerWorker("org/repo#21"), { allowed: true, reason: "refreshed" });
});

for (const [status, reason] of [
  [409, "capacity_reached"],
  [429, "threshold_reached"],
  [503, "telemetry_unavailable"],
]) {
  test(`registerWorker preserves the ${status} ${reason} denial`, async () => {
    const client = createSentinelClient({
      fetchImpl: async () => response(status, { allowed: false, reason }),
    });

    assert.deepEqual(await client.registerWorker("org/repo#21"), { allowed: false, reason });
  });
}

test("unregisterWorker sends the exact deletion request and accepts only 204", async () => {
  const fetch = recordingFetch(response(204));

  const result = await createSentinelClient({ fetchImpl: fetch.fetchImpl }).unregisterWorker("org/repo#21");

  assert.deepEqual(result, { allowed: true, reason: "unregistered" });
  const [requestUrl, options] = fetch.calls[0];
  assert.equal(requestUrl, "http://usage-sentinel:4317/workers");
  assert.equal(options.method, "DELETE");
  assert.deepEqual(options.headers, { "content-type": "application/json" });
  assert.equal(options.body, JSON.stringify({ provider: "claude-code", owner: "org/repo#21" }));
  assert.ok(options.signal instanceof AbortSignal);
});

const malformedJson = response(200, new SyntaxError("bad json"));
const failureCases = [
  ["network rejection", async () => { throw new Error("ECONNREFUSED"); }],
  ["abort", async (_url, { signal }) => {
    await new Promise((resolve, reject) => {
      signal.addEventListener("abort", () => reject(signal.reason), { once: true });
    });
  }],
  ["malformed JSON", async () => malformedJson],
  ["unexpected status", async () => response(418, { allowed: false, reason: "threshold_reached" })],
  ["unknown reason", async () => response(200, { allowed: true, reason: "maybe" })],
  ["inconsistent allowed", async () => response(200, { allowed: false, reason: "admitted" })],
];

for (const [name, fetchImpl] of failureCases) {
  test(`checkAdmission fails closed on ${name}`, async () => {
    const result = await createSentinelClient({ fetchImpl, timeoutMs: 5 }).checkAdmission();
    assert.equal(result.allowed, false);
    assert.equal(typeof result.reason, "string");
    assert.ok(result.reason.length > 0);
  });
}

for (const [name, fetchImpl] of failureCases) {
  test(`registerWorker fails closed on ${name}`, async () => {
    const result = await createSentinelClient({ fetchImpl, timeoutMs: 5 }).registerWorker("org/repo#21");
    assert.equal(result.allowed, false);
    assert.equal(typeof result.reason, "string");
    assert.ok(result.reason.length > 0);
  });
}

for (const [name, fetchImpl] of [
  ...failureCases.slice(0, 4),
  ["unexpected response body", async () => response(200, { allowed: true, reason: "unregistered" })],
]) {
  test(`unregisterWorker fails closed on ${name}`, async () => {
    const result = await createSentinelClient({ fetchImpl, timeoutMs: 5 }).unregisterWorker("org/repo#21");
    assert.equal(result.allowed, false);
    assert.equal(typeof result.reason, "string");
    assert.ok(result.reason.length > 0);
  });
}
