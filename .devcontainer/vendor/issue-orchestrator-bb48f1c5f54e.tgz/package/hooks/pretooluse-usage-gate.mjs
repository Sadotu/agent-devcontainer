#!/usr/bin/env node
import { createSentinelClient } from "../src/usageGate.mjs";

async function readStdin() {
  const chunks = [];
  for await (const c of process.stdin) chunks.push(c);
  return Buffer.concat(chunks).toString("utf8");
}

export async function runAdmissionHook(payload, { env = process.env, fetchImpl = fetch } = {}) {
  if (payload.tool_name !== "Agent") return { allowed: true, reason: "not_agent" };
  const url = env.SENTINEL_URL || "http://usage-sentinel:4317";
  try {
    return await createSentinelClient({ url, fetchImpl }).checkAdmission();
  } catch (err) {
    return { allowed: false, reason: `Usage gate error (fail closed): ${err.message}` };
  }
}

async function main() {
  let payload;
  try {
    const raw = await readStdin();
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    process.exit(2);
  }

  const result = await runAdmissionHook(payload);
  if (result.allowed === true && ["admitted", "not_agent"].includes(result.reason)) process.exit(0);
  process.stderr.write(`Usage gate blocked sub-agent start: ${result.reason}\n`);
  process.exit(2);
}

if (import.meta.url === `file://${process.argv[1]}`) main();
