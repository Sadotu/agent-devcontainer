import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import { chmod, mkdtemp, mkdir, rm, symlink, writeFile } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  acquireSupervisorOwnership,
  createGitHub,
  createTmux,
  prForIssue,
  runOnce,
  main,
  workerOwner,
} from "../bin/supervisor.mjs";
import { createSentinelClient } from "../src/usageGate.mjs";

// ---------------------------------------------------------------------------
// supervisor ownership
// ---------------------------------------------------------------------------
test("installed symlink runs the supervisor for the repository in process cwd", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "orchestrator-installed-"));
  let child;
  t.after(async () => {
    if (child?.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    await rm(root, { recursive: true, force: true });
  });
  const repo = join(root, "target");
  const tools = join(root, "tools");
  await mkdir(repo);
  await mkdir(tools);
  const launcher = join(root, "issue-orchestrator");
  await symlink(new URL("../bin/supervisor.mjs", import.meta.url), launcher);
  const helper = join(tools, "token-helper");
  await writeFile(helper, "#!/bin/sh\nprintf token\n");
  await chmod(helper, 0o755);
  for (const name of ["gh", "tmux"]) {
    const file = join(tools, name);
    await writeFile(file, "#!/bin/sh\nexit 0\n");
    await chmod(file, 0o755);
  }
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["init", "-q"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git init exited ${code}`)));
  });
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["remote", "add", "origin", "git@github.com:target-owner/target-repo.git"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git remote exited ${code}`)));
  });

  child = spawn(launcher, [], {
    cwd: repo,
    env: { ...process.env, PATH: `${tools}:${process.env.PATH}`, GH_APP_TOKEN_SCRIPT: helper },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let stdout = ""; let stderr = "";
  child.stdout.on("data", (chunk) => { stdout += chunk; });
  child.stderr.on("data", (chunk) => { stderr += chunk; });
  const timeout = setTimeout(() => child.kill("SIGKILL"), 3000);
  timeout.unref();
  t.after(() => clearTimeout(timeout));
  const [code] = await once(child, "exit");
  assert.equal(code, 0, stderr);
  assert.match(stdout, /Authenticated as GitHub App for target-owner\/target-repo/);
  assert.match(stdout, /Queue empty and no live workers/);
});

test("main rejects duplicate ownership before auth, Sentinel, or tmux setup", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => { events.push("resolve"); return "o/r"; },
    acquireOwnership: async () => { events.push("acquire"); throw new Error("supervisor already running for o/r"); },
    mintToken: async () => { events.push("auth"); },
    createSentinel: () => events.push("sentinel"),
    createTmux: () => events.push("tmux"),
  }), /already running/);
  assert.deepEqual(events, ["resolve", "acquire"]);
});

test("main releases ownership after normal completion", async () => {
  const events = [];
  await main({
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "" }),
    createSentinel: () => ({}),
    createTmux: () => ({}),
    runPoll: async () => ({ done: true }),
    log: () => {},
  });
  assert.deepEqual(events, ["release"]);
});

test("main releases ownership when startup authentication fails", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => { throw new Error("token unavailable"); },
    createTmux: () => ({}),
  }), /GitHub App auth check failed: token unavailable/);
  assert.deepEqual(events, ["release"]);
});

test("supervisor ownership rejects a simultaneous owner and release permits reacquisition", async () => {
  const repo = `test/${randomUUID()}`;
  let listenedAddress;
  const first = await acquireSupervisorOwnership(repo, {
    createServer: () => {
      const server = createNetServer();
      const listen = server.listen.bind(server);
      server.listen = (address, callback) => {
        listenedAddress = address;
        return listen(address, callback);
      };
      return server;
    },
  });
  assert.equal(listenedAddress.startsWith("\0issue-orchestrator-"), true);
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  await first();
  await first();
  const second = await acquireSupervisorOwnership(repo);
  await second();
});

test("simultaneous supervisor acquisitions produce exactly one owner", async () => {
  const repo = `test/${randomUUID()}`;
  const results = await Promise.allSettled([
    acquireSupervisorOwnership(repo),
    acquireSupervisorOwnership(repo),
  ]);
  const winners = results.filter((result) => result.status === "fulfilled");
  assert.equal(winners.length, 1);
  assert.match(results.find((result) => result.status === "rejected").reason.message, /already running/);
  await winners[0].value();
});

test("supervisor ownership is released when its process dies", async () => {
  const repo = `test/${randomUUID()}`;
  const script = `
    import { acquireSupervisorOwnership } from "./bin/supervisor.mjs";
    await acquireSupervisorOwnership(${JSON.stringify(repo)});
    process.stdout.write("READY\\n");
    setInterval(() => {}, 1000);
  `;
  const child = spawn(process.execPath, ["--input-type=module", "--eval", script], {
    cwd: new URL("..", import.meta.url),
    stdio: ["ignore", "pipe", "inherit"],
  });
  await once(child.stdout, "data");
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  child.kill("SIGKILL");
  await once(child, "exit");

  const release = await acquireSupervisorOwnership(repo);
  await release();
});

// ---------------------------------------------------------------------------
// prForIssue
// ---------------------------------------------------------------------------
test("prForIssue matches head branch prefix, not a numeric superstring", () => {
  const prs = [
    { headRefName: "agent/12-something", isDraft: true, url: "u12" },
    { headRefName: "agent/120-other", isDraft: false, url: "u120" },
  ];
  assert.deepEqual(prForIssue(prs, 12), { isDraft: true, url: "u12" });
  assert.equal(prForIssue(prs, 99), null);
});

// ---------------------------------------------------------------------------
// GitHub adapter
// ---------------------------------------------------------------------------
function fakeExec(responses) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push([file, ...args]);
    const key = args.join(" ");
    for (const [match, out] of responses) {
      if (key.includes(match)) return { stdout: out };
    }
    return { stdout: "" };
  };
  return { exec, calls };
}

test("github listReadyIssues returns ascending numbers", async () => {
  const { exec } = fakeExec([["--label agent-ready", JSON.stringify([{ number: 9 }, { number: 3 }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listReadyIssues(), [3, 9]);
});

test("github listOpenPrs queries only open PRs", async () => {
  const { exec, calls } = fakeExec([["pr list", JSON.stringify([{ headRefName: "agent/1-x", isDraft: true, url: "u" }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  const prs = await gh.listOpenPrs();
  assert.equal(prs.length, 1);
  const c = calls.find((c) => c.includes("list") && c.includes("pr"));
  assert.ok(c.includes("--state") && c.includes("open"));
  assert.ok(!c.includes("all"));
});

test("github claim swaps ready->running", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.claim(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-ready"));
  assert.ok(c.includes("--add-label") && c.includes("agent-running"));
});

test("github release removes running and adds no other label", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.release(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(!c.includes("--add-label"));
  assert.ok(!c.join(" ").includes("agent-blocked"));
});

test("github restore swaps running back to ready", async () => {
  const { exec, calls } = fakeExec([]);
  await createGitHub({ exec, repo: "o/r" }).restore(5);
  const c = calls.find((call) => call.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(c.includes("--add-label") && c.includes("agent-ready"));
});

// ---------------------------------------------------------------------------
// tmux adapter
// ---------------------------------------------------------------------------
function tmuxRecorder({ listOutput = "", listError = null, killError = null } = {}) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push(args);
    if (args[0] === "list-windows" && listError) throw listError;
    if (args[0] === "list-windows") return { stdout: listOutput };
    if (args[0] === "kill-window" && killError) throw killError;
    return { stdout: "" };
  };
  return { exec, calls };
}

test("tmux listWorkerIssues parses issue-<n> window names", async () => {
  const { exec } = tmuxRecorder({ listOutput: "supervisor\nissue-3\nissue-12\nnotes\n" });
  const tmux = createTmux({ exec });
  const set = await tmux.listWorkerIssues();
  assert.deepEqual([...set].sort((a, b) => a - b), [3, 12]);
});

test("tmux listWorkerIssues propagates list-windows inspection failures", async () => {
  const error = new Error("temporary tmux server failure");
  const { exec } = tmuxRecorder({ listError: error });
  const tmux = createTmux({ exec });
  await assert.rejects(() => tmux.listWorkerIssues(), error);
});

test("tmux openWorker creates a self-closing auto-mode issue worker", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  await tmux.openWorker(7);
  const c = calls.find((a) => a[0] === "new-window");
  assert.deepEqual(c, [
    "new-window",
    "-t",
    "orchestrator",
    "-n",
    "issue-7",
    'claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"',
  ]);
});

test("tmux openWorker rejects a non-integer issue number (no shell injection)", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  assert.throws(() => tmux.openWorker('7" && rm -rf /'), /invalid issue number/);
  assert.equal(calls.length, 0);
});

test("tmux closeWorker treats a confirmed missing window as success", async () => {
  const err = new Error("kill-window failed");
  err.stderr = "can't find window: orchestrator:issue-7";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec });
  await tmux.closeWorker(7); // must not throw
});

test("tmux closeWorker propagates a non-absent failure (e.g. server down)", async () => {
  const err = new Error("no server running on /tmp/tmux-1000/default");
  err.stderr = "no server running on /tmp/tmux-1000/default";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec });
  await assert.rejects(() => tmux.closeWorker(7), /no server running/);
});

// ---------------------------------------------------------------------------
// runOnce
// ---------------------------------------------------------------------------
function stubGh(overrides = {}) {
  return {
    listReadyIssues: async () => [],
    listRunningIssues: async () => [],
    listOpenPrs: async () => [],
    claim: async () => {},
    release: async () => {},
    restore: async () => {},
    ...overrides,
  };
}
function stubTmux(overrides = {}) {
  return {
    ensureSession: async () => {},
    listWorkerIssues: async () => new Set(),
    openWorker: async () => {},
    closeWorker: async () => {},
    ...overrides,
  };
}
const gateOpen = async () => ({ allowed: true, reason: "ok" });
function stubSentinel(overrides = {}) {
  return {
    registerWorker: async () => ({ allowed: true, reason: "registered" }),
    unregisterWorker: async () => ({ allowed: true, reason: "unregistered" }),
    ...overrides,
  };
}

test("runOnce aborts without lifecycle mutations when tmux inspection fails", async () => {
  const events = [];
  const inspectionError = new Error("temporary tmux inspection failure");
  const gh = stubGh({
    listOpenPrs: async () => { events.push("list-prs"); return []; },
    listReadyIssues: async () => { events.push("list-ready"); return [8]; },
    release: async () => events.push("release"),
    claim: async () => events.push("claim"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => { throw inspectionError; },
    openWorker: async () => events.push("open"),
  });
  const sentinel = stubSentinel({
    registerWorker: async () => { events.push("register"); return { allowed: true, reason: "registered" }; },
    unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; },
  });

  await assert.rejects(
    () => runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] }),
    inspectionError,
  );
  assert.deepEqual(events, []);
});

test("runOnce claims ready issues via gh + tmux when gate open", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [4] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({ gh, tmux, checkGate: gateOpen, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [4]);
  assert.equal(res.done, false);
});

test("runOnce never exceeds concurrency, counting ALL live windows (incl. orphans)", async () => {
  const opened = [];
  // One live window (issue 50) has no matching claimed label — still a worker.
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([50]),
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({ gh, tmux, checkGate: gateOpen, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [1, 2]); // 1 orphan + 2 new = 3
  assert.equal(res.liveCount, 3);
});

test("runOnce fetches fresh admission before EVERY start and pauses mid-fill", async () => {
  const opened = [];
  let gateCalls = 0;
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const checkGate = async () => {
    gateCalls += 1;
    return gateCalls <= 2 ? { allowed: true, reason: "ok" } : { allowed: false, reason: "admission denied" };
  };
  const res = await runOnce({ gh, tmux, checkGate, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [1, 2]); // third blocked by fresh gate
  assert.equal(gateCalls, 3); // one fresh check per start attempt
  assert.equal(res.paused, true);
  assert.equal(res.done, false); // ready remains → keep polling
});

test("runOnce heartbeats live workers but attempts no new registration when full", async () => {
  const owners = [];
  const gh = stubGh({ listReadyIssues: async () => [1] });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([10, 11, 12]) }); // full
  const sentinel = stubSentinel({ registerWorker: async (owner) => { owners.push(owner); return { allowed: true, reason: "refreshed" }; } });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(owners, ["o/r#10", "o/r#11", "o/r#12"]);
  assert.equal(res.started, 0);
});

test("runOnce completion closes, unregisters, then releases and frees the slot", async () => {
  const order = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async (n) => order.push(`release-${n}`),
    listReadyIssues: async () => [8],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async (n) => order.push(`close-${n}`),
    openWorker: async (n) => order.push(`open-${n}`),
  });
  const sentinel = stubSentinel({ unregisterWorker: async (owner) => { order.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; } });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(order, ["close-7", "unregister-o/r#7", "release-7", "open-8"]);
  assert.equal(res.liveCount, 1); // 7 freed, 8 started
});

test("runOnce completion with an already-gone window does not close or double-count", async () => {
  const order = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => order.push("release"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set(), // window already gone
    closeWorker: async () => order.push("close"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { order.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(order, ["close", "unregister", "release"]);
  assert.equal(res.liveCount, 0);
});

test("runOnce surfaces a vanished worker, releases it, and does not restart", async () => {
  const surfaced = [];
  const opened = [];
  const released = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/2-x", isDraft: true, url: "u2" }],
    release: async (n) => released.push(n),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set(), // no live window
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({
    gh, tmux, checkGate: gateOpen, concurrency: 3,
    log: (m) => surfaced.push(m), claimedIssues: [2],
  });
  assert.deepEqual(released, [2]);
  assert.deepEqual(opened, []);
  assert.ok(surfaced.some((m) => /2/.test(m) && /u2/.test(m)));
  assert.equal(res.liveCount, 0);
});

test("runOnce isolates a failed action — a close failure keeps the slot and does not skip fills", async () => {
  const logs = [];
  const opened = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    listReadyIssues: async () => [8],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async () => { throw new Error("no server running"); },
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({
    gh, tmux, checkGate: gateOpen, concurrency: 3,
    log: (m) => logs.push(m), claimedIssues: [7],
  });
  assert.ok(logs.some((m) => /reconcile error for #7/.test(m)));
  // 7's window still counts (close failed → slot not freed), so only 1 free slot left.
  assert.deepEqual(opened, [8]);
  assert.equal(res.liveCount, 2); // 7 (still up) + 8
});

test("workerOwner is stable and live windows heartbeat before a new registration", async () => {
  assert.equal(workerOwner("o/r", 12), "o/r#12");
  const events = [];
  const sentinel = stubSentinel({
    registerWorker: async (owner) => {
      events.push(`register-${owner}`);
      return { allowed: true, reason: owner.endsWith("#9") ? "refreshed" : "registered" };
    },
  });
  const gh = stubGh({ listReadyIssues: async () => [2] });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([9]), openWorker: async () => events.push("open-2") });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["register-o/r#9", "register-o/r#2", "open-2"]);
});

test("heartbeat denial starts nothing and closes no existing worker", async () => {
  const events = [];
  const sentinel = stubSentinel({ registerWorker: async () => ({ allowed: false, reason: "threshold_reached" }) });
  const gh = stubGh({
    listReadyIssues: async () => [2],
    listOpenPrs: async () => [{ headRefName: "agent/9-x", isDraft: true, url: "u9" }],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([9]),
    closeWorker: async () => events.push("close"),
    openWorker: async () => events.push("open"),
  });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [9] });
  assert.deepEqual(events, []);
  assert.equal(res.paused, true);
});

test("reconciles completion before heartbeating surviving live workers", async () => {
  const events = [];
  const sentinel = stubSentinel({
    unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; },
    registerWorker: async (owner) => { events.push(`heartbeat-${owner}`); return { allowed: false, reason: "threshold_reached" }; },
  });
  const gh = stubGh({
    listReadyIssues: async () => [8],
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async (n) => events.push(`release-${n}`),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([3, 5]),
    closeWorker: async (n) => events.push(`close-${n}`),
    openWorker: async () => events.push("open"),
  });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {}, claimedIssues: [3, 5] });
  assert.deepEqual(events, ["close-3", "unregister-o/r#3", "release-3", "heartbeat-o/r#5"]);
});

test("heartbeat failure still attempts every live owner exactly once", async () => {
  const owners = [];
  const events = [];
  const sentinel = stubSentinel({ registerWorker: async (owner) => {
    owners.push(owner);
    return owner.endsWith("#3")
      ? { allowed: false, reason: "telemetry_unavailable" }
      : { allowed: true, reason: "refreshed" };
  } });
  const gh = stubGh({
    listReadyIssues: async () => [8],
    listOpenPrs: async () => [],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([3, 5, 7]),
    closeWorker: async () => events.push("close"),
    openWorker: async () => events.push("open"),
  });
  const res = await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 4, log: () => {}, claimedIssues: [] });
  assert.deepEqual(owners, ["o/r#3", "o/r#5", "o/r#7"]);
  assert.deepEqual(events, []);
  assert.equal(res.paused, true);
});

test("new registration must be registered before claim; claim failure unregisters", async () => {
  const events = [];
  const sentinel = stubSentinel({
    registerWorker: async (owner) => { events.push(`register-${owner}`); return { allowed: true, reason: "registered" }; },
    unregisterWorker: async (owner) => { events.push(`unregister-${owner}`); return { allowed: true, reason: "unregistered" }; },
  });
  const gh = stubGh({ listReadyIssues: async () => [2], claim: async () => { events.push("claim-2"); throw new Error("claim failed"); } });
  await runOnce({ gh, tmux: stubTmux(), sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["register-o/r#2", "claim-2", "unregister-o/r#2"]);
});

test("open failure unregisters then restores GitHub labels", async () => {
  const events = [];
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const gh = stubGh({
    listReadyIssues: async () => [2], claim: async () => events.push("claim"), restore: async () => events.push("restore"),
  });
  const tmux = stubTmux({ openWorker: async () => { events.push("open"); throw new Error("tmux failed"); } });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["claim", "open", "unregister", "restore"]);
});

test("open failure logs original plus unregister and restore cleanup failures", async () => {
  const logs = [];
  const sentinel = stubSentinel({ unregisterWorker: async () => ({ allowed: false, reason: "delete failed" }) });
  const gh = stubGh({
    listReadyIssues: async () => [2], claim: async () => {}, restore: async () => { throw new Error("labels failed"); },
  });
  const tmux = stubTmux({ openWorker: async () => { throw new Error("tmux failed"); } });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: (m) => logs.push(m) });
  assert.match(logs.join("\n"), /tmux failed.*unregister: delete failed.*restore: labels failed/);
});

test("completion unregister failure logs and does not release", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async () => events.push("release"),
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => ({ allowed: false, reason: "delete failed" }) });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([3]), closeWorker: async () => events.push("close") });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: (m) => logs.push(m), claimedIssues: [3] });
  assert.deepEqual(events, ["close"]);
  assert.match(logs.join("\n"), /reconcile error for #3.*unregister failed/);
});

test("completion release failure is logged after close and unregister", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async () => { events.push("release"); throw new Error("label failed"); },
  });
  const sentinel = stubSentinel({ unregisterWorker: async () => { events.push("unregister"); return { allowed: true, reason: "unregistered" }; } });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([3]), closeWorker: async () => events.push("close") });
  await runOnce({ gh, tmux, sentinel, repo: "o/r", concurrency: 3, log: (m) => logs.push(m), claimedIssues: [3] });
  assert.deepEqual(events, ["close", "unregister", "release"]);
  assert.match(logs.join("\n"), /reconcile error for #3.*label failed/);
});

test("runOnce rejects missing repository when using Sentinel", async () => {
  await assert.rejects(
    () => runOnce({ gh: stubGh(), tmux: stubTmux(), sentinel: stubSentinel(), log: () => {} }),
    /repository/i,
  );
});

test("two supervisors share Sentinel capacity and refresh existing owners", async (t) => {
  const owners = new Set(["a/r#9"]);
  const responses = [];
  let admissionClosedResolve;
  const admissionClosed = new Promise((resolve) => { admissionClosedResolve = resolve; });
  const server = http.createServer(async (req, res) => {
    let body = ""; for await (const chunk of req) body += chunk;
    const owner = body ? JSON.parse(body).owner : "";
    if (req.method === "POST" && req.url === "/workers") {
      // This decision and mutation are synchronous after body parsing, matching
      // the Sentinel's atomic registration contract.
      if (owners.has(owner)) { responses.push([owner, 200, "refreshed", owners.size]); res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify({ allowed: true, reason: "refreshed" })); }
      else if (owners.size >= 3) { responses.push([owner, 429, "threshold_reached"]); res.writeHead(429, { "content-type": "application/json" }); res.end(JSON.stringify({ allowed: false, reason: "threshold_reached" })); }
      else { owners.add(owner); if (owners.size === 3) admissionClosedResolve(); res.writeHead(201, { "content-type": "application/json" }); res.end(JSON.stringify({ allowed: true, reason: "registered" })); }
    } else if (req.method === "DELETE") { owners.delete(owner); res.writeHead(204); res.end(); }
    else { res.writeHead(404); res.end(); }
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => server.close());
  const url = `http://127.0.0.1:${server.address().port}`;
  const opened = [];
  const seededSupervisor = runOnce({ gh: stubGh({ listOpenPrs: async () => { await admissionClosed; return []; }, listReadyIssues: async () => [1] }), tmux: stubTmux({ listWorkerIssues: async () => new Set([9]), openWorker: async (n) => opened.push(`a#${n}`) }), sentinel: createSentinelClient({ url }), repo: "a/r", concurrency: 3, log: () => {} });
  const fillingSupervisor = runOnce({ gh: stubGh({ listReadyIssues: async () => [4, 5, 6] }), tmux: stubTmux({ openWorker: async (n) => opened.push(`b#${n}`) }), sentinel: createSentinelClient({ url }), repo: "b/r", concurrency: 3, log: () => {} });
  await Promise.all([seededSupervisor, fillingSupervisor]);
  assert.equal(owners.size, 3);
  assert.ok(opened.length <= 2); // seeded worker + opened workers never exceeds three
  assert.ok(responses.some(([owner, status, reason, size]) => owner === "a/r#9" && status === 200 && reason === "refreshed" && size === 3));
  assert.ok(responses.some(([owner, status, reason]) => owner !== "a/r#9" && status === 429 && reason === "threshold_reached"));
});

test("runOnce pauses new starts when gate closed but keeps polling", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [5] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({
    gh, tmux,
    checkGate: async () => ({ allowed: false, reason: "admission denied" }),
    concurrency: 3, log: () => {},
  });
  assert.deepEqual(opened, []);
  assert.equal(res.paused, true);
  assert.equal(res.done, false);
});

test("runOnce is done when no ready issues and no live workers", async () => {
  const res = await runOnce({
    gh: stubGh(), tmux: stubTmux(), checkGate: gateOpen, concurrency: 3, log: () => {},
  });
  assert.equal(res.done, true);
});
