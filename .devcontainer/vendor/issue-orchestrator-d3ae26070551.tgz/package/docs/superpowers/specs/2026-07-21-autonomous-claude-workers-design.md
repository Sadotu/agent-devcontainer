# Autonomous Claude Workers Design

## Goal

Start each issue worker without an interactive workspace-trust prompt, run it
in Claude Code auto permission mode on a pinned Opus 4.8 model, and close its
tmux window when the `/github-issue` command finishes.

## Design

The tmux adapter will launch this command for each validated issue number:

```sh
claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

`--print` makes the worker non-interactive. Claude Code documents that this
mode skips the workspace-trust dialog, and the process exits after completing
the supplied prompt. `--permission-mode auto` enables Claude Code's built-in
automatic permission classifier instead of requiring tool confirmations.
`--model claude-opus-4-8` pins issue work to Opus 4.8 instead of inheriting
Claude Code's default model or following the moving `opus` alias.

The supervisor retains its existing lifecycle. A running tmux window counts as
one worker. When Claude exits, tmux closes that worker window. On the next poll,
the supervisor reconciles the missing window against GitHub PR state using its
existing completed-or-vanished behavior.

## Error Handling

No prompt automation or persisted trust-state manipulation will be added. This
avoids accepting unrelated future prompts and avoids depending on Claude Code's
internal trust-storage format. A Claude failure exits the process and follows
the supervisor's existing vanished-worker handling. An unavailable or
unsupported Opus 4.8 model must fail visibly through that same path; the
launcher will not silently fall back to Sonnet or another model.

## Testing and Documentation

The tmux adapter test will assert the exact non-interactive auto-mode command,
including the pinned model, while retaining the shell-injection rejection
test. The README will describe workers as autonomous, non-interactive,
self-closing, and pinned to Opus 4.8 rather than interactive or dependent on
Claude Code's default model.

## Scope

This change does not restart current workers, alter Usage Sentinel admission,
change concurrency, or modify PR reconciliation behavior.
