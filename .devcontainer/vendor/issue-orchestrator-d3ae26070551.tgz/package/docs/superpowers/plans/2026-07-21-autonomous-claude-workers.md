# Autonomous Claude Workers Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Launch each issue worker in Claude Code non-interactive auto mode on pinned Opus 4.8 so workspace trust never blocks it and its tmux window closes when work finishes.

**Architecture:** Keep worker lifecycle ownership in the existing tmux adapter. Change only the command passed to `tmux new-window`; the supervisor's existing window and PR reconciliation remains authoritative after the process exits.

**Tech Stack:** Node.js 20+, built-in `node:test`, tmux, Claude Code CLI

---

> **Historical steps:** Tasks 1-3 are completed historical steps. Tasks 4-5
> supersede their worker command examples; do not copy the Tasks 1-3 commands
> for current use.

### Task 1: Launch autonomous workers

**Files:**
- Modify: `test/supervisor.test.mjs:265`
- Modify: `bin/supervisor.mjs:160`

- [ ] **Step 1: Strengthen the worker-command test so it fails on the current interactive command**

Replace the current `tmux openWorker creates issue-<n> window running github-issue` test with:

```js
test("tmux openWorker creates a self-closing auto-mode issue worker", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  await tmux.openWorker(7);
  const c = calls.find((args) => args[0] === "new-window");
  assert.deepEqual(c, [
    "new-window",
    "-t", "orchestrator",
    "-n", "issue-7",
    'claude --print --permission-mode auto "/github-issue 7"',
  ]);
});
```

- [ ] **Step 2: Run the focused test and verify the red state**

Run:

```bash
node --test --test-name-pattern="self-closing auto-mode" test/supervisor.test.mjs
```

Expected: FAIL because the actual command is still `claude "/github-issue 7"`.

- [ ] **Step 3: Make the minimal launcher change**

In `createTmux().openWorker()`, replace the command construction with:

```js
const cmd = `claude --print --permission-mode auto "/github-issue ${n}"`;
```

Keep the validated numeric interpolation and existing `tmux new-window` call unchanged.

- [ ] **Step 4: Run the focused test and verify the green state**

Run:

```bash
node --test --test-name-pattern="self-closing auto-mode" test/supervisor.test.mjs
```

Expected: the selected test passes with no failures.

- [ ] **Step 5: Run the full test suite**

Run:

```bash
npm test
```

Expected: all tests pass.

- [ ] **Step 6: Commit the behavioral change**

```bash
git add bin/supervisor.mjs test/supervisor.test.mjs
git commit -m "fix: launch autonomous Claude workers"
```

### Task 2: Document autonomous worker lifecycle

**Files:**
- Modify: `README.md:32`
- Modify: `README.md:60`

- [ ] **Step 1: Update the usage overview**

Replace the overview's interactive-worker wording with:

```markdown
workers, and starts autonomous
`claude --print --permission-mode auto "/github-issue <number>"` workers
itself. Non-interactive mode skips Claude Code's workspace-trust prompt and
each worker process exits after its command finishes. Sentinel failures fail
closed. Do not start Claude separately.
```

- [ ] **Step 2: Update the Claim lifecycle bullet**

Replace the Claim bullet's worker description with:

```markdown
- **Claim** — the lowest-numbered `agent-ready` issue has its label swapped
  `agent-ready` → `agent-running`, then a tmux window `issue-<n>` opens running
  autonomous `claude --print --permission-mode auto "/github-issue <n>"`.
  Non-interactive mode skips workspace trust; the process and tmux window close
  after the command finishes. State lives entirely in GitHub labels, PR draft
  status, and tmux windows — there is no durable state file.
```

- [ ] **Step 3: Check for stale interactive-worker documentation**

Run:

```bash
rg -n 'interactive.*claude|claude "/github-issue' README.md
```

Expected: no stale description of workers as interactive and both documented command occurrences include `--print --permission-mode auto`.

- [ ] **Step 4: Re-run the full test suite**

Run:

```bash
npm test
```

Expected: all tests pass.

- [ ] **Step 5: Commit the documentation**

```bash
git add README.md
git commit -m "docs: explain autonomous worker lifecycle"
```

### Task 3: Verify the installable package behavior

**Files:**
- Verify only: `package.json`
- Verify only: `bin/supervisor.mjs`

- [ ] **Step 1: Verify the package test suite from a clean command invocation**

Run:

```bash
npm test
```

Expected: exit code 0 and all tests pass.

- [ ] **Step 2: Verify the installed entrypoint syntax**

Run:

```bash
node --check bin/supervisor.mjs
```

Expected: exit code 0 with no output.

- [ ] **Step 3: Inspect the final diff and commit list**

Run:

```bash
git status --short
git diff HEAD~2..HEAD -- bin/supervisor.mjs test/supervisor.test.mjs README.md
git log -3 --oneline
```

Expected: clean status; diff contains only the autonomous command, its exact test, and documentation; the two implementation commits follow the design-spec commit.

Do not restart the current supervisor or workers as part of repository verification. Installing the changed package into `agent-devcontainer` and restarting work is a separate deployment action after this implementation is reviewed.

### Task 4: Pin autonomous workers to Opus 4.8

**Files:**
- Modify: `test/supervisor.test.mjs:265`
- Modify: `bin/supervisor.mjs:160`

- [ ] **Step 1: Extend the exact worker-command test with the pinned model**

Change the expected command in `tmux openWorker creates a self-closing auto-mode issue worker` to:

```js
'claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"',
```

- [ ] **Step 2: Run the focused test and verify the red state**

Run:

```bash
node --test --test-name-pattern="self-closing auto-mode" test/supervisor.test.mjs
```

Expected: FAIL because the launcher does not yet include `--model claude-opus-4-8`.

- [ ] **Step 3: Add the model pin to the launcher**

Change the command in `createTmux().openWorker()` to:

```js
const cmd = `claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue ${n}"`;
```

Keep the positive-integer validation, shell quoting, tmux window name, and all supervisor lifecycle behavior unchanged.

- [ ] **Step 4: Run the focused test and verify the green state**

Run:

```bash
node --test --test-name-pattern="self-closing auto-mode" test/supervisor.test.mjs
```

Expected: the selected test passes with no failures.

- [ ] **Step 5: Run the explicit full suite**

Run:

```bash
node --test test/*.test.mjs
```

Expected: 78 tests pass and 0 fail. Use the explicit test paths because a fresh worktree's missing dotagents-managed `.agents/skills` target makes bare `npm test` discover a broken `.claude/skills` symlink.

- [ ] **Step 6: Commit the model pin**

```bash
git add bin/supervisor.mjs test/supervisor.test.mjs
git commit -m "fix: pin issue workers to Opus 4.8"
```

### Task 5: Document and verify the pinned model

**Files:**
- Modify: `README.md:32`
- Modify: `README.md:61`

- [ ] **Step 1: Update both documented worker commands**

In the usage overview and Claim lifecycle bullet, use this exact command shape:

```markdown
`claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"`
```

Use `<n>` in the Claim bullet where that placeholder already appears. State once in the overview that the explicit full model name pins issue workers to Opus 4.8 rather than Claude Code's default or moving `opus` alias.

- [ ] **Step 2: Verify there are no stale unpinned worker commands**

Run:

```bash
rg -n 'claude --print --permission-mode auto' README.md bin/supervisor.mjs test/supervisor.test.mjs
```

Expected: every issue-worker command occurrence includes `--model claude-opus-4-8`.

- [ ] **Step 3: Commit the documentation**

```bash
git add README.md
git commit -m "docs: explain the Opus 4.8 worker pin"
```

- [ ] **Step 4: Run final verification**

Run:

```bash
node --test test/*.test.mjs
node --check bin/supervisor.mjs
git diff --check
git status --short
```

Expected: 78 tests pass, syntax and whitespace checks exit 0, and the worktree contains no uncommitted changes after the documentation commit.

- [ ] **Step 5: Refresh the existing draft PR**

Push `agent/28-autonomous-claude-workers` and update PR #29's summary and validation to mention the pinned Opus 4.8 model. Do not restart active workers or rebuild `agent-devcontainer` in this task.
