# issue-orchestrator

A small, supervised issue queue. A single Node supervisor picks up open issues
labeled `agent-ready` (ascending) and keeps at most **three** autonomous
`claude` workers alive — each in its own tmux window running:

```bash
claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

Workers are gated by [Usage Sentinel](https://github.com/Sadotu/usage-sentinel).
The full model name pins issue workers to Opus 4.8 instead of the Claude Code
default or the moving `opus` alias.

## Orchestrator

Zero-dependency Node ≥20.8.0 on Linux (the supervisor guard uses a Linux abstract
Unix socket). No build step.

### Installed/current-repository usage

The npm package installs the `issue-orchestrator` binary. Run it from the
target project repository, not from the package checkout:

```bash
cd /path/to/target-project
issue-orchestrator
```

The shared [`agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
also exposes that command through the literal alias:

```bash
start work
```

The supervisor resolves the `origin` of that current working directory,
checks GitHub App authentication, checks Sentinel before admitting/starting
workers, and starts autonomous workers itself:

```bash
claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <number>"
```

Non-interactive print mode skips the workspace-trust prompt, and each process
exits after its command finishes. Sentinel failures fail closed. Do not start
Claude separately.

Only one supervisor per repository per Linux network namespace may run at a
time. A second invocation in the same namespace for the same resolved
`owner/repo` exits nonzero with an `already running` error before
authentication, Sentinel, tmux, or worker startup. Ownership is held by a
kernel-owned Linux abstract Unix socket, so it is released on normal exit and
automatically when the supervisor process dies. Devcontainers normally have
distinct network namespaces and therefore independent guards; containers that
share a network namespace also share this guard.

Neither the image build nor devcontainer startup launches the supervisor or
an LLM. Work begins only when a user explicitly runs `issue-orchestrator` or
its `start work` alias.

### Repository-checkout usage

```bash
npm test                 # node --test over test/
node bin/supervisor.mjs  # start the supervisor loop
tmux attach -t orchestrator   # watch the workers directly
```

### How it works

- **Claim** — the lowest-numbered `agent-ready` issue has its label swapped
  `agent-ready` → `agent-running`, then a tmux window `issue-<n>` opens running
  this autonomous command:

  ```bash
  claude --print --permission-mode auto --model claude-opus-4-8 "/github-issue <n>"
  ```

  Non-interactive print mode skips the workspace-trust prompt; the process exits
  and its tmux window closes after the command finishes. State lives entirely in
  GitHub labels, PR draft status, and tmux windows — there is no durable state
  file.
- **Complete** — when a worker's PR flips from draft to ready-for-review, the
  supervisor closes its tmux window, unregisters its stable Sentinel owner,
  then removes `agent-running`. An already-closed window is treated as closed;
  a failure at any later step is logged and retried by the next poll.
- **Vanished** — if a worker window disappears while its PR is still draft,
  its Sentinel owner is unregistered before `agent-running` is removed. The
  issue number and draft PR URL are surfaced, and the issue is **not** restarted
  automatically because its draft PR or worktree may still exist.
- **Admission and capacity** — Sentinel is authoritative for usage admission
  and the combined global limit of three workers across every connected
  repository. The supervisor also keeps a cheap local maximum-three guard. A
  stable owner (`<repository>#<issue-number>`) is registered before claim and
  tmux creation; claim failure unregisters it, while tmux failure unregisters
  it and restores the labels. Every live worker is heartbeated each poll, and
  `registered` is accepted as well as `refreshed` so Sentinel can rebuild its
  registry after a restart. A failed heartbeat prevents new starts but does not
  stop an existing worker.
- **Stop** — the supervisor exits when no claimable issues and no live workers
  remain. It does not terminate healthy workers merely because admission later
  closes.

### GitHub authentication

`gh` does not auto-consume the GitHub App credential, so the supervisor mints a
short-lived App installation token (via `gh-app-token.sh`, overridable with
`GH_APP_TOKEN_SCRIPT`) and injects it as `GH_TOKEN` for every `gh` call,
re-minting each poll. At startup it runs an authenticated `gh repo view` smoke
check and exits with a clear message if the App is not authenticated — rather
than churning on unauthenticated calls every poll.

### Configuration

The local concurrency guard is fixed at 3. Two knobs are environment-tunable:

| Var | Default | Meaning |
|-----|---------|---------|
| `SENTINEL_URL` | `http://usage-sentinel:4317` | Usage Sentinel base URL on the shared container network; set this explicitly (for example, `http://host.docker.internal:4317`) only when Sentinel is exposed on the host |
| `POLL_MS` | `60000` | Poll interval |

Labels: `agent-ready` (claimable) and `agent-running` (claimed/live). The
repository already defines these; the supervisor only swaps between them.

### Sub-agent usage gate

`.claude/settings.json` registers a `PreToolUse` hook matching the `Agent`
tool at `hooks/pretooluse-usage-gate.mjs`. Before a sub-agent is created, it
calls Sentinel admission only; it never registers another worker because the
sub-agent belongs to the top-level worker tree. The hook fails closed and exits
`2` for a denial, invalid response, timeout, or connection failure. Only a
valid admitted response exits `0`.

### Manual two-devcontainer smoke check

Run this integration check manually against a standalone Usage Sentinel; do not
substitute a mocked server. The exact Sentinel image/start command depends on
that repository, but its container must be named `usage-sentinel`, listen on
port `4317`, and join a Docker network named `agent-services`.

1. Start standalone Sentinel and create/connect its network if necessary:
   `docker network create agent-services` followed by the Sentinel repository's
   documented start command, then
   `docker network connect agent-services usage-sentinel` if it was not already
   attached.
2. Start two different project devcontainers. From the host, connect each
   container with `docker network connect agent-services <container-name>`.
3. In **both** devcontainers, run
   `curl -fsS http://usage-sentinel:4317/admission/claude-code` to prove shared
   DNS and reachability.
4. Register owners from both repositories, three total, using the following
   command with a distinct stable owner each time (for example `org/a#1`,
   `org/a#2`, and `org/b#1`):
   `curl -i -X POST -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/a#1"}' http://usage-sentinel:4317/workers`.
   From the other devcontainer, attempt a fourth distinct owner and confirm it
   is denied, demonstrating that only three workers are admitted in total
   across the two repositories.
5. Close admission by inducing Sentinel's configured provider threshold. Then
   confirm `GET /admission/claude-code` denies a new start while repeating the
   same `POST /workers` for one of the three existing owners still succeeds as
   a `refreshed` heartbeat.
6. Clean up every registered smoke owner with the same request body used to
   register it, changing the method to DELETE:
   `curl -i -X DELETE -H 'content-type: application/json' -d '{"provider":"claude-code","owner":"org/a#1"}' http://usage-sentinel:4317/workers`.
   Repeat for all owners, including any denied fourth-owner attempt if Sentinel
   retained it unexpectedly. Optionally detach the test containers afterward
   with `docker network disconnect agent-services <container-name>` (including
   `usage-sentinel` if it should not remain attached).
7. Using the [smoke-check record guide](docs/smoke-checks/README.md), create and
   commit a dated, revision-specific record of the commands, responses,
   environment details, and pass/fail result.
   This repository does not claim that smoke check has run merely from the unit-test result.

## Repo contents

| Path | Purpose |
|------|---------|
| `agents.toml` / `agents.lock` | [dotagents](https://github.com/Sadotu/agent-skills) manifest — declares which skills are installed and pins their source commits |
| `.agents/skills/` | Installed skills (`github-issue`, `setup`) — managed artifacts, restored from the manifest, not committed |
| `.claude/skills` | Symlink to `.agents/skills` so Claude Code picks the skills up |
| `CLAUDE.md` | Agent instructions and gotchas for working in this repo |

## Skills

- **`github-issue`** — runs a GitHub issue end to end: select issue, open a
  draft PR immediately, self-resolve design decisions (logged to the PR),
  implement in an isolated worktree, verify against the issue, mark ready.
- **`setup`** — connects the repo to the `container-coding-agent` GitHub App
  and verifies `git`/`gh` authenticate as the App.

Both are sourced from [`Sadotu/agent-skills`](https://github.com/Sadotu/agent-skills).

## Development environment

Agents work on this repo from a shared, sandboxed devcontainer. That
environment is **not part of this app** — it lives in its own repo:
[`Sadotu/agent-devcontainer`](https://github.com/Sadotu/agent-devcontainer)
(image, setup scripts, security model, auth docs). A local `.devcontainer/`
folder pointing at that image may exist in a checkout but is gitignored.

GitHub access is via the scoped `container-coding-agent` GitHub App — never a
personal token, never `gh auth login`. See `CLAUDE.md` for the auth wiring.
