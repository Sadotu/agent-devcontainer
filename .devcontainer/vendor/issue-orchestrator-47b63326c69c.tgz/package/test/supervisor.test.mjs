import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import { chmod, mkdtemp, mkdir, open, rm, symlink, writeFile } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  acquireSupervisorOwnership,
  createConfiguredLease,
  createGitHub,
  createTmux,
  formatLogLine,
  isAgentSetupReady,
  prForIssue,
  runOnce,
  main,
} from "../bin/supervisor.mjs";
import { resolveContainerId } from "../src/managedContainer.mjs";

// ---------------------------------------------------------------------------
// managed-container lease helpers
// ---------------------------------------------------------------------------
const CONTAINER = "c".repeat(64);

// A lease that always succeeds, for tests whose subject is not the lease.
function stubLease() {
  return {
    resolveContainerId: async () => CONTAINER,
    createLeaseClient: () => ({
      register: async () => ({ status: "registered" }),
      unregister: async () => {},
    }),
  };
}

function leaseHarness({ registerImpl, unregisterImpl } = {}) {
  const calls = [];
  return {
    calls,
    lease: {
      register: async (id) => {
        calls.push(["register", id]);
        if (registerImpl) return registerImpl(id, calls.length);
        return { status: calls.length === 1 ? "registered" : "refreshed" };
      },
      unregister: async (id) => {
        calls.push(["unregister", id]);
        if (unregisterImpl) return unregisterImpl(id);
      },
    },
  };
}

test("isAgentSetupReady checks the devcontainer setup marker", async () => {
  const paths = [];
  const ready = await isAgentSetupReady({ accessImpl: async (path) => paths.push(path) });
  assert.equal(ready, true);
  assert.deepEqual(paths, ["/run/agent-devcontainer/agent-setup-complete"]);
});

test("isAgentSetupReady returns false when the setup marker is inaccessible", async () => {
  const ready = await isAgentSetupReady({ accessImpl: async () => { throw new Error("missing"); } });
  assert.equal(ready, false);
});

// ---------------------------------------------------------------------------
// log line formatting
// ---------------------------------------------------------------------------
test("formatLogLine prefixes an ISO timestamp inside the orchestrator tag", () => {
  const now = new Date("2026-07-21T12:34:56.000Z");
  assert.equal(
    formatLogLine("Started worker for #82", now),
    "[orchestrator 2026-07-21T12:34:56.000Z] Started worker for #82",
  );
});

// ---------------------------------------------------------------------------
// supervisor ownership
// ---------------------------------------------------------------------------
test("installed symlink runs the supervisor for the repository in process cwd", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "orchestrator-installed-"));
  let child;
  t.after(async () => {
    if (child?.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    await rm(root, { recursive: true, force: true });
  });
  const repo = join(root, "target");
  const tools = join(root, "tools");
  await mkdir(repo);
  await mkdir(tools);
  const launcher = join(root, "issue-orchestrator");
  await symlink(new URL("../bin/supervisor.mjs", import.meta.url), launcher);
  const helper = join(tools, "token-helper");
  await writeFile(helper, "#!/bin/sh\nprintf token\n");
  await chmod(helper, 0o755);
  for (const name of ["gh", "tmux"]) {
    const file = join(tools, name);
    await writeFile(file, "#!/bin/sh\nexit 0\n");
    await chmod(file, 0o755);
  }
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["init", "-q"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git init exited ${code}`)));
  });
  await new Promise((resolve, reject) => {
    const git = spawn("git", ["remote", "add", "origin", "git@github.com:target-owner/target-repo.git"], { cwd: repo });
    git.once("error", reject); git.once("exit", (code) => code === 0 ? resolve() : reject(new Error(`git remote exited ${code}`)));
  });

  // Stand in for Sentinel's lease API so the run never depends on a deployed
  // Sentinel, and record exactly what the supervisor asks it for.
  const leaseRequests = [];
  const sentinel = http.createServer((req, res) => {
    leaseRequests.push([req.method, req.url]);
    if (req.method === "PUT") {
      res.writeHead(201, { "content-type": "application/json" });
      res.end(JSON.stringify({ containerId: req.url.split("/").pop(), status: "registered" }));
      return;
    }
    res.writeHead(req.method === "DELETE" ? 204 : 404);
    res.end();
  });
  sentinel.listen(0, "127.0.0.1");
  await once(sentinel, "listening");
  t.after(() => new Promise((resolve) => sentinel.close(resolve)));

  child = spawn(launcher, [], {
    cwd: repo,
    env: {
      ...process.env,
      PATH: `${tools}:${process.env.PATH}`,
      GH_APP_TOKEN_SCRIPT: helper,
      SENTINEL_URL: `http://127.0.0.1:${sentinel.address().port}`,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let stdout = ""; let stderr = "";
  child.stdout.on("data", (chunk) => { stdout += chunk; });
  child.stderr.on("data", (chunk) => { stderr += chunk; });
  const timeout = setTimeout(() => child.kill("SIGKILL"), 3000);
  timeout.unref();
  t.after(() => clearTimeout(timeout));
  const [code] = await once(child, "exit");
  assert.equal(code, 0, stderr);
  assert.match(stdout, /Authenticated as GitHub App for target-owner\/target-repo/);
  assert.match(stdout, /Queue empty and no live workers/);

  // The lease carries this container's exact 64-hex ID, and nothing else on
  // Sentinel is ever contacted — no usage telemetry, no worker admission.
  const containerId = await resolveContainerId();
  assert.deepEqual(leaseRequests, [
    ["PUT", `/managed-containers/${containerId}`],
    ["DELETE", `/managed-containers/${containerId}`],
  ]);
  assert.match(stdout, new RegExp(`Managed container lease registered for ${containerId}`));
});

test("main rejects duplicate ownership before auth, the lease, or tmux setup", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => { events.push("resolve"); return "o/r"; },
    acquireOwnership: async () => { events.push("acquire"); throw new Error("supervisor already running for o/r"); },
    mintToken: async () => { events.push("auth"); },
    resolveContainerId: async () => { events.push("container"); return CONTAINER; },
    createTmux: () => events.push("tmux"),
  }), /already running/);
  assert.deepEqual(events, ["resolve", "acquire"]);
});

test("main releases ownership after normal completion", async () => {
  const events = [];
  await main({
    ...stubLease(),
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "" }),
    createTmux: () => ({}),
    runPoll: async () => ({ done: true }),
    log: () => {},
  });
  assert.deepEqual(events, ["release"]);
});

// ---------------------------------------------------------------------------
// managed-container lease wiring
// ---------------------------------------------------------------------------
function mainDeps(overrides = {}) {
  return {
    exec: async () => ({ stdout: "git@github.com:owner/repo.git\n", stderr: "" }),
    acquireOwnership: async () => async () => {},
    mintToken: async () => "token",
    authExec: () => async () => ({ stdout: "owner/repo", stderr: "" }),
    createTmux: () => ({}),
    resolveContainerId: async () => CONTAINER,
    runPoll: async () => ({ done: true }),
    sleepImpl: async () => {},
    log: () => {},
    ...overrides,
  };
}

test("main registers the exact container ID at startup and unregisters on clean shutdown", async () => {
  const { calls, lease } = leaseHarness();
  await main(mainDeps({ createLeaseClient: () => lease }));
  assert.deepEqual(calls, [["register", CONTAINER], ["unregister", CONTAINER]]);
});

test("main refreshes the same lease on every poll", async () => {
  const { calls, lease } = leaseHarness();
  let polls = 0;
  await main(mainDeps({
    createLeaseClient: () => lease,
    runPoll: async () => ({ done: ++polls === 3 }),
  }));
  assert.deepEqual(calls, [
    ["register", CONTAINER], ["register", CONTAINER], ["register", CONTAINER],
    ["unregister", CONTAINER],
  ]);
});

test("main fails fast when the container ID cannot be resolved", async () => {
  const { calls, lease } = leaseHarness();
  let polled = false;
  await assert.rejects(() => main(mainDeps({
    createLeaseClient: () => lease,
    resolveContainerId: async () => { throw new Error("no container mount"); },
    runPoll: async () => { polled = true; return { done: true }; },
  })), /managed-container registration failed: no container mount/);
  assert.equal(polled, false);
  assert.deepEqual(calls, []);
});

test("main fails fast when startup registration fails", async () => {
  let polled = false;
  await assert.rejects(() => main(mainDeps({
    createLeaseClient: () => ({
      register: async () => { throw new Error("sentinel unreachable: ECONNREFUSED"); },
      unregister: async () => {},
    }),
    runPoll: async () => { polled = true; return { done: true }; },
  })), /managed-container registration failed: sentinel unreachable: ECONNREFUSED/);
  assert.equal(polled, false);
});

test("main logs a failed heartbeat and keeps polling", async () => {
  const logs = [];
  let polls = 0;
  const { calls, lease } = leaseHarness({
    registerImpl: (_id, call) => {
      if (call === 2) throw new Error("sentinel request timed out: exceeded 5000ms");
      return { status: "refreshed" };
    },
  });
  await main(mainDeps({
    createLeaseClient: () => lease,
    runPoll: async () => ({ done: ++polls === 3 }),
    log: (message) => logs.push(message),
  }));
  assert.equal(calls.filter(([name]) => name === "register").length, 3);
  assert.equal(polls, 3);
  assert.ok(logs.some((line) => /lease heartbeat failed: sentinel request timed out/.test(line)));
});

test("main logs but does not fail when best-effort unregister fails", async () => {
  const logs = [];
  await main(mainDeps({
    createLeaseClient: () => ({
      register: async () => ({ status: "registered" }),
      unregister: async () => { throw new Error("sentinel unreachable: ECONNREFUSED"); },
    }),
    log: (message) => logs.push(message),
  }));
  assert.ok(logs.some((line) => /lease unregister failed \(Sentinel lease expiry recovers this\)/.test(line)));
});

test("createConfiguredLease targets the configured Sentinel base URL", async () => {
  const urls = [];
  const lease = createConfiguredLease({
    env: { SENTINEL_URL: "http://host.docker.internal:4317" },
    fetchImpl: async (url) => { urls.push(url); return { status: 204 }; },
  });
  await lease.unregister(CONTAINER);
  assert.deepEqual(urls, [`http://host.docker.internal:4317/managed-containers/${CONTAINER}`]);
});

test("main releases ownership when startup authentication fails", async () => {
  const events = [];
  await assert.rejects(() => main({
    resolveRepo: async () => "o/r",
    acquireOwnership: async () => async () => { events.push("release"); },
    mintToken: async () => { throw new Error("token unavailable"); },
    createTmux: () => ({}),
  }), /GitHub App auth check failed: token unavailable/);
  assert.deepEqual(events, ["release"]);
});

test("supervisor ownership rejects a simultaneous owner and release permits reacquisition", async () => {
  const repo = `test/${randomUUID()}`;
  let listenedAddress;
  const first = await acquireSupervisorOwnership(repo, {
    createServer: () => {
      const server = createNetServer();
      const listen = server.listen.bind(server);
      server.listen = (address, callback) => {
        listenedAddress = address;
        return listen(address, callback);
      };
      return server;
    },
  });
  assert.equal(listenedAddress.startsWith("\0issue-orchestrator-"), true);
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  await first();
  await first();
  const second = await acquireSupervisorOwnership(repo);
  await second();
});

test("simultaneous supervisor acquisitions produce exactly one owner", async () => {
  const repo = `test/${randomUUID()}`;
  const results = await Promise.allSettled([
    acquireSupervisorOwnership(repo),
    acquireSupervisorOwnership(repo),
  ]);
  const winners = results.filter((result) => result.status === "fulfilled");
  assert.equal(winners.length, 1);
  assert.match(results.find((result) => result.status === "rejected").reason.message, /already running/);
  await winners[0].value();
});

test("supervisor ownership is released when its process dies", async () => {
  const repo = `test/${randomUUID()}`;
  const script = `
    import { acquireSupervisorOwnership } from "./bin/supervisor.mjs";
    await acquireSupervisorOwnership(${JSON.stringify(repo)});
    process.stdout.write("READY\\n");
    setInterval(() => {}, 1000);
  `;
  const child = spawn(process.execPath, ["--input-type=module", "--eval", script], {
    cwd: new URL("..", import.meta.url),
    stdio: ["ignore", "pipe", "inherit"],
  });
  await once(child.stdout, "data");
  await assert.rejects(() => acquireSupervisorOwnership(repo), /already running/);
  child.kill("SIGKILL");
  await once(child, "exit");

  const release = await acquireSupervisorOwnership(repo);
  await release();
});

// ---------------------------------------------------------------------------
// prForIssue
// ---------------------------------------------------------------------------
test("prForIssue matches head branch prefix, not a numeric superstring", () => {
  const prs = [
    { headRefName: "agent/12-something", isDraft: true, url: "u12" },
    { headRefName: "agent/120-other", isDraft: false, url: "u120" },
  ];
  assert.deepEqual(prForIssue(prs, 12), { isDraft: true, url: "u12" });
  assert.equal(prForIssue(prs, 99), null);
});

test("prForIssue matches a closing reference even when the branch drifted", () => {
  // Real incident: worker branch drifted to `worktree-agent+81-…` (no `agent/N-`
  // prefix) but the finished PR still closes #81 via its `Closes #81` body.
  const prs = [
    {
      headRefName: "worktree-agent+81-h2-test-scope",
      isDraft: false,
      url: "u81",
      closingIssuesReferences: [{ number: 81 }],
    },
  ];
  assert.deepEqual(prForIssue(prs, 81), { isDraft: false, url: "u81" });
});

test("prForIssue closing-reference match compares exact numbers, not superstrings", () => {
  const prs = [
    { headRefName: "feature-x", isDraft: false, url: "u120", closingIssuesReferences: [{ number: 120 }] },
  ];
  assert.equal(prForIssue(prs, 12), null);
  assert.deepEqual(prForIssue(prs, 120), { isDraft: false, url: "u120" });
});

// ---------------------------------------------------------------------------
// GitHub adapter
// ---------------------------------------------------------------------------
function fakeExec(responses) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push([file, ...args]);
    const key = args.join(" ");
    for (const [match, out] of responses) {
      if (key.includes(match)) return { stdout: out };
    }
    return { stdout: "" };
  };
  return { exec, calls };
}

test("github listReadyIssues returns ascending numbers", async () => {
  const { exec } = fakeExec([["--label agent-ready", JSON.stringify([{ number: 9 }, { number: 3 }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  assert.deepEqual(await gh.listReadyIssues(), [3, 9]);
});

test("github listOpenPrs queries only open PRs", async () => {
  const { exec, calls } = fakeExec([["pr list", JSON.stringify([{ headRefName: "agent/1-x", isDraft: true, url: "u" }])]]);
  const gh = createGitHub({ exec, repo: "o/r" });
  const prs = await gh.listOpenPrs();
  assert.equal(prs.length, 1);
  const c = calls.find((c) => c.includes("list") && c.includes("pr"));
  assert.ok(c.includes("--state") && c.includes("open"));
  assert.ok(!c.includes("all"));
});

test("github claim swaps ready->running", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.claim(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-ready"));
  assert.ok(c.includes("--add-label") && c.includes("agent-running"));
});

test("github release removes running and adds no other label", async () => {
  const { exec, calls } = fakeExec([]);
  const gh = createGitHub({ exec, repo: "o/r" });
  await gh.release(5);
  const c = calls.find((c) => c.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(!c.includes("--add-label"));
  assert.ok(!c.join(" ").includes("agent-blocked"));
});

test("github restore swaps running back to ready", async () => {
  const { exec, calls } = fakeExec([]);
  await createGitHub({ exec, repo: "o/r" }).restore(5);
  const c = calls.find((call) => call.includes("edit"));
  assert.ok(c.includes("--remove-label") && c.includes("agent-running"));
  assert.ok(c.includes("--add-label") && c.includes("agent-ready"));
});

// ---------------------------------------------------------------------------
// tmux adapter
// ---------------------------------------------------------------------------
function tmuxRecorder({ listOutput = "", listError = null, killError = null } = {}) {
  const calls = [];
  const exec = async (file, args) => {
    calls.push(args);
    if (args[0] === "list-windows" && listError) throw listError;
    if (args[0] === "list-windows") return { stdout: listOutput };
    if (args[0] === "kill-window" && killError) throw killError;
    return { stdout: "" };
  };
  return { exec, calls };
}

test("tmux listWorkerIssues collects issue windows by name", async () => {
  const { exec, calls } = tmuxRecorder({ listOutput: "supervisor\nissue-3\nissue-12\nnotes\n" });
  const tmux = createTmux({ exec });
  const set = await tmux.listWorkerIssues();
  assert.deepEqual([...set].sort((a, b) => a - b), [3, 12]);
  assert.equal(calls[0].at(-1), "#{window_name}");
});

test("tmux listWorkerIssues propagates list-windows inspection failures", async () => {
  const error = new Error("temporary tmux server failure");
  const { exec } = tmuxRecorder({ listError: error });
  const tmux = createTmux({ exec });
  await assert.rejects(() => tmux.listWorkerIssues(), error);
});

test("tmux openWorker creates a self-closing auto-mode issue worker with no pause environment", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  await tmux.openWorker(7);
  const c = calls.find((a) => a[0] === "new-window");
  assert.deepEqual(c, [
    "new-window",
    "-t",
    "orchestrator",
    "-n",
    "issue-7",
    `bash -ic 'ccode --print --permission-mode auto --model claude-opus-4-8 "/github-issue 7"'`,
  ]);
});

test("tmux openWorker rejects a non-integer issue number (no shell injection)", async () => {
  const { exec, calls } = tmuxRecorder();
  const tmux = createTmux({ exec });
  assert.throws(() => tmux.openWorker('7" && rm -rf /'), /invalid issue number/);
  assert.equal(calls.length, 0);
});

test("tmux closeWorker treats a confirmed missing window as success", async () => {
  const err = new Error("kill-window failed");
  err.stderr = "can't find window: orchestrator:issue-7";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec });
  await tmux.closeWorker(7); // must not throw
});

test("tmux closeWorker propagates a non-absent failure (e.g. server down)", async () => {
  const err = new Error("no server running on /tmp/tmux-1000/default");
  err.stderr = "no server running on /tmp/tmux-1000/default";
  const { exec } = tmuxRecorder({ killError: err });
  const tmux = createTmux({ exec });
  await assert.rejects(() => tmux.closeWorker(7), /no server running/);
});

// ---------------------------------------------------------------------------
// runOnce
// ---------------------------------------------------------------------------
function stubGh(overrides = {}) {
  return {
    listReadyIssues: async () => [],
    listRunningIssues: async () => [],
    listOpenPrs: async () => [],
    claim: async () => {},
    release: async () => {},
    restore: async () => {},
    ...overrides,
  };
}
function stubTmux(overrides = {}) {
  return {
    ensureSession: async () => {},
    listWorkerIssues: async () => new Set(),
    openWorker: async () => {},
    closeWorker: async () => {},
    ...overrides,
  };
}
test("runOnce aborts without lifecycle mutations when tmux inspection fails", async () => {
  const events = [];
  const inspectionError = new Error("temporary tmux inspection failure");
  const gh = stubGh({
    listOpenPrs: async () => { events.push("list-prs"); return []; },
    listReadyIssues: async () => { events.push("list-ready"); return [8]; },
    release: async () => events.push("release"),
    claim: async () => events.push("claim"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => { throw inspectionError; },
    openWorker: async () => events.push("open"),
  });
  await assert.rejects(
    () => runOnce({ gh, tmux, concurrency: 3, log: () => {}, claimedIssues: [7] }),
    inspectionError,
  );
  assert.deepEqual(events, []);
});

test("runOnce claims ready issues via gh + tmux", async () => {
  const opened = [];
  const gh = stubGh({ listReadyIssues: async () => [4] });
  const tmux = stubTmux({ openWorker: async (n) => opened.push(n) });
  const res = await runOnce({ gh, tmux, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [4]);
  assert.equal(res.done, false);
});

test("runOnce never exceeds concurrency, counting ALL live windows (incl. orphans)", async () => {
  const opened = [];
  // One live window (issue 50) has no matching claimed label — still a worker.
  const gh = stubGh({ listReadyIssues: async () => [1, 2, 3] });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([50]),
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({ gh, tmux, concurrency: 3, log: () => {} });
  assert.deepEqual(opened, [1, 2]); // 1 orphan + 2 new = 3
  assert.equal(res.liveCount, 3);
});

test("runOnce completion closes, then releases and frees the slot", async () => {
  const order = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async (n) => order.push(`release-${n}`),
    listReadyIssues: async () => [8],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async (n) => order.push(`close-${n}`),
    openWorker: async (n) => order.push(`open-${n}`),
  });
  const res = await runOnce({ gh, tmux, concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(order, ["close-7", "release-7", "open-8"]);
  assert.equal(res.liveCount, 1); // 7 freed, 8 started
});

test("runOnce completion with an already-gone window does not close or double-count", async () => {
  const order = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    release: async () => order.push("release"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set(), // window already gone
    closeWorker: async () => order.push("close"),
  });
  const res = await runOnce({ gh, tmux, concurrency: 3, log: () => {}, claimedIssues: [7] });
  assert.deepEqual(order, ["release"]);
  assert.equal(res.liveCount, 0);
});

test("runOnce surfaces a vanished worker, releases it, and does not restart", async () => {
  const surfaced = [];
  const opened = [];
  const released = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/2-x", isDraft: true, url: "u2" }],
    release: async (n) => released.push(n),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set(), // no live window
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({
    gh, tmux, concurrency: 3,
    log: (m) => surfaced.push(m), claimedIssues: [2],
  });
  assert.deepEqual(released, [2]);
  assert.deepEqual(opened, []);
  assert.ok(surfaced.some((m) => /2/.test(m) && /u2/.test(m)));
  assert.equal(res.liveCount, 0);
});

test("runOnce isolates a failed action — a close failure keeps the slot and does not skip fills", async () => {
  const logs = [];
  const opened = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: false, url: "u7" }],
    listReadyIssues: async () => [8],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async () => { throw new Error("no server running"); },
    openWorker: async (n) => opened.push(n),
  });
  const res = await runOnce({
    gh, tmux, concurrency: 3,
    log: (m) => logs.push(m), claimedIssues: [7],
  });
  assert.ok(logs.some((m) => /reconcile error for #7/.test(m)));
  // 7's window still counts (close failed → slot not freed), so only 1 free slot left.
  assert.deepEqual(opened, [8]);
  assert.equal(res.liveCount, 2); // 7 (still up) + 8
});

test("open failure restores GitHub labels", async () => {
  const events = [];
  const gh = stubGh({
    listReadyIssues: async () => [2], claim: async () => events.push("claim"), restore: async () => events.push("restore"),
  });
  const tmux = stubTmux({ openWorker: async () => { events.push("open"); throw new Error("tmux failed"); } });
  await runOnce({ gh, tmux, concurrency: 3, log: () => {} });
  assert.deepEqual(events, ["claim", "open", "restore"]);
});

test("open failure logs the original failure plus a restore cleanup failure", async () => {
  const logs = [];
  const gh = stubGh({
    listReadyIssues: async () => [2], claim: async () => {}, restore: async () => { throw new Error("labels failed"); },
  });
  const tmux = stubTmux({ openWorker: async () => { throw new Error("tmux failed"); } });
  await runOnce({ gh, tmux, concurrency: 3, log: (m) => logs.push(m) });
  assert.match(logs.join("\n"), /tmux failed.*restore: labels failed/);
});

test("completion release failure is logged after the close", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({
    listOpenPrs: async () => [{ headRefName: "agent/3-x", isDraft: false, url: "u3" }],
    release: async () => { events.push("release"); throw new Error("label failed"); },
  });
  const tmux = stubTmux({ listWorkerIssues: async () => new Set([3]), closeWorker: async () => events.push("close") });
  await runOnce({ gh, tmux, concurrency: 3, log: (m) => logs.push(m), claimedIssues: [3] });
  assert.deepEqual(events, ["close", "release"]);
  assert.match(logs.join("\n"), /reconcile error for #3.*label failed/);
});

test("runOnce keeps live workers but pauses launches until agent setup completes", async () => {
  const events = [];
  const logs = [];
  const gh = stubGh({
    listReadyIssues: async () => [2],
    claim: async () => events.push("claim-2"),
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([9]),
    openWorker: async () => events.push("open-2"),
    closeWorker: async (n) => events.push(`close-${n}`),
  });

  const result = await runOnce({
    gh, tmux, concurrency: 3, claimedIssues: [],
    checkSetupReady: async () => false,
    log: (message) => logs.push(message),
  });

  assert.deepEqual(events, []);
  assert.deepEqual(result, { done: false, liveCount: 1, started: 0 });
  assert.match(logs.join("\n"), /agent setup/i);
});

// A worker is never terminated for usage reasons: Sentinel pauses the whole
// container instead, so reconciliation only ever closes a completed worker.
test("runOnce never closes a live worker whose PR is still draft", async () => {
  const closed = [];
  const gh = stubGh({
    listRunningIssues: async () => [7],
    listOpenPrs: async () => [{ headRefName: "agent/7-x", isDraft: true, url: "u7" }],
  });
  const tmux = stubTmux({
    listWorkerIssues: async () => new Set([7]),
    closeWorker: async (n) => closed.push(n),
  });
  const result = await runOnce({ gh, tmux, concurrency: 3, log: () => {} });
  assert.deepEqual(closed, []);
  assert.deepEqual(result, { done: false, liveCount: 1, started: 0 });
});

test("runOnce is done when no ready issues and no live workers", async () => {
  const res = await runOnce({
    gh: stubGh(), tmux: stubTmux(), concurrency: 3, log: () => {},
  });
  assert.equal(res.done, true);
});
